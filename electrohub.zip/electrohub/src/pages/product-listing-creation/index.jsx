import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

// Import all components
import ProgressIndicator from './components/ProgressIndicator';
import CategorySelector from './components/CategorySelector';
import ProductInfoForm from './components/ProductInfoForm';
import ConditionAssessment from './components/ConditionAssessment';
import ListingTypeSelector from './components/ListingTypeSelector';
import LocationSettings from './components/LocationSettings';
import ReviewAndSubmit from './components/ReviewAndSubmit';
import PriceEstimationSidebar from './components/PriceEstimationSidebar';

const ProductListingCreation = () => {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState({});
  const [showPriceSidebar, setShowPriceSidebar] = useState(false);
  const [errors, setErrors] = useState({});

  const steps = [
    {
      title: 'Category & Info',
      description: 'Select category and product details',
      component: 'category-info'
    },
    {
      title: 'Condition',
      description: 'Assess condition and upload photos',
      component: 'condition'
    },
    {
      title: 'Listing Type',
      description: 'Choose how to list your product',
      component: 'listing-type'
    },
    {
      title: 'Location',
      description: 'Set pickup and delivery options',
      component: 'location'
    },
    {
      title: 'Review',
      description: 'Review and publish your listing',
      component: 'review'
    }
  ];

  useEffect(() => {
    // Show price sidebar on desktop when we have enough data
    if (window.innerWidth >= 1024 && formData?.productName && formData?.condition) {
      setShowPriceSidebar(true);
    }
  }, [formData?.productName, formData?.condition]);

  const validateStep = (step) => {
    const newErrors = {};

    switch (step) {
      case 0:
        if (!formData?.category) newErrors.category = 'Please select a category';
        if (!formData?.productName) newErrors.productName = 'Product name is required';
        if (!formData?.brand) newErrors.brand = 'Brand is required';
        break;
      case 1:
        if (!formData?.condition) newErrors.condition = 'Please select product condition';
        if (!formData?.images || formData?.images?.length === 0) {
          newErrors.images = 'At least one photo is required';
        }
        break;
      case 2:
        if (!formData?.listingType) newErrors.listingType = 'Please select listing type';
        if (formData?.listingType === 'sell' && !formData?.price) {
          newErrors.price = 'Price is required for sale listings';
        }
        if (formData?.listingType === 'rent' && !formData?.rentalPrice) {
          newErrors.rentalPrice = 'Rental price is required';
        }
        if (formData?.listingType === 'auction' && !formData?.startingBid) {
          newErrors.startingBid = 'Starting bid is required';
        }
        break;
      case 3:
        if (!formData?.address) newErrors.address = 'Address is required';
        if (!formData?.city) newErrors.city = 'City is required';
        if (!formData?.state) newErrors.state = 'State is required';
        if (!formData?.zipCode) newErrors.zipCode = 'ZIP code is required';
        if (!formData?.deliveryMethod) newErrors.deliveryMethod = 'Delivery method is required';
        break;
    }

    setErrors(newErrors);
    return Object.keys(newErrors)?.length === 0;
  };

  const handleNext = () => {
    if (validateStep(currentStep)) {
      if (currentStep < steps?.length - 1) {
        setCurrentStep(currentStep + 1);
      }
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleStepEdit = (stepIndex) => {
    setCurrentStep(stepIndex);
  };

  const handleFormDataChange = (newData) => {
    setFormData(newData);
    // Clear errors when data changes
    setErrors({});
  };

  const handleSubmit = (finalData) => {
    console.log('Submitting listing:', finalData);
    
    // Simulate successful submission
    setTimeout(() => {
      navigate('/marketplace-dashboard', { 
        state: { 
          message: 'Your listing has been published successfully!',
          type: 'success'
        }
      });
    }, 2000);
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 0:
        return (
          <div className="space-y-8">
            <CategorySelector
              selectedCategory={formData?.category}
              onCategorySelect={(category) => handleFormDataChange({ ...formData, category })}
            />
            {formData?.category && (
              <ProductInfoForm
                formData={formData}
                onFormDataChange={handleFormDataChange}
              />
            )}
          </div>
        );
      case 1:
        return (
          <ConditionAssessment
            formData={formData}
            onFormDataChange={handleFormDataChange}
          />
        );
      case 2:
        return (
          <ListingTypeSelector
            formData={formData}
            onFormDataChange={handleFormDataChange}
          />
        );
      case 3:
        return (
          <LocationSettings
            formData={formData}
            onFormDataChange={handleFormDataChange}
          />
        );
      case 4:
        return (
          <ReviewAndSubmit
            formData={formData}
            onEdit={handleStepEdit}
            onSubmit={handleSubmit}
          />
        );
      default:
        return null;
    }
  };

  const canProceed = () => {
    switch (currentStep) {
      case 0:
        return formData?.category && formData?.productName && formData?.brand;
      case 1:
        return formData?.condition && formData?.images && formData?.images?.length > 0;
      case 2:
        return formData?.listingType && (
          (formData?.listingType === 'sell' && formData?.price) ||
          (formData?.listingType === 'rent' && formData?.rentalPrice) ||
          (formData?.listingType === 'auction' && formData?.startingBid)
        );
      case 3:
        return formData?.address && formData?.city && formData?.state && formData?.zipCode && formData?.deliveryMethod;
      default:
        return true;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="pt-16">
        <ProgressIndicator
          currentStep={currentStep}
          totalSteps={steps?.length}
          steps={steps}
        />

        <div className="flex">
          {/* Main Content */}
          <div className={`flex-1 ${showPriceSidebar ? 'lg:pr-80' : ''}`}>
            <div className="max-w-4xl mx-auto p-6 lg:p-8">
              {/* Error Display */}
              {Object.keys(errors)?.length > 0 && (
                <div className="mb-6 bg-red-50 border border-red-200 rounded-lg p-4">
                  <div className="flex items-start space-x-3">
                    <Icon name="AlertCircle" size={20} className="text-red-600 mt-0.5" />
                    <div>
                      <h4 className="font-medium text-red-900">Please fix the following errors:</h4>
                      <ul className="text-sm text-red-700 mt-1 space-y-1">
                        {Object.values(errors)?.map((error, index) => (
                          <li key={index}>• {error}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              )}

              {/* Step Content */}
              <div className="mb-8">
                {renderStepContent()}
              </div>

              {/* Navigation Buttons */}
              <div className="flex items-center justify-between pt-6 border-t border-border">
                <Button
                  variant="outline"
                  onClick={handlePrevious}
                  disabled={currentStep === 0}
                  iconName="ChevronLeft"
                  iconPosition="left"
                >
                  Previous
                </Button>

                <div className="flex items-center space-x-3">
                  {/* Save Draft */}
                  <Button
                    variant="ghost"
                    onClick={() => console.log('Save draft:', formData)}
                    iconName="Save"
                    iconPosition="left"
                  >
                    Save Draft
                  </Button>

                  {/* Next/Finish Button */}
                  {currentStep < steps?.length - 1 ? (
                    <Button
                      variant="primary"
                      onClick={handleNext}
                      disabled={!canProceed()}
                      iconName="ChevronRight"
                      iconPosition="right"
                    >
                      Next
                    </Button>
                  ) : (
                    <Button
                      variant="primary"
                      onClick={() => handleSubmit(formData)}
                      disabled={!canProceed()}
                      iconName="Check"
                      iconPosition="left"
                    >
                      Publish Listing
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Price Estimation Sidebar */}
          <PriceEstimationSidebar
            formData={formData}
            isVisible={showPriceSidebar}
            onToggle={() => setShowPriceSidebar(!showPriceSidebar)}
          />
        </div>
      </div>
      {/* Mobile Price Estimation Toggle */}
      {!showPriceSidebar && formData?.productName && formData?.condition && (
        <div className="fixed bottom-6 right-6 lg:hidden z-40">
          <Button
            variant="primary"
            size="icon"
            onClick={() => setShowPriceSidebar(true)}
            className="rounded-full shadow-lg w-14 h-14"
          >
            <Icon name="DollarSign" size={24} />
          </Button>
        </div>
      )}
      {/* Mobile Sticky Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-card border-t border-border p-4 lg:hidden">
        <div className="flex items-center justify-between">
          <Button
            variant="outline"
            size="sm"
            onClick={handlePrevious}
            disabled={currentStep === 0}
            iconName="ChevronLeft"
            iconPosition="left"
          >
            Previous
          </Button>

          <span className="text-sm text-muted-foreground">
            {currentStep + 1} of {steps?.length}
          </span>

          {currentStep < steps?.length - 1 ? (
            <Button
              variant="primary"
              size="sm"
              onClick={handleNext}
              disabled={!canProceed()}
              iconName="ChevronRight"
              iconPosition="right"
            >
              Next
            </Button>
          ) : (
            <Button
              variant="primary"
              size="sm"
              onClick={() => handleSubmit(formData)}
              disabled={!canProceed()}
              iconName="Check"
              iconPosition="left"
            >
              Publish
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductListingCreation;