import React from 'react';
import Icon from '../../../components/AppIcon';

const ProgressIndicator = ({ currentStep, totalSteps, steps }) => {
  return (
    <div className="bg-card border-b border-border p-4 lg:p-6">
      <div className="max-w-4xl mx-auto">
        {/* Mobile Progress Bar */}
        <div className="lg:hidden mb-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-foreground">
              Step {currentStep + 1} of {totalSteps}
            </span>
            <span className="text-sm text-muted-foreground">
              {Math.round(((currentStep + 1) / totalSteps) * 100)}%
            </span>
          </div>
          <div className="w-full bg-muted rounded-full h-2">
            <div
              className="bg-primary h-2 rounded-full transition-all duration-300"
              style={{ width: `${((currentStep + 1) / totalSteps) * 100}%` }}
            />
          </div>
          <div className="mt-2">
            <h2 className="text-lg font-semibold text-foreground">
              {steps?.[currentStep]?.title}
            </h2>
            <p className="text-sm text-muted-foreground">
              {steps?.[currentStep]?.description}
            </p>
          </div>
        </div>

        {/* Desktop Step Indicator */}
        <div className="hidden lg:block">
          <div className="flex items-center justify-between">
            {steps?.map((step, index) => (
              <div key={index} className="flex items-center">
                <div className="flex items-center">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all ${
                      index < currentStep
                        ? 'bg-primary border-primary text-white'
                        : index === currentStep
                        ? 'border-primary text-primary bg-primary/10' :'border-border text-muted-foreground bg-background'
                    }`}
                  >
                    {index < currentStep ? (
                      <Icon name="Check" size={20} />
                    ) : (
                      <span className="text-sm font-medium">{index + 1}</span>
                    )}
                  </div>
                  <div className="ml-3">
                    <div
                      className={`text-sm font-medium ${
                        index <= currentStep ? 'text-foreground' : 'text-muted-foreground'
                      }`}
                    >
                      {step?.title}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {step?.description}
                    </div>
                  </div>
                </div>
                
                {index < steps?.length - 1 && (
                  <div
                    className={`flex-1 h-0.5 mx-4 transition-all ${
                      index < currentStep ? 'bg-primary' : 'bg-border'
                    }`}
                    style={{ minWidth: '60px' }}
                  />
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProgressIndicator;