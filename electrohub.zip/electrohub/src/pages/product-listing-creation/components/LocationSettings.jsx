import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';
import { Checkbox } from '../../../components/ui/Checkbox';

const LocationSettings = ({ formData, onFormDataChange }) => {
  const [currentLocation, setCurrentLocation] = useState(null);
  const [locationLoading, setLocationLoading] = useState(false);

  const deliveryOptions = [
    { value: 'pickup-only', label: 'Pickup Only' },
    { value: 'delivery-available', label: 'Delivery Available' },
    { value: 'both', label: 'Both Pickup & Delivery' }
  ];

  const deliveryZones = [
    { value: '5', label: 'Within 5 miles' },
    { value: '10', label: 'Within 10 miles' },
    { value: '25', label: 'Within 25 miles' },
    { value: '50', label: 'Within 50 miles' },
    { value: 'custom', label: 'Custom area' }
  ];

  const stateOptions = [
    { value: 'ny', label: 'New York' },
    { value: 'ca', label: 'California' },
    { value: 'tx', label: 'Texas' },
    { value: 'fl', label: 'Florida' },
    { value: 'il', label: 'Illinois' },
    { value: 'pa', label: 'Pennsylvania' },
    { value: 'oh', label: 'Ohio' },
    { value: 'ga', label: 'Georgia' },
    { value: 'nc', label: 'North Carolina' },
    { value: 'mi', label: 'Michigan' }
  ];

  useEffect(() => {
    // Auto-populate with mock location data
    if (!formData?.address) {
      onFormDataChange({
        ...formData,
        address: '123 Main Street',
        city: 'New York',
        state: 'ny',
        zipCode: '10001',
        coordinates: { lat: 40.7128, lng: -74.0060 }
      });
    }
  }, []);

  const getCurrentLocation = () => {
    setLocationLoading(true);
    
    // Simulate geolocation API
    setTimeout(() => {
      const mockLocation = {
        address: '456 Broadway',
        city: 'New York',
        state: 'ny',
        zipCode: '10013',
        coordinates: { lat: 40.7589, lng: -73.9851 }
      };
      
      setCurrentLocation(mockLocation);
      onFormDataChange({
        ...formData,
        ...mockLocation
      });
      setLocationLoading(false);
    }, 2000);
  };

  const handleFieldChange = (field, value) => {
    onFormDataChange({
      ...formData,
      [field]: value
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-foreground mb-2">Location & Delivery</h3>
        <p className="text-sm text-muted-foreground">Set your pickup location and delivery options</p>
      </div>
      {/* Current Location Detection */}
      <div className="bg-card border border-border rounded-lg p-4">
        <div className="flex items-center justify-between mb-3">
          <h4 className="font-medium text-foreground">Pickup Location</h4>
          <Button
            variant="outline"
            size="sm"
            onClick={getCurrentLocation}
            loading={locationLoading}
            iconName="MapPin"
            iconPosition="left"
          >
            Use Current Location
          </Button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input
            label="Street Address"
            type="text"
            placeholder="123 Main Street"
            value={formData?.address || ''}
            onChange={(e) => handleFieldChange('address', e?.target?.value)}
            required
          />
          <Input
            label="City"
            type="text"
            placeholder="New York"
            value={formData?.city || ''}
            onChange={(e) => handleFieldChange('city', e?.target?.value)}
            required
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          <Select
            label="State"
            placeholder="Select state"
            options={stateOptions}
            value={formData?.state || ''}
            onChange={(value) => handleFieldChange('state', value)}
            searchable
            required
          />
          <Input
            label="ZIP Code"
            type="text"
            placeholder="10001"
            value={formData?.zipCode || ''}
            onChange={(e) => handleFieldChange('zipCode', e?.target?.value)}
            required
          />
        </div>
      </div>
      {/* Map Preview */}
      {formData?.coordinates && (
        <div className="bg-card border border-border rounded-lg overflow-hidden">
          <div className="h-48 bg-muted relative">
            <iframe
              width="100%"
              height="100%"
              loading="lazy"
              title="Pickup Location"
              referrerPolicy="no-referrer-when-downgrade"
              src={`https://www.google.com/maps?q=${formData?.coordinates?.lat},${formData?.coordinates?.lng}&z=14&output=embed`}
              className="border-0"
            />
            <div className="absolute top-3 left-3 bg-white px-2 py-1 rounded shadow-sm">
              <span className="text-xs font-medium text-foreground">Pickup Location</span>
            </div>
          </div>
        </div>
      )}
      {/* Delivery Options */}
      <div className="space-y-4">
        <h4 className="font-medium text-foreground">Delivery Options</h4>
        <Select
          label="Delivery Method"
          placeholder="Select delivery option"
          options={deliveryOptions}
          value={formData?.deliveryMethod || ''}
          onChange={(value) => handleFieldChange('deliveryMethod', value)}
          required
        />

        {(formData?.deliveryMethod === 'delivery-available' || formData?.deliveryMethod === 'both') && (
          <div className="space-y-4 pl-4 border-l-2 border-primary/20">
            <Select
              label="Delivery Zone"
              placeholder="Select delivery area"
              options={deliveryZones}
              value={formData?.deliveryZone || ''}
              onChange={(value) => handleFieldChange('deliveryZone', value)}
            />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                label="Delivery Fee (USD)"
                type="number"
                placeholder="15.00"
                value={formData?.deliveryFee || ''}
                onChange={(e) => handleFieldChange('deliveryFee', e?.target?.value)}
                min="0"
                step="0.01"
              />
              <Input
                label="Free Delivery Above (USD)"
                type="number"
                placeholder="100.00"
                value={formData?.freeDeliveryThreshold || ''}
                onChange={(e) => handleFieldChange('freeDeliveryThreshold', e?.target?.value)}
                min="0"
                step="0.01"
                description="Optional minimum order for free delivery"
              />
            </div>

            <div className="space-y-2">
              <Checkbox
                label="Same-day delivery available"
                checked={formData?.sameDayDelivery || false}
                onChange={(e) => handleFieldChange('sameDayDelivery', e?.target?.checked)}
              />
              <Checkbox
                label="Weekend delivery available"
                checked={formData?.weekendDelivery || false}
                onChange={(e) => handleFieldChange('weekendDelivery', e?.target?.checked)}
              />
              <Checkbox
                label="Evening delivery available (6-9 PM)"
                checked={formData?.eveningDelivery || false}
                onChange={(e) => handleFieldChange('eveningDelivery', e?.target?.checked)}
              />
            </div>
          </div>
        )}
      </div>
      {/* Special Instructions */}
      <div className="space-y-3">
        <h4 className="font-medium text-foreground">Special Instructions</h4>
        <Input
          type="text"
          placeholder="Any special pickup or delivery instructions..."
          value={formData?.specialInstructions || ''}
          onChange={(e) => handleFieldChange('specialInstructions', e?.target?.value)}
          description="Building access codes, parking instructions, etc."
        />
      </div>
      {/* Safety Notice */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-start space-x-3">
          <Icon name="Shield" size={20} className="text-blue-600 mt-0.5" />
          <div>
            <h5 className="font-medium text-blue-900">Safety Guidelines</h5>
            <ul className="text-sm text-blue-700 mt-1 space-y-1">
              <li>• Meet in public places for pickup transactions</li>
              <li>• Verify buyer identity before delivery</li>
              <li>• Use ElectroHub's secure payment system</li>
              <li>• Report any suspicious activity immediately</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LocationSettings;