import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const PriceEstimationSidebar = ({ formData, isVisible, onToggle }) => {
  const [estimation, setEstimation] = useState(null);
  const [loading, setLoading] = useState(false);
  const [marketData, setMarketData] = useState(null);

  useEffect(() => {
    if (formData?.productName && formData?.condition && formData?.brand) {
      generateEstimation();
    }
  }, [formData?.productName, formData?.condition, formData?.brand, formData?.yearOfPurchase]);

  const generateEstimation = () => {
    setLoading(true);
    
    // Simulate AI price estimation
    setTimeout(() => {
      const basePrice = formData?.originalPrice ? parseFloat(formData?.originalPrice) : 500;
      const currentYear = new Date()?.getFullYear();
      const age = formData?.yearOfPurchase ? currentYear - parseInt(formData?.yearOfPurchase) : 1;
      
      // Condition multipliers
      const conditionMultipliers = {
        'excellent': 0.85,
        'very-good': 0.75,
        'good': 0.65,
        'fair': 0.50,
        'poor': 0.35
      };
      
      // Age depreciation
      const ageMultiplier = Math.max(0.3, 1 - (age * 0.15));
      
      const conditionMultiplier = conditionMultipliers?.[formData?.condition] || 0.65;
      const estimatedPrice = basePrice * conditionMultiplier * ageMultiplier;
      
      const lowRange = Math.round(estimatedPrice * 0.85);
      const highRange = Math.round(estimatedPrice * 1.15);
      
      setEstimation({
        suggested: Math.round(estimatedPrice),
        range: { low: lowRange, high: highRange },
        confidence: 85,
        factors: {
          condition: formData?.condition,
          age: age,
          brand: formData?.brand,
          demand: 'High'
        }
      });
      
      setMarketData({
        recentSales: [
          { price: lowRange + 50, date: '2 days ago', condition: 'very-good' },
          { price: estimatedPrice - 30, date: '1 week ago', condition: 'good' },
          { price: highRange - 20, date: '2 weeks ago', condition: 'excellent' }
        ],
        averagePrice: Math.round(estimatedPrice),
        totalListings: 23,
        soldLastMonth: 8
      });
      
      setLoading(false);
    }, 1500);
  };

  if (!isVisible) {
    return (
      <div className="fixed right-4 top-1/2 transform -translate-y-1/2 z-50 lg:hidden">
        <Button
          variant="primary"
          size="icon"
          onClick={onToggle}
          className="rounded-full shadow-lg"
        >
          <Icon name="DollarSign" size={20} />
        </Button>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 z-50 lg:relative lg:inset-auto lg:bg-transparent lg:z-auto">
      <div className="absolute right-0 top-0 h-full w-full max-w-sm bg-card border-l border-border lg:relative lg:max-w-none lg:w-80">
        <div className="h-full overflow-y-auto">
          {/* Header */}
          <div className="sticky top-0 bg-card border-b border-border p-4 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Icon name="Sparkles" size={20} className="text-primary" />
              <h3 className="font-semibold text-foreground">AI Price Estimation</h3>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={onToggle}
              className="lg:hidden"
            >
              <Icon name="X" size={20} />
            </Button>
          </div>

          <div className="p-4 space-y-6">
            {loading ? (
              <div className="text-center py-8">
                <div className="animate-spin w-8 h-8 border-2 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
                <p className="text-sm text-muted-foreground">Analyzing your product...</p>
              </div>
            ) : estimation ? (
              <>
                {/* Price Estimation */}
                <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary mb-1">
                      ${estimation?.suggested}
                    </div>
                    <div className="text-sm text-muted-foreground mb-3">
                      Suggested Price
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Range: ${estimation?.range?.low} - ${estimation?.range?.high}
                    </div>
                  </div>
                  
                  <div className="mt-4 flex items-center justify-center space-x-2">
                    <Icon name="TrendingUp" size={16} className="text-green-600" />
                    <span className="text-sm text-green-600 font-medium">
                      {estimation?.confidence}% Confidence
                    </span>
                  </div>
                </div>

                {/* Pricing Factors */}
                <div className="space-y-3">
                  <h4 className="font-medium text-foreground">Pricing Factors</h4>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Condition</span>
                      <span className="font-medium capitalize">{estimation?.factors?.condition}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Age</span>
                      <span className="font-medium">{estimation?.factors?.age} years</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Brand</span>
                      <span className="font-medium capitalize">{estimation?.factors?.brand}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Market Demand</span>
                      <span className="font-medium text-green-600">{estimation?.factors?.demand}</span>
                    </div>
                  </div>
                </div>

                {/* Market Data */}
                {marketData && (
                  <div className="space-y-3">
                    <h4 className="font-medium text-foreground">Market Insights</h4>
                    <div className="bg-muted/50 rounded-lg p-3">
                      <div className="grid grid-cols-2 gap-3 text-center">
                        <div>
                          <div className="text-lg font-semibold text-foreground">
                            ${marketData?.averagePrice}
                          </div>
                          <div className="text-xs text-muted-foreground">Avg. Price</div>
                        </div>
                        <div>
                          <div className="text-lg font-semibold text-foreground">
                            {marketData?.soldLastMonth}
                          </div>
                          <div className="text-xs text-muted-foreground">Sold/Month</div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <h5 className="text-sm font-medium text-foreground">Recent Sales</h5>
                      {marketData?.recentSales?.map((sale, index) => (
                        <div key={index} className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">{sale?.date}</span>
                          <div className="text-right">
                            <div className="font-medium">${sale?.price}</div>
                            <div className="text-xs text-muted-foreground capitalize">
                              {sale?.condition}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Pricing Tips */}
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                  <div className="flex items-start space-x-2">
                    <Icon name="Lightbulb" size={16} className="text-blue-600 mt-0.5" />
                    <div>
                      <h5 className="text-sm font-medium text-blue-900">Pricing Tips</h5>
                      <ul className="text-xs text-blue-700 mt-1 space-y-1">
                        <li>• Price competitively for faster sales</li>
                        <li>• Consider seasonal demand patterns</li>
                        <li>• Include original accessories for higher value</li>
                        <li>• High-quality photos increase perceived value</li>
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="space-y-2">
                  <Button
                    variant="primary"
                    fullWidth
                    onClick={() => {
                      // Apply suggested price to form
                      console.log('Apply suggested price:', estimation?.suggested);
                    }}
                  >
                    Use Suggested Price
                  </Button>
                  <Button
                    variant="outline"
                    fullWidth
                    onClick={generateEstimation}
                    iconName="RefreshCw"
                    iconPosition="left"
                  >
                    Refresh Estimation
                  </Button>
                </div>
              </>
            ) : (
              <div className="text-center py-8">
                <Icon name="Calculator" size={48} className="mx-auto text-muted-foreground mb-4" />
                <p className="text-sm text-muted-foreground">
                  Fill in product details to get AI-powered price estimation
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PriceEstimationSidebar;