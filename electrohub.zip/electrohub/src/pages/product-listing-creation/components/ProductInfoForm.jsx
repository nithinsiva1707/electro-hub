import React, { useState } from 'react';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const ProductInfoForm = ({ formData, onFormDataChange }) => {
  const [suggestions] = useState([
    'iPhone 15 Pro Max',
    'Samsung Galaxy S24',
    'MacBook Pro M3',
    'Dell XPS 13',
    'Sony WH-1000XM5',
    'iPad Air',
    'Nintendo Switch OLED'
  ]);

  const brandOptions = [
    { value: 'apple', label: 'Apple' },
    { value: 'samsung', label: 'Samsung' },
    { value: 'sony', label: 'Sony' },
    { value: 'lg', label: 'LG' },
    { value: 'dell', label: 'Dell' },
    { value: 'hp', label: 'HP' },
    { value: 'lenovo', label: 'Lenovo' },
    { value: 'microsoft', label: 'Microsoft' },
    { value: 'nintendo', label: 'Nintendo' },
    { value: 'other', label: 'Other' }
  ];

  const modelOptions = {
    apple: [
      { value: 'iphone-15-pro-max', label: 'iPhone 15 Pro Max' },
      { value: 'iphone-15-pro', label: 'iPhone 15 Pro' },
      { value: 'iphone-15', label: 'iPhone 15' },
      { value: 'macbook-pro-m3', label: 'MacBook Pro M3' },
      { value: 'ipad-air', label: 'iPad Air' },
      { value: 'apple-watch-series-9', label: 'Apple Watch Series 9' }
    ],
    samsung: [
      { value: 'galaxy-s24-ultra', label: 'Galaxy S24 Ultra' },
      { value: 'galaxy-s24', label: 'Galaxy S24' },
      { value: 'galaxy-tab-s9', label: 'Galaxy Tab S9' },
      { value: 'galaxy-watch-6', label: 'Galaxy Watch 6' }
    ],
    sony: [
      { value: 'wh-1000xm5', label: 'WH-1000XM5' },
      { value: 'playstation-5', label: 'PlayStation 5' },
      { value: 'bravia-x90l', label: 'BRAVIA X90L' }
    ]
  };

  const handleInputChange = (field, value) => {
    onFormDataChange({
      ...formData,
      [field]: value
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-foreground mb-2">Product Information</h3>
        <p className="text-sm text-muted-foreground">Provide details about your product</p>
      </div>
      <div className="space-y-4">
        <Input
          label="Product Name"
          type="text"
          placeholder="Enter product name"
          value={formData?.productName || ''}
          onChange={(e) => handleInputChange('productName', e?.target?.value)}
          description="Be specific and include model details"
          required
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Select
            label="Brand"
            placeholder="Select brand"
            options={brandOptions}
            value={formData?.brand || ''}
            onChange={(value) => handleInputChange('brand', value)}
            searchable
            required
          />

          <Select
            label="Model"
            placeholder="Select model"
            options={formData?.brand ? (modelOptions?.[formData?.brand] || []) : []}
            value={formData?.model || ''}
            onChange={(value) => handleInputChange('model', value)}
            disabled={!formData?.brand}
            searchable
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input
            label="Year of Purchase"
            type="number"
            placeholder="2024"
            value={formData?.yearOfPurchase || ''}
            onChange={(e) => handleInputChange('yearOfPurchase', e?.target?.value)}
            min="2000"
            max="2025"
          />

          <Input
            label="Original Price (USD)"
            type="number"
            placeholder="999.00"
            value={formData?.originalPrice || ''}
            onChange={(e) => handleInputChange('originalPrice', e?.target?.value)}
            min="0"
            step="0.01"
          />
        </div>

        <Input
          label="Product Description"
          type="text"
          placeholder="Describe your product's features and condition"
          value={formData?.description || ''}
          onChange={(e) => handleInputChange('description', e?.target?.value)}
          description="Include any accessories, original packaging, or special features"
        />

        {/* Auto-complete suggestions */}
        {formData?.productName && formData?.productName?.length > 2 && (
          <div className="bg-card border border-border rounded-lg p-3">
            <h4 className="text-sm font-medium text-foreground mb-2">Suggestions</h4>
            <div className="space-y-1">
              {suggestions?.filter(suggestion => 
                  suggestion?.toLowerCase()?.includes(formData?.productName?.toLowerCase())
                )?.slice(0, 3)?.map((suggestion, index) => (
                  <button
                    key={index}
                    onClick={() => handleInputChange('productName', suggestion)}
                    className="block w-full text-left px-2 py-1 text-sm text-muted-foreground hover:text-foreground hover:bg-muted rounded transition-smooth"
                  >
                    {suggestion}
                  </button>
                ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductInfoForm;