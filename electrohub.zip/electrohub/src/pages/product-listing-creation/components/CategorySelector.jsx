import React from 'react';
import Icon from '../../../components/AppIcon';

const CategorySelector = ({ selectedCategory, onCategorySelect }) => {
  const categories = [
    {
      id: 'personal-gadgets',
      name: 'Personal Gadgets',
      icon: 'Smartphone',
      description: 'Phones, tablets, wearables',
      color: 'bg-blue-50 border-blue-200 text-blue-700'
    },
    {
      id: 'home-appliances',
      name: 'Home & Kitchen Appliances',
      icon: 'Home',
      description: 'Refrigerators, washing machines, microwaves',
      color: 'bg-green-50 border-green-200 text-green-700'
    },
    {
      id: 'office-electronics',
      name: 'Office Electronics',
      icon: 'Monitor',
      description: 'Computers, printers, projectors',
      color: 'bg-purple-50 border-purple-200 text-purple-700'
    },
    {
      id: 'entertainment',
      name: 'Entertainment Devices',
      icon: 'Tv',
      description: 'TVs, gaming consoles, speakers',
      color: 'bg-orange-50 border-orange-200 text-orange-700'
    }
  ];

  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-lg font-semibold text-foreground mb-2">Select Category</h3>
        <p className="text-sm text-muted-foreground">Choose the category that best describes your product</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {categories?.map((category) => (
          <button
            key={category?.id}
            onClick={() => onCategorySelect(category?.id)}
            className={`p-4 border-2 rounded-lg text-left transition-all hover:shadow-md ${
              selectedCategory === category?.id
                ? 'border-primary bg-primary/5' :'border-border hover:border-primary/50'
            }`}
          >
            <div className="flex items-start space-x-3">
              <div className={`p-2 rounded-lg ${category?.color}`}>
                <Icon name={category?.icon} size={24} />
              </div>
              <div className="flex-1">
                <h4 className="font-medium text-foreground">{category?.name}</h4>
                <p className="text-sm text-muted-foreground mt-1">{category?.description}</p>
              </div>
              {selectedCategory === category?.id && (
                <Icon name="Check" size={20} className="text-primary" />
              )}
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};

export default CategorySelector;