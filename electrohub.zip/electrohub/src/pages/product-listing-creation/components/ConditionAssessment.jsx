import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { Checkbox } from '../../../components/ui/Checkbox';

const ConditionAssessment = ({ formData, onFormDataChange }) => {
  const [uploadedImages, setUploadedImages] = useState([]);
  const [dragOver, setDragOver] = useState(false);

  const conditionOptions = [
    {
      value: 'excellent',
      label: 'Excellent',
      description: 'Like new, no visible wear',
      color: 'text-green-600'
    },
    {
      value: 'very-good',
      label: 'Very Good',
      description: 'Minor signs of use',
      color: 'text-blue-600'
    },
    {
      value: 'good',
      label: 'Good',
      description: 'Normal wear, fully functional',
      color: 'text-yellow-600'
    },
    {
      value: 'fair',
      label: 'Fair',
      description: 'Noticeable wear, works well',
      color: 'text-orange-600'
    },
    {
      value: 'poor',
      label: 'Poor',
      description: 'Heavy wear, may need repair',
      color: 'text-red-600'
    }
  ];

  const functionalityChecks = [
    { id: 'powers-on', label: 'Powers on normally' },
    { id: 'all-functions', label: 'All functions work properly' },
    { id: 'no-damage', label: 'No physical damage' },
    { id: 'original-accessories', label: 'Includes original accessories' },
    { id: 'original-packaging', label: 'Has original packaging' },
    { id: 'warranty-valid', label: 'Warranty still valid' }
  ];

  const handleConditionSelect = (condition) => {
    onFormDataChange({
      ...formData,
      condition: condition
    });
  };

  const handleFunctionalityChange = (checkId, checked) => {
    const currentChecks = formData?.functionalityChecks || [];
    const updatedChecks = checked
      ? [...currentChecks, checkId]
      : currentChecks?.filter(id => id !== checkId);
    
    onFormDataChange({
      ...formData,
      functionalityChecks: updatedChecks
    });
  };

  const handleImageUpload = (files) => {
    const newImages = Array.from(files)?.map((file, index) => ({
      id: Date.now() + index,
      file,
      url: URL.createObjectURL(file),
      name: file?.name
    }));
    
    const updatedImages = [...uploadedImages, ...newImages];
    setUploadedImages(updatedImages);
    
    onFormDataChange({
      ...formData,
      images: updatedImages
    });
  };

  const handleDrop = (e) => {
    e?.preventDefault();
    setDragOver(false);
    const files = e?.dataTransfer?.files;
    handleImageUpload(files);
  };

  const handleDragOver = (e) => {
    e?.preventDefault();
    setDragOver(true);
  };

  const handleDragLeave = (e) => {
    e?.preventDefault();
    setDragOver(false);
  };

  const removeImage = (imageId) => {
    const updatedImages = uploadedImages?.filter(img => img?.id !== imageId);
    setUploadedImages(updatedImages);
    
    onFormDataChange({
      ...formData,
      images: updatedImages
    });
  };

  const reorderImages = (fromIndex, toIndex) => {
    const updatedImages = [...uploadedImages];
    const [movedImage] = updatedImages?.splice(fromIndex, 1);
    updatedImages?.splice(toIndex, 0, movedImage);
    
    setUploadedImages(updatedImages);
    onFormDataChange({
      ...formData,
      images: updatedImages
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-foreground mb-2">Condition Assessment</h3>
        <p className="text-sm text-muted-foreground">Help us understand your product's condition</p>
      </div>
      {/* Condition Selection */}
      <div className="space-y-4">
        <h4 className="font-medium text-foreground">Overall Condition</h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {conditionOptions?.map((option) => (
            <button
              key={option?.value}
              onClick={() => handleConditionSelect(option?.value)}
              className={`p-4 border-2 rounded-lg text-left transition-all hover:shadow-md ${
                formData?.condition === option?.value
                  ? 'border-primary bg-primary/5' :'border-border hover:border-primary/50'
              }`}
            >
              <div className={`font-medium ${option?.color}`}>{option?.label}</div>
              <div className="text-sm text-muted-foreground mt-1">{option?.description}</div>
              {formData?.condition === option?.value && (
                <Icon name="Check" size={16} className="text-primary mt-2" />
              )}
            </button>
          ))}
        </div>
      </div>
      {/* Functionality Checks */}
      <div className="space-y-4">
        <h4 className="font-medium text-foreground">Functionality Check</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {functionalityChecks?.map((check) => (
            <Checkbox
              key={check?.id}
              label={check?.label}
              checked={(formData?.functionalityChecks || [])?.includes(check?.id)}
              onChange={(e) => handleFunctionalityChange(check?.id, e?.target?.checked)}
            />
          ))}
        </div>
      </div>
      {/* Image Upload */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h4 className="font-medium text-foreground">Product Photos</h4>
          <span className="text-sm text-muted-foreground">
            {uploadedImages?.length}/10 photos
          </span>
        </div>
        
        <div
          className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
            dragOver
              ? 'border-primary bg-primary/5' :'border-border hover:border-primary/50'
          }`}
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
        >
          <Icon name="Upload" size={48} className="mx-auto text-muted-foreground mb-4" />
          <h5 className="font-medium text-foreground mb-2">Upload Product Photos</h5>
          <p className="text-sm text-muted-foreground mb-4">
            Drag and drop photos here, or click to browse
          </p>
          <input
            type="file"
            multiple
            accept="image/*"
            onChange={(e) => handleImageUpload(e?.target?.files)}
            className="hidden"
            id="image-upload"
          />
          <Button
            variant="outline"
            onClick={() => document.getElementById('image-upload')?.click()}
            iconName="Camera"
            iconPosition="left"
          >
            Choose Photos
          </Button>
        </div>

        {/* Image Gallery */}
        {uploadedImages?.length > 0 && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {uploadedImages?.map((image, index) => (
              <div key={image?.id} className="relative group">
                <div className="aspect-square bg-muted rounded-lg overflow-hidden">
                  <img
                    src={image?.url}
                    alt={`Product photo ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                </div>
                <button
                  onClick={() => removeImage(image?.id)}
                  className="absolute -top-2 -right-2 w-6 h-6 bg-error text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <Icon name="X" size={14} />
                </button>
                {index === 0 && (
                  <div className="absolute bottom-2 left-2 bg-primary text-white text-xs px-2 py-1 rounded">
                    Main
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
      {/* AI Analysis Preview */}
      {formData?.condition && uploadedImages?.length > 0 && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-start space-x-3">
            <Icon name="Sparkles" size={20} className="text-blue-600 mt-0.5" />
            <div>
              <h5 className="font-medium text-blue-900">AI Analysis</h5>
              <p className="text-sm text-blue-700 mt-1">
                Based on your photos and condition assessment, we estimate this item is in{' '}
                <span className="font-medium">{formData?.condition}</span> condition.
                Our AI suggests a market value range of $450 - $550.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ConditionAssessment;