import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';

const ListingTypeSelector = ({ formData, onFormDataChange }) => {
  const [showCalendar, setShowCalendar] = useState(false);

  const listingTypes = [
    {
      value: 'sell',
      label: 'Sell',
      icon: 'DollarSign',
      description: 'Sell your item permanently',
      color: 'bg-green-50 border-green-200 text-green-700'
    },
    {
      value: 'rent',
      label: 'Rent',
      icon: 'Calendar',
      description: 'Rent out for temporary use',
      color: 'bg-blue-50 border-blue-200 text-blue-700'
    },
    {
      value: 'auction',
      label: 'Auction',
      icon: 'Gavel',
      description: 'Let buyers bid on your item',
      color: 'bg-purple-50 border-purple-200 text-purple-700'
    }
  ];

  const durationOptions = [
    { value: '1', label: '1 day' },
    { value: '3', label: '3 days' },
    { value: '5', label: '5 days' },
    { value: '7', label: '7 days' },
    { value: '10', label: '10 days' }
  ];

  const rentalPeriodOptions = [
    { value: 'daily', label: 'Daily' },
    { value: 'weekly', label: 'Weekly' },
    { value: 'monthly', label: 'Monthly' }
  ];

  const insuranceOptions = [
    { value: 'basic', label: 'Basic Protection ($5/day)', price: 5 },
    { value: 'premium', label: 'Premium Protection ($10/day)', price: 10 },
    { value: 'comprehensive', label: 'Comprehensive Protection ($15/day)', price: 15 }
  ];

  const handleListingTypeChange = (type) => {
    onFormDataChange({
      ...formData,
      listingType: type,
      // Reset type-specific fields when changing type
      price: '',
      reservePrice: '',
      auctionDuration: '',
      rentalPrice: '',
      rentalPeriod: '',
      availabilityDates: [],
      insuranceOptions: []
    });
  };

  const handleFieldChange = (field, value) => {
    onFormDataChange({
      ...formData,
      [field]: value
    });
  };

  const handleInsuranceChange = (option, checked) => {
    const currentOptions = formData?.insuranceOptions || [];
    const updatedOptions = checked
      ? [...currentOptions, option]
      : currentOptions?.filter(opt => opt !== option);
    
    handleFieldChange('insuranceOptions', updatedOptions);
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-foreground mb-2">Listing Type</h3>
        <p className="text-sm text-muted-foreground">Choose how you want to list your product</p>
      </div>
      {/* Listing Type Selection */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {listingTypes?.map((type) => (
          <button
            key={type?.value}
            onClick={() => handleListingTypeChange(type?.value)}
            className={`p-4 border-2 rounded-lg text-center transition-all hover:shadow-md ${
              formData?.listingType === type?.value
                ? 'border-primary bg-primary/5' :'border-border hover:border-primary/50'
            }`}
          >
            <div className={`inline-flex p-3 rounded-lg mb-3 ${type?.color}`}>
              <Icon name={type?.icon} size={24} />
            </div>
            <h4 className="font-medium text-foreground">{type?.label}</h4>
            <p className="text-sm text-muted-foreground mt-1">{type?.description}</p>
            {formData?.listingType === type?.value && (
              <Icon name="Check" size={16} className="text-primary mt-2 mx-auto" />
            )}
          </button>
        ))}
      </div>
      {/* Dynamic Form Fields Based on Listing Type */}
      {formData?.listingType === 'sell' && (
        <div className="space-y-4">
          <h4 className="font-medium text-foreground">Sale Details</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input
              label="Selling Price (USD)"
              type="number"
              placeholder="499.00"
              value={formData?.price || ''}
              onChange={(e) => handleFieldChange('price', e?.target?.value)}
              min="0"
              step="0.01"
              required
            />
            <div className="flex items-end">
              <Checkbox
                label="Accept offers"
                checked={formData?.acceptOffers || false}
                onChange={(e) => handleFieldChange('acceptOffers', e?.target?.checked)}
              />
            </div>
          </div>
        </div>
      )}
      {formData?.listingType === 'rent' && (
        <div className="space-y-4">
          <h4 className="font-medium text-foreground">Rental Details</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input
              label="Rental Price (USD)"
              type="number"
              placeholder="25.00"
              value={formData?.rentalPrice || ''}
              onChange={(e) => handleFieldChange('rentalPrice', e?.target?.value)}
              min="0"
              step="0.01"
              required
            />
            <Select
              label="Rental Period"
              placeholder="Select period"
              options={rentalPeriodOptions}
              value={formData?.rentalPeriod || ''}
              onChange={(value) => handleFieldChange('rentalPeriod', value)}
              required
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input
              label="Security Deposit (USD)"
              type="number"
              placeholder="100.00"
              value={formData?.securityDeposit || ''}
              onChange={(e) => handleFieldChange('securityDeposit', e?.target?.value)}
              min="0"
              step="0.01"
            />
            <Input
              label="Minimum Rental Period"
              type="number"
              placeholder="1"
              value={formData?.minRentalPeriod || ''}
              onChange={(e) => handleFieldChange('minRentalPeriod', e?.target?.value)}
              min="1"
            />
          </div>

          {/* Insurance Options */}
          <div className="space-y-3">
            <h5 className="font-medium text-foreground">Insurance Options</h5>
            {insuranceOptions?.map((option) => (
              <Checkbox
                key={option?.value}
                label={option?.label}
                checked={(formData?.insuranceOptions || [])?.includes(option?.value)}
                onChange={(e) => handleInsuranceChange(option?.value, e?.target?.checked)}
              />
            ))}
          </div>

          {/* Calendar Availability */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h5 className="font-medium text-foreground">Availability Calendar</h5>
              <button
                onClick={() => setShowCalendar(!showCalendar)}
                className="text-primary hover:text-primary/80 text-sm font-medium"
              >
                {showCalendar ? 'Hide Calendar' : 'Set Availability'}
              </button>
            </div>
            
            {showCalendar && (
              <div className="bg-muted/50 border border-border rounded-lg p-4">
                <p className="text-sm text-muted-foreground mb-3">
                  Select dates when your item will be available for rent
                </p>
                <div className="grid grid-cols-7 gap-1 text-center text-sm">
                  {/* Calendar placeholder - would integrate with a date picker library */}
                  <div className="font-medium text-muted-foreground p-2">Sun</div>
                  <div className="font-medium text-muted-foreground p-2">Mon</div>
                  <div className="font-medium text-muted-foreground p-2">Tue</div>
                  <div className="font-medium text-muted-foreground p-2">Wed</div>
                  <div className="font-medium text-muted-foreground p-2">Thu</div>
                  <div className="font-medium text-muted-foreground p-2">Fri</div>
                  <div className="font-medium text-muted-foreground p-2">Sat</div>
                  
                  {Array.from({ length: 35 }, (_, i) => (
                    <button
                      key={i}
                      className="p-2 hover:bg-primary/10 rounded transition-colors"
                    >
                      {i + 1 <= 30 ? i + 1 : ''}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
      {formData?.listingType === 'auction' && (
        <div className="space-y-4">
          <h4 className="font-medium text-foreground">Auction Details</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input
              label="Starting Bid (USD)"
              type="number"
              placeholder="100.00"
              value={formData?.startingBid || ''}
              onChange={(e) => handleFieldChange('startingBid', e?.target?.value)}
              min="0"
              step="0.01"
              required
            />
            <Input
              label="Reserve Price (USD)"
              type="number"
              placeholder="300.00"
              value={formData?.reservePrice || ''}
              onChange={(e) => handleFieldChange('reservePrice', e?.target?.value)}
              min="0"
              step="0.01"
              description="Minimum price you'll accept"
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Select
              label="Auction Duration"
              placeholder="Select duration"
              options={durationOptions}
              value={formData?.auctionDuration || ''}
              onChange={(value) => handleFieldChange('auctionDuration', value)}
              required
            />
            <Input
              label="Buy It Now Price (USD)"
              type="number"
              placeholder="450.00"
              value={formData?.buyItNowPrice || ''}
              onChange={(e) => handleFieldChange('buyItNowPrice', e?.target?.value)}
              min="0"
              step="0.01"
              description="Optional instant purchase price"
            />
          </div>

          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <div className="flex items-start space-x-3">
              <Icon name="Info" size={20} className="text-yellow-600 mt-0.5" />
              <div>
                <h5 className="font-medium text-yellow-900">Auction Guidelines</h5>
                <ul className="text-sm text-yellow-700 mt-1 space-y-1">
                  <li>• Auctions cannot be cancelled once a bid is placed</li>
                  <li>• Reserve price is hidden from bidders</li>
                  <li>• Buy It Now option disappears after first bid</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ListingTypeSelector;