import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { Checkbox } from '../../../components/ui/Checkbox';

const ReviewAndSubmit = ({ formData, onEdit, onSubmit }) => {
  const [agreed, setAgreed] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const getCategoryName = (categoryId) => {
    const categories = {
      'personal-gadgets': 'Personal Gadgets',
      'home-appliances': 'Home & Kitchen Appliances',
      'office-electronics': 'Office Electronics',
      'entertainment': 'Entertainment Devices'
    };
    return categories?.[categoryId] || categoryId;
  };

  const getConditionLabel = (condition) => {
    const conditions = {
      'excellent': 'Excellent',
      'very-good': 'Very Good',
      'good': 'Good',
      'fair': 'Fair',
      'poor': 'Poor'
    };
    return conditions?.[condition] || condition;
  };

  const getListingTypeLabel = (type) => {
    const types = {
      'sell': 'For Sale',
      'rent': 'For Rent',
      'auction': 'Auction'
    };
    return types?.[type] || type;
  };

  const handleSubmit = async () => {
    if (!agreed) return;
    
    setSubmitting(true);
    
    // Simulate form submission
    setTimeout(() => {
      onSubmit(formData);
      setSubmitting(false);
    }, 2000);
  };

  const formatPrice = (price) => {
    return price ? `$${parseFloat(price)?.toFixed(2)}` : 'Not specified';
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-foreground mb-2">Review Your Listing</h3>
        <p className="text-sm text-muted-foreground">Please review all details before submitting</p>
      </div>
      {/* Product Overview */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <h4 className="text-xl font-semibold text-foreground mb-2">
              {formData?.productName || 'Product Name'}
            </h4>
            <div className="flex items-center space-x-4 text-sm text-muted-foreground">
              <span>{getCategoryName(formData?.category)}</span>
              <span>•</span>
              <span className="capitalize">{formData?.brand}</span>
              <span>•</span>
              <span>{getConditionLabel(formData?.condition)}</span>
            </div>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => onEdit(0)}
            iconName="Edit"
            iconPosition="left"
          >
            Edit
          </Button>
        </div>

        {/* Images Preview */}
        {formData?.images && formData?.images?.length > 0 && (
          <div className="mb-4">
            <div className="flex space-x-2 overflow-x-auto pb-2">
              {formData?.images?.slice(0, 4)?.map((image, index) => (
                <div key={index} className="flex-shrink-0 w-20 h-20 bg-muted rounded-lg overflow-hidden">
                  <img
                    src={image?.url}
                    alt={`Product ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                </div>
              ))}
              {formData?.images?.length > 4 && (
                <div className="flex-shrink-0 w-20 h-20 bg-muted rounded-lg flex items-center justify-center">
                  <span className="text-xs text-muted-foreground">
                    +{formData?.images?.length - 4}
                  </span>
                </div>
              )}
            </div>
          </div>
        )}

        <p className="text-sm text-muted-foreground">
          {formData?.description || 'No description provided'}
        </p>
      </div>
      {/* Listing Details */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Pricing Information */}
        <div className="bg-card border border-border rounded-lg p-4">
          <div className="flex items-center justify-between mb-3">
            <h5 className="font-medium text-foreground">Pricing & Type</h5>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onEdit(2)}
              iconName="Edit"
              iconSize={14}
            />
          </div>
          
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Listing Type:</span>
              <span className="font-medium">{getListingTypeLabel(formData?.listingType)}</span>
            </div>
            
            {formData?.listingType === 'sell' && (
              <>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Price:</span>
                  <span className="font-medium">{formatPrice(formData?.price)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Accept Offers:</span>
                  <span className="font-medium">{formData?.acceptOffers ? 'Yes' : 'No'}</span>
                </div>
              </>
            )}
            
            {formData?.listingType === 'rent' && (
              <>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Rental Price:</span>
                  <span className="font-medium">{formatPrice(formData?.rentalPrice)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Period:</span>
                  <span className="font-medium capitalize">{formData?.rentalPeriod}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Security Deposit:</span>
                  <span className="font-medium">{formatPrice(formData?.securityDeposit)}</span>
                </div>
              </>
            )}
            
            {formData?.listingType === 'auction' && (
              <>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Starting Bid:</span>
                  <span className="font-medium">{formatPrice(formData?.startingBid)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Reserve Price:</span>
                  <span className="font-medium">{formatPrice(formData?.reservePrice)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Duration:</span>
                  <span className="font-medium">{formData?.auctionDuration} days</span>
                </div>
              </>
            )}
          </div>
        </div>

        {/* Location & Delivery */}
        <div className="bg-card border border-border rounded-lg p-4">
          <div className="flex items-center justify-between mb-3">
            <h5 className="font-medium text-foreground">Location & Delivery</h5>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onEdit(3)}
              iconName="Edit"
              iconSize={14}
            />
          </div>
          
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Location:</span>
              <span className="font-medium">
                {formData?.city}, {formData?.state?.toUpperCase()}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Delivery:</span>
              <span className="font-medium capitalize">
                {formData?.deliveryMethod?.replace('-', ' ')}
              </span>
            </div>
            {formData?.deliveryFee && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">Delivery Fee:</span>
                <span className="font-medium">{formatPrice(formData?.deliveryFee)}</span>
              </div>
            )}
          </div>
        </div>
      </div>
      {/* Condition Details */}
      <div className="bg-card border border-border rounded-lg p-4">
        <div className="flex items-center justify-between mb-3">
          <h5 className="font-medium text-foreground">Condition Assessment</h5>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onEdit(1)}
            iconName="Edit"
            iconSize={14}
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <span className="text-sm text-muted-foreground">Overall Condition:</span>
            <div className="font-medium capitalize">{getConditionLabel(formData?.condition)}</div>
          </div>
          <div>
            <span className="text-sm text-muted-foreground">Functionality Checks:</span>
            <div className="text-sm">
              {(formData?.functionalityChecks || [])?.length} items verified
            </div>
          </div>
        </div>
      </div>
      {/* Estimated Fees */}
      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
        <h5 className="font-medium text-yellow-900 mb-3">Estimated Fees</h5>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-yellow-700">Listing Fee:</span>
            <span className="font-medium">Free</span>
          </div>
          <div className="flex justify-between">
            <span className="text-yellow-700">Transaction Fee (3%):</span>
            <span className="font-medium">
              {formData?.price ? `$${(parseFloat(formData?.price) * 0.03)?.toFixed(2)}` : '$0.00'}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-yellow-700">Payment Processing (2.9%):</span>
            <span className="font-medium">
              {formData?.price ? `$${(parseFloat(formData?.price) * 0.029)?.toFixed(2)}` : '$0.00'}
            </span>
          </div>
          <div className="border-t border-yellow-300 pt-2 flex justify-between font-medium">
            <span className="text-yellow-900">You'll Receive:</span>
            <span className="text-yellow-900">
              {formData?.price ? 
                `$${(parseFloat(formData?.price) * 0.941)?.toFixed(2)}` : 
                '$0.00'
              }
            </span>
          </div>
        </div>
      </div>
      {/* Terms and Submit */}
      <div className="space-y-4">
        <Checkbox
          label="I agree to ElectroHub's Terms of Service and Listing Policies"
          checked={agreed}
          onChange={(e) => setAgreed(e?.target?.checked)}
          required
        />
        
        <div className="flex space-x-4">
          <Button
            variant="outline"
            onClick={() => onEdit(0)}
            className="flex-1"
          >
            Back to Edit
          </Button>
          <Button
            variant="primary"
            onClick={handleSubmit}
            disabled={!agreed}
            loading={submitting}
            className="flex-1"
            iconName="Check"
            iconPosition="left"
          >
            {submitting ? 'Publishing...' : 'Publish Listing'}
          </Button>
        </div>
      </div>
      {/* Success Message */}
      {submitting && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <div className="flex items-center space-x-3">
            <Icon name="CheckCircle" size={20} className="text-green-600" />
            <div>
              <h5 className="font-medium text-green-900">Publishing Your Listing</h5>
              <p className="text-sm text-green-700">
                Your listing will be live within a few minutes and visible to buyers.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ReviewAndSubmit;