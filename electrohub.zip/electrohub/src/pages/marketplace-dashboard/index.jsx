import React, { useEffect, useState } from 'react';
import Header from '../../components/ui/Header';
import FeaturedRentalsCarousel from './components/FeaturedRentalsCarousel';
import QuickActionButtons from './components/QuickActionButtons';
import StatusCards from './components/StatusCards';
import CategoryNavigation from './components/CategoryNavigation';
import NearbyItemsGrid from './components/NearbyItemsGrid';
import RecentActivityFeed from './components/RecentActivityFeed';
import NotificationBanner from './components/NotificationBanner';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const MarketplaceDashboard = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [userLocation, setUserLocation] = useState('New York, NY');

  useEffect(() => {
    // Simulate loading data
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  const handleRefresh = async () => {
    setRefreshing(true);
    // Simulate refresh
    await new Promise(resolve => setTimeout(resolve, 1500));
    setRefreshing(false);
  };

  const handleLocationUpdate = () => {
    // Mock location update
    const locations = ['New York, NY', 'Brooklyn, NY', 'Manhattan, NY', 'Queens, NY'];
    const currentIndex = locations?.indexOf(userLocation);
    const nextIndex = (currentIndex + 1) % locations?.length;
    setUserLocation(locations?.[nextIndex]);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="pt-16">
          <div className="max-w-7xl mx-auto px-6 py-8">
            <div className="space-y-8">
              {/* Loading Skeleton */}
              <div className="animate-pulse space-y-6">
                <div className="h-8 bg-muted rounded-lg w-1/3"></div>
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
                  {[...Array(4)]?.map((_, i) => (
                    <div key={i} className="h-32 bg-muted rounded-lg"></div>
                  ))}
                </div>
                <div className="h-64 bg-muted rounded-lg"></div>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  <div className="lg:col-span-2 h-96 bg-muted rounded-lg"></div>
                  <div className="h-96 bg-muted rounded-lg"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="pt-16">
        <div className="max-w-7xl mx-auto px-6 py-8">
          {/* Welcome Section */}
          <div className="mb-8">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
              <div>
                <h1 className="text-3xl font-bold text-foreground mb-2">
                  Welcome back, John! 👋
                </h1>
                <p className="text-muted-foreground">
                  Discover amazing electronics and appliances in {userLocation}
                </p>
              </div>
              
              <div className="flex items-center gap-3">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleLocationUpdate}
                  className="flex items-center gap-2"
                >
                  <Icon name="MapPin" size={16} />
                  <span className="hidden sm:inline">{userLocation}</span>
                  <Icon name="RefreshCw" size={14} />
                </Button>
                
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleRefresh}
                  disabled={refreshing}
                  className="flex items-center gap-2"
                >
                  <Icon 
                    name="RefreshCw" 
                    size={16} 
                    className={refreshing ? 'animate-spin' : ''} 
                  />
                  <span className="hidden sm:inline">
                    {refreshing ? 'Refreshing...' : 'Refresh'}
                  </span>
                </Button>
              </div>
            </div>

            {/* Notification Banner */}
            <NotificationBanner />
          </div>

          {/* Status Cards */}
          <div className="mb-8">
            <StatusCards />
          </div>

          {/* Quick Actions */}
          <div className="mb-8">
            <QuickActionButtons />
          </div>

          {/* Featured Rentals */}
          <div className="mb-8">
            <FeaturedRentalsCarousel />
          </div>

          {/* Main Content Grid */}
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-8 mb-8">
            {/* Left Column - Category Navigation */}
            <div className="xl:col-span-1">
              <CategoryNavigation />
            </div>

            {/* Right Column - Nearby Items */}
            <div className="xl:col-span-2">
              <NearbyItemsGrid />
            </div>
          </div>

          {/* Recent Activity Feed */}
          <div className="mb-8">
            <RecentActivityFeed />
          </div>

          {/* Footer CTA Section */}
          <div className="bg-gradient-to-r from-primary to-secondary rounded-lg p-8 text-center">
            <div className="max-w-2xl mx-auto">
              <h2 className="text-2xl font-bold text-white mb-4">
                Ready to Start Earning?
              </h2>
              <p className="text-white/90 mb-6">
                List your electronics and appliances to start earning money today. 
                Join thousands of users already making extra income on ElectroHub.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  variant="secondary" 
                  size="lg"
                  className="bg-white text-primary hover:bg-white/90"
                >
                  <Icon name="Plus" size={20} className="mr-2" />
                  List Your First Item
                </Button>
                <Button 
                  variant="outline" 
                  size="lg"
                  className="border-white text-white hover:bg-white/10"
                >
                  <Icon name="Play" size={20} className="mr-2" />
                  Watch How It Works
                </Button>
              </div>
            </div>
          </div>

          {/* Stats Footer */}
          <div className="mt-12 pt-8 border-t border-border">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
              <div>
                <p className="text-3xl font-bold text-foreground">50K+</p>
                <p className="text-sm text-muted-foreground">Active Users</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-foreground">1.2M+</p>
                <p className="text-sm text-muted-foreground">Items Listed</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-foreground">$2.5M+</p>
                <p className="text-sm text-muted-foreground">Total Earnings</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-foreground">4.9★</p>
                <p className="text-sm text-muted-foreground">User Rating</p>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Mobile Pull-to-Refresh Indicator */}
      {refreshing && (
        <div className="fixed top-20 left-1/2 transform -translate-x-1/2 z-50 bg-card border border-border rounded-full px-4 py-2 shadow-elevated">
          <div className="flex items-center gap-2">
            <Icon name="RefreshCw" size={16} className="animate-spin text-primary" />
            <span className="text-sm text-foreground">Refreshing...</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default MarketplaceDashboard;