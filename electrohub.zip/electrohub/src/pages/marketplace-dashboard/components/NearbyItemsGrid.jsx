import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const NearbyItemsGrid = () => {
  const [viewMode, setViewMode] = useState('grid');
  const [sortBy, setSortBy] = useState('distance');

  const nearbyItems = [
    {
      id: 1,
      title: "iPhone 15 Pro Max",
      category: "Personal Gadgets",
      price: 45,
      period: "day",
      rating: 4.9,
      reviews: 67,
      image: "https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=300&h=200&fit=crop",
      location: "0.8 miles away",
      distance: 0.8,
      available: true,
      owner: "TechMaster",
      condition: "Excellent",
      features: ["256GB", "Titanium", "ProRAW"]
    },
    {
      id: 2,
      title: "Ninja Air Fryer",
      category: "Home & Kitchen Appliances",
      price: 12,
      period: "day",
      rating: 4.7,
      reviews: 89,
      image: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop",
      location: "1.2 miles away",
      distance: 1.2,
      available: true,
      owner: "KitchenPro",
      condition: "Very Good",
      features: ["6 Quart", "Digital", "Non-stick"]
    },
    {
      id: 3,
      title: "Dell UltraSharp 4K Monitor",
      category: "Office Electronics",
      price: 35,
      period: "day",
      rating: 4.8,
      reviews: 45,
      image: "https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?w=300&h=200&fit=crop",
      location: "1.5 miles away",
      distance: 1.5,
      available: true,
      owner: "OfficeGear",
      condition: "Excellent",
      features: ["27 inch", "4K UHD", "USB-C Hub"]
    },
    {
      id: 4,
      title: "PlayStation 5",
      category: "Entertainment Devices",
      price: 25,
      period: "day",
      rating: 4.9,
      reviews: 123,
      image: "https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?w=300&h=200&fit=crop",
      location: "2.1 miles away",
      distance: 2.1,
      available: false,
      owner: "GameZone",
      condition: "Excellent",
      features: ["825GB SSD", "DualSense", "4K Gaming"]
    },
    {
      id: 5,
      title: "Dyson V11 Vacuum",
      category: "Home & Kitchen Appliances",
      price: 20,
      period: "day",
      rating: 4.6,
      reviews: 78,
      image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=300&h=200&fit=crop",
      location: "2.3 miles away",
      distance: 2.3,
      available: true,
      owner: "CleanTech",
      condition: "Good",
      features: ["Cordless", "HEPA Filter", "60min Battery"]
    },
    {
      id: 6,
      title: "Canon EOS R5",
      category: "Entertainment Devices",
      price: 75,
      period: "day",
      rating: 4.8,
      reviews: 56,
      image: "https://images.unsplash.com/photo-1606983340126-99ab4feaa64a?w=300&h=200&fit=crop",
      location: "2.8 miles away",
      distance: 2.8,
      available: true,
      owner: "PhotoStudio",
      condition: "Excellent",
      features: ["45MP", "8K Video", "Image Stabilization"]
    }
  ];

  const sortOptions = [
    { value: 'distance', label: 'Distance' },
    { value: 'price-low', label: 'Price: Low to High' },
    { value: 'price-high', label: 'Price: High to Low' },
    { value: 'rating', label: 'Highest Rated' },
    { value: 'newest', label: 'Newest First' }
  ];

  const getSortedItems = () => {
    const items = [...nearbyItems];
    switch (sortBy) {
      case 'distance':
        return items?.sort((a, b) => a?.distance - b?.distance);
      case 'price-low':
        return items?.sort((a, b) => a?.price - b?.price);
      case 'price-high':
        return items?.sort((a, b) => b?.price - a?.price);
      case 'rating':
        return items?.sort((a, b) => b?.rating - a?.rating);
      default:
        return items;
    }
  };

  const getConditionColor = (condition) => {
    switch (condition) {
      case 'Excellent':
        return 'text-success bg-success/10';
      case 'Very Good':
        return 'text-primary bg-primary/10';
      case 'Good':
        return 'text-warning bg-warning/10';
      default:
        return 'text-muted-foreground bg-muted';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold text-foreground">Nearby Available Items</h2>
          <p className="text-sm text-muted-foreground">Items within 5 miles of your location</p>
        </div>
        
        <div className="flex items-center gap-3">
          {/* Sort Dropdown */}
          <div className="flex items-center gap-2">
            <Icon name="ArrowUpDown" size={16} className="text-muted-foreground" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e?.target?.value)}
              className="text-sm border border-border rounded-md px-3 py-1 bg-card text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            >
              {sortOptions?.map((option) => (
                <option key={option?.value} value={option?.value}>
                  {option?.label}
                </option>
              ))}
            </select>
          </div>

          {/* View Mode Toggle */}
          <div className="flex items-center border border-border rounded-md">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 ${viewMode === 'grid' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'} transition-colors`}
            >
              <Icon name="Grid3X3" size={16} />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 ${viewMode === 'list' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'} transition-colors`}
            >
              <Icon name="List" size={16} />
            </button>
          </div>
        </div>
      </div>
      {/* Grid View */}
      {viewMode === 'grid' && (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {getSortedItems()?.map((item) => (
            <div
              key={item?.id}
              className="bg-card rounded-lg border border-border overflow-hidden hover:shadow-elevated transition-all duration-200 group"
            >
              <div className="relative">
                <div className="aspect-[4/3] overflow-hidden">
                  <Image
                    src={item?.image}
                    alt={item?.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                  />
                </div>
                <div className="absolute top-3 left-3 flex gap-2">
                  <span className={`px-2 py-1 rounded-md text-xs font-medium ${
                    item?.available 
                      ? 'bg-success text-success-foreground' 
                      : 'bg-error text-error-foreground'
                  }`}>
                    {item?.available ? 'Available' : 'Rented'}
                  </span>
                  <span className={`px-2 py-1 rounded-md text-xs font-medium ${getConditionColor(item?.condition)}`}>
                    {item?.condition}
                  </span>
                </div>
                <button className="absolute top-3 right-3 bg-card/80 backdrop-blur-sm p-2 rounded-full hover:bg-card transition-colors">
                  <Icon name="Heart" size={16} className="text-muted-foreground" />
                </button>
              </div>

              <div className="p-4 space-y-3">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-medium text-primary bg-primary/10 px-2 py-1 rounded-md">
                      {item?.category}
                    </span>
                    <div className="flex items-center gap-1">
                      <Icon name="Star" size={12} className="text-warning fill-current" />
                      <span className="text-xs font-medium text-foreground">{item?.rating}</span>
                      <span className="text-xs text-muted-foreground">({item?.reviews})</span>
                    </div>
                  </div>
                  <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors">
                    {item?.title}
                  </h3>
                  <div className="flex items-center justify-between text-sm text-muted-foreground mt-1">
                    <div className="flex items-center gap-1">
                      <Icon name="MapPin" size={12} />
                      <span>{item?.location}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Icon name="User" size={12} />
                      <span>{item?.owner}</span>
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap gap-1">
                  {item?.features?.slice(0, 3)?.map((feature, index) => (
                    <span
                      key={index}
                      className="text-xs bg-muted text-muted-foreground px-2 py-1 rounded-md"
                    >
                      {feature}
                    </span>
                  ))}
                </div>

                <div className="flex items-center justify-between pt-2">
                  <div>
                    <div className="flex items-baseline gap-1">
                      <span className="text-lg font-bold text-foreground">${item?.price}</span>
                      <span className="text-sm text-muted-foreground">/{item?.period}</span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" disabled={!item?.available}>
                      <Icon name="MessageCircle" size={14} />
                    </Button>
                    <Link to={`/product-detail-booking?id=${item?.id}`}>
                      <Button size="sm" disabled={!item?.available}>
                        {item?.available ? 'Rent' : 'Unavailable'}
                      </Button>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
      {/* List View */}
      {viewMode === 'list' && (
        <div className="space-y-4">
          {getSortedItems()?.map((item) => (
            <div
              key={item?.id}
              className="bg-card rounded-lg border border-border p-4 hover:shadow-elevated transition-all duration-200 group"
            >
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="sm:w-48 flex-shrink-0">
                  <div className="relative aspect-[4/3] rounded-lg overflow-hidden">
                    <Image
                      src={item?.image}
                      alt={item?.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                    />
                    <div className="absolute top-2 left-2">
                      <span className={`px-2 py-1 rounded-md text-xs font-medium ${
                        item?.available 
                          ? 'bg-success text-success-foreground' 
                          : 'bg-error text-error-foreground'
                      }`}>
                        {item?.available ? 'Available' : 'Rented'}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex-1 space-y-3">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-medium text-primary bg-primary/10 px-2 py-1 rounded-md">
                        {item?.category}
                      </span>
                      <span className={`text-xs font-medium px-2 py-1 rounded-md ${getConditionColor(item?.condition)}`}>
                        {item?.condition}
                      </span>
                      <div className="flex items-center gap-1">
                        <Icon name="Star" size={12} className="text-warning fill-current" />
                        <span className="text-xs font-medium text-foreground">{item?.rating}</span>
                        <span className="text-xs text-muted-foreground">({item?.reviews})</span>
                      </div>
                    </div>
                    <h3 className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors">
                      {item?.title}
                    </h3>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Icon name="MapPin" size={14} />
                        <span>{item?.location}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Icon name="User" size={14} />
                        <span>{item?.owner}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {item?.features?.map((feature, index) => (
                      <span
                        key={index}
                        className="text-xs bg-muted text-muted-foreground px-2 py-1 rounded-md"
                      >
                        {feature}
                      </span>
                    ))}
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-baseline gap-1">
                        <span className="text-xl font-bold text-foreground">${item?.price}</span>
                        <span className="text-sm text-muted-foreground">/{item?.period}</span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" disabled={!item?.available}>
                        <Icon name="MessageCircle" size={16} />
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Icon name="Heart" size={16} />
                      </Button>
                      <Link to={`/product-detail-booking?id=${item?.id}`}>
                        <Button size="sm" disabled={!item?.available}>
                          {item?.available ? 'Rent Now' : 'Unavailable'}
                        </Button>
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
      <div className="text-center">
        <Link to="/product-search-browse">
          <Button variant="outline">
            View All Nearby Items
            <Icon name="ArrowRight" size={16} className="ml-2" />
          </Button>
        </Link>
      </div>
    </div>
  );
};

export default NearbyItemsGrid;