import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const FeaturedRentalsCarousel = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  const featuredRentals = [
    {
      id: 1,
      title: "MacBook Pro 16-inch M3",
      category: "Personal Gadgets",
      price: 89,
      period: "day",
      rating: 4.8,
      reviews: 124,
      image: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400&h=300&fit=crop",
      location: "Manhattan, NY",
      available: true,
      owner: "TechRentals Pro",
      features: ["Latest M3 Chip", "32GB RAM", "1TB SSD"]
    },
    {
      id: 2,
      title: "KitchenAid Stand Mixer",
      category: "Home & Kitchen Appliances",
      price: 25,
      period: "day",
      rating: 4.9,
      reviews: 89,
      image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=300&fit=crop",
      location: "Brooklyn, NY",
      available: true,
      owner: "HomeChef Rentals",
      features: ["Professional Grade", "Multiple Attachments", "10 Speed Settings"]
    },
    {
      id: 3,
      title: "Sony A7 IV Camera Kit",
      category: "Entertainment Devices",
      price: 65,
      period: "day",
      rating: 4.7,
      reviews: 156,
      image: "https://images.unsplash.com/photo-1606983340126-99ab4feaa64a?w=400&h=300&fit=crop",
      location: "Queens, NY",
      available: true,
      owner: "PhotoPro Rentals",
      features: ["Full Frame", "4K Video", "Complete Lens Kit"]
    },
    {
      id: 4,
      title: "Dyson V15 Detect",
      category: "Home & Kitchen Appliances",
      price: 18,
      period: "day",
      rating: 4.6,
      reviews: 203,
      image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&h=300&fit=crop",
      location: "Manhattan, NY",
      available: true,
      owner: "CleanTech Rentals",
      features: ["Laser Detection", "HEPA Filtration", "60min Runtime"]
    }
  ];

  useEffect(() => {
    if (!isAutoPlaying) return;

    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % featuredRentals?.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [isAutoPlaying, featuredRentals?.length]);

  const goToSlide = (index) => {
    setCurrentSlide(index);
    setIsAutoPlaying(false);
    setTimeout(() => setIsAutoPlaying(true), 10000);
  };

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % featuredRentals?.length);
    setIsAutoPlaying(false);
    setTimeout(() => setIsAutoPlaying(true), 10000);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + featuredRentals?.length) % featuredRentals?.length);
    setIsAutoPlaying(false);
    setTimeout(() => setIsAutoPlaying(true), 10000);
  };

  return (
    <div className="bg-card rounded-lg border border-border overflow-hidden">
      <div className="flex items-center justify-between p-6 border-b border-border">
        <div>
          <h2 className="text-xl font-semibold text-foreground">Featured Rentals</h2>
          <p className="text-sm text-muted-foreground">Top-rated items available now</p>
        </div>
        <Link to="/product-search-browse">
          <Button variant="outline" size="sm">
            View All
            <Icon name="ArrowRight" size={16} className="ml-2" />
          </Button>
        </Link>
      </div>
      <div className="relative">
        <div className="overflow-hidden">
          <div 
            className="flex transition-transform duration-500 ease-in-out"
            style={{ transform: `translateX(-${currentSlide * 100}%)` }}
          >
            {featuredRentals?.map((item) => (
              <div key={item?.id} className="w-full flex-shrink-0">
                <div className="p-6">
                  <div className="flex flex-col lg:flex-row gap-6">
                    <div className="lg:w-1/3">
                      <div className="relative aspect-[4/3] rounded-lg overflow-hidden">
                        <Image
                          src={item?.image}
                          alt={item?.title}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute top-3 left-3">
                          <span className="bg-success text-success-foreground px-2 py-1 rounded-md text-xs font-medium">
                            Available
                          </span>
                        </div>
                        <div className="absolute top-3 right-3">
                          <button className="bg-card/80 backdrop-blur-sm p-2 rounded-full hover:bg-card transition-colors">
                            <Icon name="Heart" size={16} className="text-muted-foreground" />
                          </button>
                        </div>
                      </div>
                    </div>

                    <div className="lg:w-2/3 space-y-4">
                      <div>
                        <div className="flex items-center gap-2 mb-2">
                          <span className="text-xs font-medium text-primary bg-primary/10 px-2 py-1 rounded-md">
                            {item?.category}
                          </span>
                          <div className="flex items-center gap-1">
                            <Icon name="Star" size={14} className="text-warning fill-current" />
                            <span className="text-sm font-medium text-foreground">{item?.rating}</span>
                            <span className="text-sm text-muted-foreground">({item?.reviews})</span>
                          </div>
                        </div>
                        <h3 className="text-lg font-semibold text-foreground mb-1">{item?.title}</h3>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Icon name="MapPin" size={14} />
                            <span>{item?.location}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Icon name="User" size={14} />
                            <span>{item?.owner}</span>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <h4 className="text-sm font-medium text-foreground">Key Features:</h4>
                        <div className="flex flex-wrap gap-2">
                          {item?.features?.map((feature, index) => (
                            <span
                              key={index}
                              className="text-xs bg-muted text-muted-foreground px-2 py-1 rounded-md"
                            >
                              {feature}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-4">
                        <div>
                          <div className="flex items-baseline gap-1">
                            <span className="text-2xl font-bold text-foreground">${item?.price}</span>
                            <span className="text-sm text-muted-foreground">/{item?.period}</span>
                          </div>
                          <p className="text-xs text-muted-foreground">Free delivery within 5 miles</p>
                        </div>
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm">
                            <Icon name="MessageCircle" size={16} />
                          </Button>
                          <Link to={`/product-detail-booking?id=${item?.id}`}>
                            <Button size="sm">
                              Rent Now
                            </Button>
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Navigation Arrows */}
        <button
          onClick={prevSlide}
          className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-card/80 backdrop-blur-sm p-2 rounded-full hover:bg-card transition-colors shadow-soft"
        >
          <Icon name="ChevronLeft" size={20} className="text-foreground" />
        </button>
        <button
          onClick={nextSlide}
          className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-card/80 backdrop-blur-sm p-2 rounded-full hover:bg-card transition-colors shadow-soft"
        >
          <Icon name="ChevronRight" size={20} className="text-foreground" />
        </button>

        {/* Dots Indicator */}
        <div className="flex justify-center gap-2 p-4">
          {featuredRentals?.map((_, index) => (
            <button
              key={index}
              onClick={() => goToSlide(index)}
              className={`w-2 h-2 rounded-full transition-colors ${
                index === currentSlide ? 'bg-primary' : 'bg-muted-foreground/30'
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default FeaturedRentalsCarousel;