import React from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';

const CategoryNavigation = () => {
  const categories = [
    {
      id: 1,
      name: "Personal Gadgets",
      description: "Phones, laptops, tablets & more",
      icon: "Smartphone",
      color: "bg-blue-500",
      textColor: "text-blue-500",
      bgColor: "bg-blue-50",
      count: "450+ items",
      popular: ["iPhone 15", "MacBook Pro", "iPad Air"]
    },
    {
      id: 2,
      name: "Home & Kitchen Appliances",
      description: "Cooking, cleaning & home essentials",
      icon: "Home",
      color: "bg-green-500",
      textColor: "text-green-500",
      bgColor: "bg-green-50",
      count: "320+ items",
      popular: ["Stand Mixer", "Air Fryer", "Vacuum Cleaner"]
    },
    {
      id: 3,
      name: "Office Electronics",
      description: "Printers, monitors & work equipment",
      icon: "Monitor",
      color: "bg-purple-500",
      textColor: "text-purple-500",
      bgColor: "bg-purple-50",
      count: "280+ items",
      popular: ["4K Monitor", "Laser Printer", "Webcam"]
    },
    {
      id: 4,
      name: "Entertainment Devices",
      description: "Gaming, audio & video equipment",
      icon: "Gamepad2",
      color: "bg-orange-500",
      textColor: "text-orange-500",
      bgColor: "bg-orange-50",
      count: "380+ items",
      popular: ["PS5", "4K TV", "Sound System"]
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold text-foreground">Browse Categories</h2>
          <p className="text-sm text-muted-foreground">Find exactly what you're looking for</p>
        </div>
      </div>
      {/* Desktop Grid Layout */}
      <div className="hidden md:grid md:grid-cols-2 xl:grid-cols-4 gap-4">
        {categories?.map((category) => (
          <Link
            key={category?.id}
            to={`/product-search-browse?category=${encodeURIComponent(category?.name)}`}
            className="group"
          >
            <div className="bg-card rounded-lg border border-border p-6 hover:shadow-elevated hover:border-primary/50 transition-all duration-200">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className={`w-12 h-12 ${category?.color} rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform duration-200`}>
                    <Icon name={category?.icon} size={24} className="text-white" />
                  </div>
                  <Icon name="ArrowUpRight" size={16} className="text-muted-foreground group-hover:text-primary transition-colors" />
                </div>

                <div>
                  <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors">
                    {category?.name}
                  </h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    {category?.description}
                  </p>
                  <p className="text-xs font-medium text-primary mt-2">
                    {category?.count}
                  </p>
                </div>

                <div className="space-y-2">
                  <p className="text-xs font-medium text-foreground">Popular:</p>
                  <div className="flex flex-wrap gap-1">
                    {category?.popular?.slice(0, 2)?.map((item, index) => (
                      <span
                        key={index}
                        className="text-xs bg-muted text-muted-foreground px-2 py-1 rounded-md"
                      >
                        {item}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </Link>
        ))}
      </div>
      {/* Mobile Horizontal Scroll */}
      <div className="md:hidden">
        <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide">
          {categories?.map((category) => (
            <Link
              key={category?.id}
              to={`/product-search-browse?category=${encodeURIComponent(category?.name)}`}
              className="flex-shrink-0 w-64"
            >
              <div className="bg-card rounded-lg border border-border p-4 hover:shadow-elevated transition-all duration-200 active:scale-95">
                <div className="flex items-start gap-3">
                  <div className={`w-10 h-10 ${category?.color} rounded-lg flex items-center justify-center flex-shrink-0`}>
                    <Icon name={category?.icon} size={20} className="text-white" />
                  </div>
                  
                  <div className="min-w-0 flex-1">
                    <h3 className="font-medium text-foreground text-sm">
                      {category?.name}
                    </h3>
                    <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                      {category?.description}
                    </p>
                    <p className="text-xs font-medium text-primary mt-2">
                      {category?.count}
                    </p>
                  </div>
                </div>

                <div className="mt-3">
                  <div className="flex flex-wrap gap-1">
                    {category?.popular?.slice(0, 3)?.map((item, index) => (
                      <span
                        key={index}
                        className="text-xs bg-muted text-muted-foreground px-2 py-1 rounded-md"
                      >
                        {item}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
      {/* Category Stats */}
      <div className="bg-card rounded-lg border border-border p-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <p className="text-2xl font-bold text-foreground">1,430</p>
            <p className="text-sm text-muted-foreground">Total Items</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-foreground">89%</p>
            <p className="text-sm text-muted-foreground">Available Now</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-foreground">4.8</p>
            <p className="text-sm text-muted-foreground">Avg Rating</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-foreground">24/7</p>
            <p className="text-sm text-muted-foreground">Support</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CategoryNavigation;