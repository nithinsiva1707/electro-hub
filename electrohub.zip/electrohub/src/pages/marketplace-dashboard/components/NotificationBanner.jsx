import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const NotificationBanner = () => {
  const [notifications, setNotifications] = useState([]);
  const [currentNotification, setCurrentNotification] = useState(0);

  const mockNotifications = [
    {
      id: 1,
      type: 'bid_update',
      title: "New Bid Alert!",
      message: "Your MacBook Pro auction received a bid of $1,250. Current highest bid!",
      icon: "Gavel",
      color: "bg-warning",
      textColor: "text-warning-foreground",
      action: "View Auction",
      route: "/auction-bidding-interface",
      priority: "high",
      timestamp: new Date(Date.now() - 300000), // 5 minutes ago
      dismissible: true
    },
    {
      id: 2,
      type: 'rental_reminder',
      title: "Rental Ending Soon",
      message: "iPhone 15 Pro rental ends in 2 hours. Extend or prepare for return.",
      icon: "Clock",
      color: "bg-primary",
      textColor: "text-primary-foreground",
      action: "Manage Rental",
      route: "/rental-management",
      priority: "medium",
      timestamp: new Date(Date.now() - 600000), // 10 minutes ago
      dismissible: true
    },
    {
      id: 3,
      type: 'payment_success',
      title: "Payment Received",
      message: "You\'ve earned $36 from your Ninja Air Fryer rental. Great job!",
      icon: "DollarSign",
      color: "bg-success",
      textColor: "text-success-foreground",
      action: "View Earnings",
      route: "/rental-management",
      priority: "low",
      timestamp: new Date(Date.now() - 1800000), // 30 minutes ago
      dismissible: true
    },
    {
      id: 4,
      type: 'message_new',
      title: "New Message",
      message: "Sarah Johnson sent you a message about the Dell Monitor rental.",
      icon: "MessageCircle",
      color: "bg-secondary",
      textColor: "text-secondary-foreground",
      action: "Read Message",
      route: "/rental-management",
      priority: "medium",
      timestamp: new Date(Date.now() - 900000), // 15 minutes ago
      dismissible: true
    },
    {
      id: 5,
      type: 'system_update',
      title: "New Feature Available",
      message: "AI Price Estimation is now live! Get instant price suggestions for your listings.",
      icon: "Sparkles",
      color: "bg-accent",
      textColor: "text-accent-foreground",
      action: "Try Now",
      route: "/product-listing-creation",
      priority: "low",
      timestamp: new Date(Date.now() - 3600000), // 1 hour ago
      dismissible: true
    }
  ];

  useEffect(() => {
    // Filter out dismissed notifications from localStorage
    const dismissedIds = JSON.parse(localStorage.getItem('dismissedNotifications') || '[]');
    const activeNotifications = mockNotifications?.filter(n => !dismissedIds?.includes(n?.id));
    setNotifications(activeNotifications);
  }, []);

  useEffect(() => {
    if (notifications?.length > 1) {
      const interval = setInterval(() => {
        setCurrentNotification((prev) => (prev + 1) % notifications?.length);
      }, 8000); // Change notification every 8 seconds

      return () => clearInterval(interval);
    }
  }, [notifications?.length]);

  const dismissNotification = (notificationId) => {
    const dismissedIds = JSON.parse(localStorage.getItem('dismissedNotifications') || '[]');
    const updatedDismissedIds = [...dismissedIds, notificationId];
    localStorage.setItem('dismissedNotifications', JSON.stringify(updatedDismissedIds));
    
    setNotifications(prev => prev?.filter(n => n?.id !== notificationId));
    
    // Adjust current notification index if needed
    if (currentNotification >= notifications?.length - 1) {
      setCurrentNotification(0);
    }
  };

  const dismissAllNotifications = () => {
    const allIds = notifications?.map(n => n?.id);
    localStorage.setItem('dismissedNotifications', JSON.stringify(allIds));
    setNotifications([]);
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high':
        return 'border-l-error';
      case 'medium':
        return 'border-l-warning';
      case 'low':
        return 'border-l-primary';
      default:
        return 'border-l-muted';
    }
  };

  const formatTimeAgo = (timestamp) => {
    const now = new Date();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);

    if (hours > 0) return `${hours}h ago`;
    if (minutes > 0) return `${minutes}m ago`;
    return 'Just now';
  };

  if (notifications?.length === 0) {
    return null;
  }

  const notification = notifications?.[currentNotification];

  return (
    <div className="space-y-4">
      {/* Main Notification Banner */}
      <div className={`relative overflow-hidden rounded-lg border-l-4 ${getPriorityColor(notification?.priority)} bg-card border border-border shadow-soft`}>
        <div className="p-4">
          <div className="flex items-start gap-4">
            <div className={`w-10 h-10 ${notification?.color} rounded-lg flex items-center justify-center flex-shrink-0`}>
              <Icon name={notification?.icon} size={20} className={notification?.textColor} />
            </div>
            
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-foreground mb-1">{notification?.title}</h3>
                  <p className="text-sm text-muted-foreground mb-3">{notification?.message}</p>
                  
                  <div className="flex items-center gap-4">
                    <Link to={notification?.route}>
                      <Button size="sm" variant="outline">
                        {notification?.action}
                        <Icon name="ArrowRight" size={14} className="ml-2" />
                      </Button>
                    </Link>
                    <span className="text-xs text-muted-foreground">
                      {formatTimeAgo(notification?.timestamp)}
                    </span>
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  {notifications?.length > 1 && (
                    <div className="flex items-center gap-1">
                      {notifications?.map((_, index) => (
                        <button
                          key={index}
                          onClick={() => setCurrentNotification(index)}
                          className={`w-2 h-2 rounded-full transition-colors ${
                            index === currentNotification ? 'bg-primary' : 'bg-muted-foreground/30'
                          }`}
                        />
                      ))}
                    </div>
                  )}
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => dismissNotification(notification?.id)}
                    className="text-muted-foreground hover:text-foreground"
                  >
                    <Icon name="X" size={16} />
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Progress bar for auto-rotation */}
        {notifications?.length > 1 && (
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-muted">
            <div 
              className="h-full bg-primary transition-all duration-[8000ms] ease-linear"
              style={{ width: '100%' }}
              key={currentNotification} // Reset animation on notification change
            />
          </div>
        )}
      </div>
      {/* Notification Summary */}
      {notifications?.length > 1 && (
        <div className="bg-card rounded-lg border border-border p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Icon name="Bell" size={16} className="text-muted-foreground" />
              <span className="text-sm text-muted-foreground">
                {notifications?.length} active notifications
              </span>
            </div>
            
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm" onClick={dismissAllNotifications}>
                <Icon name="X" size={14} className="mr-1" />
                Dismiss All
              </Button>
              <Link to="/rental-management">
                <Button variant="outline" size="sm">
                  View All
                </Button>
              </Link>
            </div>
          </div>
        </div>
      )}
      {/* Mobile Compact View */}
      <div className="md:hidden bg-card rounded-lg border border-border p-3">
        <div className="flex items-center gap-3">
          <div className={`w-8 h-8 ${notification?.color} rounded-lg flex items-center justify-center flex-shrink-0`}>
            <Icon name={notification?.icon} size={16} className={notification?.textColor} />
          </div>
          
          <div className="flex-1 min-w-0">
            <h4 className="font-medium text-foreground text-sm">{notification?.title}</h4>
            <p className="text-xs text-muted-foreground line-clamp-1">{notification?.message}</p>
          </div>
          
          <div className="flex items-center gap-1">
            <Link to={notification?.route}>
              <Button size="xs">
                <Icon name="ArrowRight" size={12} />
              </Button>
            </Link>
            <Button
              variant="ghost"
              size="xs"
              onClick={() => dismissNotification(notification?.id)}
            >
              <Icon name="X" size={12} />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NotificationBanner;