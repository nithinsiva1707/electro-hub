import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const RecentActivityFeed = () => {
  const [filter, setFilter] = useState('all');

  const activities = [
    {
      id: 1,
      type: 'rental_started',
      title: "Rental Started",
      description: "iPhone 15 Pro rental period began",
      user: "Sarah Johnson",
      userAvatar: "https://randomuser.me/api/portraits/women/32.jpg",
      timestamp: new Date(Date.now() - 1800000), // 30 minutes ago
      amount: "$45/day",
      status: "active",
      itemImage: "https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=100&h=100&fit=crop",
      action: "View Details"
    },
    {
      id: 2,
      type: 'bid_received',
      title: "New Bid Received",
      description: "Someone bid on your MacBook Pro auction",
      user: "Mike Chen",
      userAvatar: "https://randomuser.me/api/portraits/men/45.jpg",
      timestamp: new Date(Date.now() - 3600000), // 1 hour ago
      amount: "$1,250",
      status: "pending",
      itemImage: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=100&h=100&fit=crop",
      action: "View Auction"
    },
    {
      id: 3,
      type: 'payment_received',
      title: "Payment Received",
      description: "Rental payment for Ninja Air Fryer",
      user: "Emma Wilson",
      userAvatar: "https://randomuser.me/api/portraits/women/28.jpg",
      timestamp: new Date(Date.now() - 7200000), // 2 hours ago
      amount: "+$36",
      status: "completed",
      itemImage: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=100&h=100&fit=crop",
      action: "View Receipt"
    },
    {
      id: 4,
      type: 'message_received',
      title: "New Message",
      description: "Question about Dell Monitor availability",
      user: "Alex Rodriguez",
      userAvatar: "https://randomuser.me/api/portraits/men/34.jpg",
      timestamp: new Date(Date.now() - 10800000), // 3 hours ago
      amount: null,
      status: "unread",
      itemImage: "https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?w=100&h=100&fit=crop",
      action: "Reply"
    },
    {
      id: 5,
      type: 'rental_returned',
      title: "Item Returned",
      description: "PlayStation 5 returned in excellent condition",
      user: "David Kim",
      userAvatar: "https://randomuser.me/api/portraits/men/29.jpg",
      timestamp: new Date(Date.now() - 14400000), // 4 hours ago
      amount: "+$75",
      status: "completed",
      itemImage: "https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?w=100&h=100&fit=crop",
      action: "Rate User"
    },
    {
      id: 6,
      type: 'pickup_scheduled',
      title: "Pickup Scheduled",
      description: "Recycling pickup for old electronics",
      user: "GreenTech Recycling",
      userAvatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop",
      timestamp: new Date(Date.now() - 18000000), // 5 hours ago
      amount: "Free",
      status: "scheduled",
      itemImage: null,
      action: "View Schedule"
    }
  ];

  const filterOptions = [
    { value: 'all', label: 'All Activity', count: activities?.length },
    { value: 'rental', label: 'Rentals', count: activities?.filter(a => a?.type?.includes('rental'))?.length },
    { value: 'auction', label: 'Auctions', count: activities?.filter(a => a?.type?.includes('bid'))?.length },
    { value: 'payment', label: 'Payments', count: activities?.filter(a => a?.type?.includes('payment'))?.length },
    { value: 'message', label: 'Messages', count: activities?.filter(a => a?.type?.includes('message'))?.length }
  ];

  const getFilteredActivities = () => {
    if (filter === 'all') return activities;
    return activities?.filter(activity => {
      switch (filter) {
        case 'rental':
          return activity?.type?.includes('rental');
        case 'auction':
          return activity?.type?.includes('bid');
        case 'payment':
          return activity?.type?.includes('payment');
        case 'message':
          return activity?.type?.includes('message');
        default:
          return true;
      }
    });
  };

  const getActivityIcon = (type) => {
    switch (type) {
      case 'rental_started':
        return { name: 'Play', color: 'text-success' };
      case 'rental_returned':
        return { name: 'RotateCcw', color: 'text-primary' };
      case 'bid_received':
        return { name: 'Gavel', color: 'text-warning' };
      case 'payment_received':
        return { name: 'DollarSign', color: 'text-success' };
      case 'message_received':
        return { name: 'MessageCircle', color: 'text-primary' };
      case 'pickup_scheduled':
        return { name: 'Calendar', color: 'text-secondary' };
      default:
        return { name: 'Activity', color: 'text-muted-foreground' };
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'active':
        return 'bg-success/10 text-success';
      case 'pending':
        return 'bg-warning/10 text-warning';
      case 'completed':
        return 'bg-primary/10 text-primary';
      case 'unread':
        return 'bg-error/10 text-error';
      case 'scheduled':
        return 'bg-secondary/10 text-secondary';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const formatTimeAgo = (timestamp) => {
    const now = new Date();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (days > 0) return `${days}d ago`;
    if (hours > 0) return `${hours}h ago`;
    if (minutes > 0) return `${minutes}m ago`;
    return 'Just now';
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold text-foreground">Recent Activity</h2>
          <p className="text-sm text-muted-foreground">Stay updated with your marketplace activity</p>
        </div>
        <Link to="/rental-management">
          <Button variant="outline" size="sm">
            View All
            <Icon name="ArrowRight" size={16} className="ml-2" />
          </Button>
        </Link>
      </div>
      {/* Filter Tabs */}
      <div className="bg-card rounded-lg border border-border p-1">
        <div className="flex flex-wrap gap-1">
          {filterOptions?.map((option) => (
            <button
              key={option?.value}
              onClick={() => setFilter(option?.value)}
              className={`flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                filter === option?.value
                  ? 'bg-primary text-primary-foreground'
                  : 'text-muted-foreground hover:text-foreground hover:bg-muted'
              }`}
            >
              <span>{option?.label}</span>
              <span className={`text-xs px-1.5 py-0.5 rounded-full ${
                filter === option?.value
                  ? 'bg-primary-foreground/20 text-primary-foreground'
                  : 'bg-muted text-muted-foreground'
              }`}>
                {option?.count}
              </span>
            </button>
          ))}
        </div>
      </div>
      {/* Activity Feed */}
      <div className="bg-card rounded-lg border border-border">
        <div className="divide-y divide-border">
          {getFilteredActivities()?.map((activity) => {
            const activityIcon = getActivityIcon(activity?.type);
            
            return (
              <div key={activity?.id} className="p-4 hover:bg-muted/50 transition-colors">
                <div className="flex gap-4">
                  {/* Activity Icon */}
                  <div className="flex-shrink-0">
                    <div className={`w-10 h-10 rounded-full bg-muted flex items-center justify-center ${activityIcon?.color}`}>
                      <Icon name={activityIcon?.name} size={18} />
                    </div>
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-medium text-foreground">{activity?.title}</h3>
                          <span className={`px-2 py-1 rounded-md text-xs font-medium ${getStatusBadge(activity?.status)}`}>
                            {activity?.status}
                          </span>
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">{activity?.description}</p>
                        
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <div className="flex items-center gap-2">
                            <Image
                              src={activity?.userAvatar}
                              alt={activity?.user}
                              className="w-5 h-5 rounded-full"
                            />
                            <span>{activity?.user}</span>
                          </div>
                          <span>{formatTimeAgo(activity?.timestamp)}</span>
                          {activity?.amount && (
                            <span className="font-medium text-foreground">{activity?.amount}</span>
                          )}
                        </div>
                      </div>

                      {/* Item Image & Action */}
                      <div className="flex items-center gap-3">
                        {activity?.itemImage && (
                          <div className="w-12 h-12 rounded-lg overflow-hidden flex-shrink-0">
                            <Image
                              src={activity?.itemImage}
                              alt="Item"
                              className="w-full h-full object-cover"
                            />
                          </div>
                        )}
                        <Button variant="ghost" size="sm">
                          {activity?.action}
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {getFilteredActivities()?.length === 0 && (
          <div className="p-8 text-center">
            <Icon name="Activity" size={48} className="text-muted-foreground mx-auto mb-4" />
            <h3 className="font-medium text-foreground mb-2">No activity found</h3>
            <p className="text-sm text-muted-foreground">
              {filter === 'all' 
                ? "You don't have any recent activity yet."
                : `No ${filter} activity found.`
              }
            </p>
          </div>
        )}
      </div>
      {/* Load More */}
      {getFilteredActivities()?.length > 0 && (
        <div className="text-center">
          <Button variant="outline">
            Load More Activity
            <Icon name="ChevronDown" size={16} className="ml-2" />
          </Button>
        </div>
      )}
    </div>
  );
};

export default RecentActivityFeed;