import React from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const StatusCards = () => {
  const statusData = [
    {
      id: 1,
      title: "Active Rentals",
      value: "3",
      subtitle: "Items currently rented",
      icon: "Package",
      color: "text-primary",
      bgColor: "bg-primary/10",
      trend: "+2 this week",
      trendIcon: "TrendingUp",
      trendColor: "text-success",
      action: "Manage",
      route: "/rental-management"
    },
    {
      id: 2,
      title: "Pending Auctions",
      value: "2",
      subtitle: "Bids awaiting response",
      icon: "Gavel",
      color: "text-warning",
      bgColor: "bg-warning/10",
      trend: "Ends in 2h 15m",
      trendIcon: "Clock",
      trendColor: "text-warning",
      action: "View Bids",
      route: "/auction-bidding-interface"
    },
    {
      id: 3,
      title: "Reward Points",
      value: "1,247",
      subtitle: "Available to redeem",
      icon: "Star",
      color: "text-success",
      bgColor: "bg-success/10",
      trend: "+150 earned",
      trendIcon: "Plus",
      trendColor: "text-success",
      action: "Redeem",
      route: "/rental-management"
    },
    {
      id: 4,
      title: "Total Earnings",
      value: "$2,340",
      subtitle: "This month",
      icon: "DollarSign",
      color: "text-secondary",
      bgColor: "bg-secondary/10",
      trend: "+18% vs last month",
      trendIcon: "TrendingUp",
      trendColor: "text-success",
      action: "Details",
      route: "/rental-management"
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold text-foreground">Your Activity</h2>
          <p className="text-sm text-muted-foreground">Overview of your marketplace activity</p>
        </div>
        <Link to="/rental-management">
          <Button variant="outline" size="sm">
            View All
            <Icon name="ArrowRight" size={16} className="ml-2" />
          </Button>
        </Link>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        {statusData?.map((item) => (
          <div
            key={item?.id}
            className="bg-card rounded-lg border border-border p-6 hover:shadow-elevated transition-all duration-200 group"
          >
            <div className="flex items-start justify-between mb-4">
              <div className={`w-12 h-12 ${item?.bgColor} rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform duration-200`}>
                <Icon name={item?.icon} size={24} className={item?.color} />
              </div>
              <Link to={item?.route}>
                <Button variant="ghost" size="sm" className="opacity-0 group-hover:opacity-100 transition-opacity">
                  <Icon name="ExternalLink" size={14} />
                </Button>
              </Link>
            </div>

            <div className="space-y-2">
              <div>
                <h3 className="text-2xl font-bold text-foreground">{item?.value}</h3>
                <p className="text-sm font-medium text-foreground">{item?.title}</p>
                <p className="text-xs text-muted-foreground">{item?.subtitle}</p>
              </div>

              <div className="flex items-center justify-between pt-2">
                <div className="flex items-center gap-1">
                  <Icon name={item?.trendIcon} size={12} className={item?.trendColor} />
                  <span className={`text-xs font-medium ${item?.trendColor}`}>
                    {item?.trend}
                  </span>
                </div>
                <Link to={item?.route}>
                  <Button variant="ghost" size="xs" className="text-xs">
                    {item?.action}
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>
      {/* Mobile Compact View */}
      <div className="md:hidden bg-card rounded-lg border border-border p-4">
        <h3 className="font-semibold text-foreground mb-3">Quick Stats</h3>
        <div className="space-y-3">
          {statusData?.slice(0, 2)?.map((item) => (
            <div key={item?.id} className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 ${item?.bgColor} rounded-lg flex items-center justify-center`}>
                  <Icon name={item?.icon} size={16} className={item?.color} />
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">{item?.title}</p>
                  <p className="text-xs text-muted-foreground">{item?.subtitle}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-lg font-bold text-foreground">{item?.value}</p>
                <div className="flex items-center gap-1">
                  <Icon name={item?.trendIcon} size={10} className={item?.trendColor} />
                  <span className={`text-xs ${item?.trendColor}`}>
                    {item?.trend?.split(' ')?.[0]}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default StatusCards;