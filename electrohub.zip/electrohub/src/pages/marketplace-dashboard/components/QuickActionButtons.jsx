import React from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const QuickActionButtons = () => {
  const quickActions = [
    {
      id: 1,
      title: "List Item",
      description: "Rent out your electronics",
      icon: "Plus",
      color: "bg-primary",
      textColor: "text-primary-foreground",
      route: "/product-listing-creation",
      stats: "Avg. $150/month"
    },
    {
      id: 2,
      title: "Find Rentals",
      description: "Browse available items",
      icon: "Search",
      color: "bg-secondary",
      textColor: "text-secondary-foreground",
      route: "/product-search-browse",
      stats: "1,200+ items"
    },
    {
      id: 3,
      title: "Schedule Pickup",
      description: "Recycle responsibly",
      icon: "Calendar",
      color: "bg-success",
      textColor: "text-success-foreground",
      route: "/rental-management",
      stats: "Free service"
    },
    {
      id: 4,
      title: "Live Auctions",
      description: "Bid on unique items",
      icon: "Gavel",
      color: "bg-warning",
      textColor: "text-warning-foreground",
      route: "/auction-bidding-interface",
      stats: "24 active"
    }
  ];

  return (
    <div className="space-y-6">
      {/* Desktop Layout */}
      <div className="hidden lg:block">
        <div className="bg-card rounded-lg border border-border p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-xl font-semibold text-foreground">Quick Actions</h2>
              <p className="text-sm text-muted-foreground">Get started with these popular features</p>
            </div>
          </div>
          
          <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
            {quickActions?.map((action) => (
              <Link key={action?.id} to={action?.route}>
                <div className="group relative overflow-hidden rounded-lg border border-border hover:border-primary/50 transition-all duration-200 hover:shadow-elevated">
                  <div className="p-6 space-y-4">
                    <div className="flex items-center justify-between">
                      <div className={`w-12 h-12 ${action?.color} rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform duration-200`}>
                        <Icon name={action?.icon} size={24} className={action?.textColor} />
                      </div>
                      <Icon name="ArrowUpRight" size={16} className="text-muted-foreground group-hover:text-primary transition-colors" />
                    </div>
                    
                    <div>
                      <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors">
                        {action?.title}
                      </h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        {action?.description}
                      </p>
                      <p className="text-xs font-medium text-primary mt-2">
                        {action?.stats}
                      </p>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>
      {/* Mobile Layout - Floating Action Buttons */}
      <div className="lg:hidden">
        <div className="bg-card rounded-lg border border-border p-4">
          <h2 className="text-lg font-semibold text-foreground mb-4">Quick Actions</h2>
          
          <div className="grid grid-cols-2 gap-3">
            {quickActions?.map((action) => (
              <Link key={action?.id} to={action?.route}>
                <div className="group relative overflow-hidden rounded-lg border border-border hover:border-primary/50 transition-all duration-200 active:scale-95">
                  <div className="p-4 text-center space-y-3">
                    <div className={`w-10 h-10 ${action?.color} rounded-lg flex items-center justify-center mx-auto group-hover:scale-110 transition-transform duration-200`}>
                      <Icon name={action?.icon} size={20} className={action?.textColor} />
                    </div>
                    
                    <div>
                      <h3 className="font-medium text-foreground text-sm group-hover:text-primary transition-colors">
                        {action?.title}
                      </h3>
                      <p className="text-xs text-muted-foreground mt-1">
                        {action?.description}
                      </p>
                      <p className="text-xs font-medium text-primary mt-1">
                        {action?.stats}
                      </p>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>
      {/* Floating Action Button for Mobile (Alternative) */}
      <div className="lg:hidden fixed bottom-6 right-6 z-50">
        <div className="relative">
          <Link to="/product-listing-creation">
            <Button
              size="lg"
              className="w-14 h-14 rounded-full shadow-elevated hover:shadow-lg transition-all duration-200"
            >
              <Icon name="Plus" size={24} />
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default QuickActionButtons;