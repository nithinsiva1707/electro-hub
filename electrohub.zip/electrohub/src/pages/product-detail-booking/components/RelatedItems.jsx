import React from 'react';
import Image from '../../../components/AppImage';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { Link } from 'react-router-dom';

const RelatedItems = ({ items, title = "Related Items" }) => {
  const getTypeIcon = (type) => {
    switch (type) {
      case 'rental': return 'Calendar';
      case 'auction': return 'Gavel';
      case 'purchase': return 'ShoppingCart';
      default: return 'Package';
    }
  };

  const getTypeColor = (type) => {
    switch (type) {
      case 'rental': return 'text-primary';
      case 'auction': return 'text-error';
      case 'purchase': return 'text-success';
      default: return 'text-muted-foreground';
    }
  };

  return (
    <div className="bg-background py-8">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-foreground">{title}</h2>
          <Button variant="outline" iconName="ArrowRight" iconPosition="right">
            View All
          </Button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {items?.map((item) => (
            <Link
              key={item?.id}
              to={`/product-detail-booking?id=${item?.id}`}
              className="group bg-card border border-border rounded-lg overflow-hidden hover:shadow-elevated transition-all duration-200"
            >
              {/* Image */}
              <div className="relative aspect-square overflow-hidden">
                <Image
                  src={item?.image}
                  alt={item?.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                />
                
                {/* Type Badge */}
                <div className="absolute top-2 left-2">
                  <div className={`flex items-center space-x-1 px-2 py-1 bg-white/90 backdrop-blur-sm rounded-full text-xs font-medium ${getTypeColor(item?.type)}`}>
                    <Icon name={getTypeIcon(item?.type)} size={12} />
                    <span className="capitalize">{item?.type}</span>
                  </div>
                </div>

                {/* Wishlist Button */}
                <button className="absolute top-2 right-2 w-8 h-8 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <Icon name="Heart" size={16} className="text-muted-foreground hover:text-error" />
                </button>

                {/* Condition Badge */}
                {item?.condition && (
                  <div className="absolute bottom-2 left-2">
                    <span className="px-2 py-1 bg-black/70 text-white text-xs rounded">
                      {item?.condition}
                    </span>
                  </div>
                )}
              </div>

              {/* Content */}
              <div className="p-4">
                <h3 className="font-semibold text-foreground mb-2 line-clamp-2 group-hover:text-primary transition-colors">
                  {item?.title}
                </h3>
                
                {/* Price */}
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <span className="text-lg font-bold text-primary">
                      ${item?.price}
                    </span>
                    {item?.type === 'rental' && (
                      <span className="text-sm text-muted-foreground">/day</span>
                    )}
                  </div>
                  {item?.originalPrice && (
                    <span className="text-sm text-muted-foreground line-through">
                      ${item?.originalPrice}
                    </span>
                  )}
                </div>

                {/* Seller Info */}
                <div className="flex items-center space-x-2 mb-3">
                  <Image
                    src={item?.seller?.avatar}
                    alt={item?.seller?.name}
                    className="w-5 h-5 rounded-full object-cover"
                  />
                  <span className="text-sm text-muted-foreground">{item?.seller?.name}</span>
                  {item?.seller?.isVerified && (
                    <Icon name="BadgeCheck" size={14} className="text-success" />
                  )}
                </div>

                {/* Rating */}
                <div className="flex items-center space-x-1 mb-3">
                  <div className="flex items-center space-x-1">
                    {[...Array(5)]?.map((_, i) => (
                      <Icon
                        key={i}
                        name="Star"
                        size={12}
                        className={i < Math.floor(item?.rating) ? 'text-warning fill-current' : 'text-muted-foreground'}
                      />
                    ))}
                  </div>
                  <span className="text-xs text-muted-foreground">
                    ({item?.reviewCount})
                  </span>
                </div>

                {/* Location */}
                <div className="flex items-center space-x-1 text-xs text-muted-foreground mb-3">
                  <Icon name="MapPin" size={12} />
                  <span>{item?.location}</span>
                </div>

                {/* Action Button */}
                <Button
                  variant="outline"
                  fullWidth
                  className="text-sm"
                  iconName={getTypeIcon(item?.type)}
                  iconPosition="left"
                >
                  {item?.type === 'rental' && 'Book Now'}
                  {item?.type === 'auction' && 'Place Bid'}
                  {item?.type === 'purchase' && 'Buy Now'}
                </Button>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
};

export default RelatedItems;