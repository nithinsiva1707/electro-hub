import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const RentalCalendar = ({ availability, onDateSelect, selectedDates, pricing }) => {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  
  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  const getDaysInMonth = (date) => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0)?.getDate();
  };

  const getFirstDayOfMonth = (date) => {
    return new Date(date.getFullYear(), date.getMonth(), 1)?.getDay();
  };

  const isDateAvailable = (date) => {
    const dateStr = date?.toISOString()?.split('T')?.[0];
    return availability?.includes(dateStr);
  };

  const isDateSelected = (date) => {
    const dateStr = date?.toISOString()?.split('T')?.[0];
    return selectedDates?.includes(dateStr);
  };

  const isDateInRange = (date) => {
    if (selectedDates?.length !== 2) return false;
    const dateStr = date?.toISOString()?.split('T')?.[0];
    const [start, end] = selectedDates?.sort();
    return dateStr > start && dateStr < end;
  };

  const getPriceForDate = (date) => {
    const dayOfWeek = date?.getDay();
    const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
    return isWeekend ? pricing?.weekend : pricing?.weekday;
  };

  const handleDateClick = (date) => {
    if (!isDateAvailable(date)) return;
    onDateSelect(date);
  };

  const navigateMonth = (direction) => {
    setCurrentMonth(prev => {
      const newMonth = new Date(prev);
      newMonth?.setMonth(prev?.getMonth() + direction);
      return newMonth;
    });
  };

  const renderCalendarDays = () => {
    const daysInMonth = getDaysInMonth(currentMonth);
    const firstDay = getFirstDayOfMonth(currentMonth);
    const days = [];

    // Empty cells for days before the first day of the month
    for (let i = 0; i < firstDay; i++) {
      days?.push(<div key={`empty-${i}`} className="h-10"></div>);
    }

    // Days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day);
      const isAvailable = isDateAvailable(date);
      const isSelected = isDateSelected(date);
      const isInRange = isDateInRange(date);
      const price = getPriceForDate(date);
      const isToday = date?.toDateString() === new Date()?.toDateString();

      days?.push(
        <button
          key={day}
          onClick={() => handleDateClick(date)}
          disabled={!isAvailable}
          className={`h-10 w-full rounded-lg text-sm font-medium transition-colors relative ${
            isSelected
              ? 'bg-primary text-primary-foreground'
              : isInRange
              ? 'bg-primary/20 text-primary'
              : isAvailable
              ? 'hover:bg-muted text-foreground'
              : 'text-muted-foreground cursor-not-allowed'
          } ${isToday ? 'ring-2 ring-primary ring-offset-2' : ''}`}
        >
          <div className="flex flex-col items-center justify-center h-full">
            <span>{day}</span>
            {isAvailable && (
              <span className="text-xs opacity-75">${price}</span>
            )}
          </div>
        </button>
      );
    }

    return days;
  };

  return (
    <div className="bg-card border border-border rounded-lg p-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-foreground">Select Rental Dates</h3>
        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            onClick={() => navigateMonth(-1)}
            className="p-2"
          >
            <Icon name="ChevronLeft" size={16} />
          </Button>
          <span className="text-sm font-medium text-foreground min-w-[120px] text-center">
            {monthNames?.[currentMonth?.getMonth()]} {currentMonth?.getFullYear()}
          </span>
          <Button
            variant="ghost"
            onClick={() => navigateMonth(1)}
            className="p-2"
          >
            <Icon name="ChevronRight" size={16} />
          </Button>
        </div>
      </div>
      {/* Calendar Grid */}
      <div className="grid grid-cols-7 gap-1 mb-4">
        {/* Day headers */}
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']?.map(day => (
          <div key={day} className="h-8 flex items-center justify-center text-xs font-medium text-muted-foreground">
            {day}
          </div>
        ))}
        {/* Calendar days */}
        {renderCalendarDays()}
      </div>
      {/* Legend */}
      <div className="flex flex-wrap gap-4 text-xs text-muted-foreground">
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 bg-primary rounded"></div>
          <span>Selected</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 bg-primary/20 rounded"></div>
          <span>In Range</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 bg-muted rounded"></div>
          <span>Available</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 bg-muted-foreground/20 rounded"></div>
          <span>Unavailable</span>
        </div>
      </div>
      {/* Pricing Info */}
      <div className="mt-4 p-3 bg-muted rounded-lg">
        <h4 className="text-sm font-medium text-foreground mb-2">Pricing</h4>
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Weekdays:</span>
          <span className="font-medium text-foreground">${pricing?.weekday}/day</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Weekends:</span>
          <span className="font-medium text-foreground">${pricing?.weekend}/day</span>
        </div>
      </div>
    </div>
  );
};

export default RentalCalendar;