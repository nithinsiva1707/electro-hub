import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const AuctionWidget = ({ auction, onPlaceBid }) => {
  const [timeLeft, setTimeLeft] = useState({});
  const [bidAmount, setBidAmount] = useState('');
  const [showBidHistory, setShowBidHistory] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date()?.getTime();
      const endTime = new Date(auction.endTime)?.getTime();
      const difference = endTime - now;

      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
          minutes: Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60)),
          seconds: Math.floor((difference % (1000 * 60)) / 1000)
        });
      } else {
        setTimeLeft({ expired: true });
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [auction?.endTime]);

  const suggestedBids = [
    auction?.currentBid + auction?.minIncrement,
    auction?.currentBid + auction?.minIncrement * 2,
    auction?.currentBid + auction?.minIncrement * 5
  ];

  const handleQuickBid = (amount) => {
    setBidAmount(amount?.toString());
  };

  const handlePlaceBid = () => {
    const amount = parseFloat(bidAmount);
    if (amount >= auction?.currentBid + auction?.minIncrement) {
      onPlaceBid(amount);
      setBidAmount('');
    }
  };

  const isValidBid = () => {
    const amount = parseFloat(bidAmount);
    return amount >= auction?.currentBid + auction?.minIncrement;
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6 space-y-6 sticky top-24">
      {/* Auction Header */}
      <div className="text-center border-b border-border pb-4">
        <h3 className="text-lg font-semibold text-foreground mb-2">Live Auction</h3>
        <div className="text-3xl font-bold text-primary mb-1">
          ${auction?.currentBid?.toLocaleString()}
        </div>
        <p className="text-sm text-muted-foreground">Current Highest Bid</p>
      </div>
      {/* Countdown Timer */}
      {!timeLeft?.expired ? (
        <div className="bg-error/10 border border-error/20 rounded-lg p-4">
          <div className="text-center">
            <h4 className="text-sm font-medium text-error mb-2">Auction Ends In</h4>
            <div className="grid grid-cols-4 gap-2 text-center">
              <div className="bg-error text-white rounded-lg p-2">
                <div className="text-lg font-bold">{timeLeft?.days || 0}</div>
                <div className="text-xs">Days</div>
              </div>
              <div className="bg-error text-white rounded-lg p-2">
                <div className="text-lg font-bold">{timeLeft?.hours || 0}</div>
                <div className="text-xs">Hours</div>
              </div>
              <div className="bg-error text-white rounded-lg p-2">
                <div className="text-lg font-bold">{timeLeft?.minutes || 0}</div>
                <div className="text-xs">Min</div>
              </div>
              <div className="bg-error text-white rounded-lg p-2">
                <div className="text-lg font-bold">{timeLeft?.seconds || 0}</div>
                <div className="text-xs">Sec</div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-muted border border-border rounded-lg p-4 text-center">
          <Icon name="Clock" size={24} className="text-muted-foreground mx-auto mb-2" />
          <h4 className="text-lg font-semibold text-foreground">Auction Ended</h4>
          <p className="text-sm text-muted-foreground">This auction has concluded</p>
        </div>
      )}
      {/* Auction Stats */}
      <div className="grid grid-cols-2 gap-4">
        <div className="text-center p-3 bg-muted rounded-lg">
          <div className="text-lg font-semibold text-foreground">{auction?.totalBids}</div>
          <div className="text-xs text-muted-foreground">Total Bids</div>
        </div>
        <div className="text-center p-3 bg-muted rounded-lg">
          <div className="text-lg font-semibold text-foreground">{auction?.watchers}</div>
          <div className="text-xs text-muted-foreground">Watchers</div>
        </div>
      </div>
      {/* Bidding Section */}
      {!timeLeft?.expired && (
        <>
          {/* Quick Bid Buttons */}
          <div>
            <h4 className="text-sm font-medium text-foreground mb-3">Quick Bid</h4>
            <div className="grid grid-cols-3 gap-2">
              {suggestedBids?.map((amount, index) => (
                <Button
                  key={index}
                  variant="outline"
                  onClick={() => handleQuickBid(amount)}
                  className="text-xs"
                >
                  ${amount}
                </Button>
              ))}
            </div>
          </div>

          {/* Custom Bid Input */}
          <div>
            <Input
              label="Your Bid Amount"
              type="number"
              placeholder={`Min: $${auction?.currentBid + auction?.minIncrement}`}
              value={bidAmount}
              onChange={(e) => setBidAmount(e?.target?.value)}
              description={`Minimum increment: $${auction?.minIncrement}`}
              error={bidAmount && !isValidBid() ? 'Bid must be higher than current bid + minimum increment' : ''}
            />
          </div>

          {/* Place Bid Button */}
          <Button
            variant="default"
            fullWidth
            onClick={handlePlaceBid}
            disabled={!bidAmount || !isValidBid()}
            iconName="Gavel"
            iconPosition="left"
          >
            Place Bid
          </Button>
        </>
      )}
      {/* Bid History */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h4 className="text-sm font-medium text-foreground">Bid History</h4>
          <Button
            variant="ghost"
            onClick={() => setShowBidHistory(!showBidHistory)}
            className="text-xs"
          >
            {showBidHistory ? 'Hide' : 'Show All'}
          </Button>
        </div>
        
        <div className="space-y-2 max-h-48 overflow-y-auto">
          {(showBidHistory ? auction?.bidHistory : auction?.bidHistory?.slice(0, 3))?.map((bid, index) => (
            <div key={index} className="flex items-center justify-between p-2 bg-muted rounded-lg">
              <div className="flex items-center space-x-2">
                <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center">
                  <span className="text-xs text-white font-medium">
                    {bid?.bidderName?.charAt(0)}
                  </span>
                </div>
                <div>
                  <div className="text-sm font-medium text-foreground">
                    {bid?.bidderName}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {new Date(bid.timestamp)?.toLocaleString()}
                  </div>
                </div>
              </div>
              <div className="text-sm font-semibold text-foreground">
                ${bid?.amount?.toLocaleString()}
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Auction Info */}
      <div className="border-t border-border pt-4 space-y-2">
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">Starting Bid:</span>
          <span className="font-medium text-foreground">${auction?.startingBid}</span>
        </div>
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">Reserve Price:</span>
          <span className="font-medium text-foreground">
            {auction?.reserveMet ? 'Met' : 'Not Met'}
          </span>
        </div>
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">Shipping:</span>
          <span className="font-medium text-foreground">
            {auction?.shippingCost === 0 ? 'Free' : `$${auction?.shippingCost}`}
          </span>
        </div>
      </div>
      {/* Action Buttons */}
      <div className="grid grid-cols-2 gap-2">
        <Button variant="outline" fullWidth iconName="Eye" iconPosition="left">
          Watch
        </Button>
        <Button variant="outline" fullWidth iconName="Share" iconPosition="left">
          Share
        </Button>
      </div>
      {/* Trust Indicators */}
      <div className="border-t border-border pt-4 space-y-2">
        <div className="flex items-center space-x-2 text-xs text-muted-foreground">
          <Icon name="Shield" size={14} className="text-success" />
          <span>Buyer protection included</span>
        </div>
        <div className="flex items-center space-x-2 text-xs text-muted-foreground">
          <Icon name="CreditCard" size={14} className="text-primary" />
          <span>Secure payment processing</span>
        </div>
        <div className="flex items-center space-x-2 text-xs text-muted-foreground">
          <Icon name="Truck" size={14} className="text-secondary" />
          <span>Insured shipping available</span>
        </div>
      </div>
    </div>
  );
};

export default AuctionWidget;