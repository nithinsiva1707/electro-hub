import React from 'react';
import Icon from '../../../components/AppIcon';

const ProductInfo = ({ product }) => {
  const getConditionColor = (condition) => {
    switch (condition?.toLowerCase()) {
      case 'excellent': return 'text-success';
      case 'good': return 'text-primary';
      case 'fair': return 'text-warning';
      case 'poor': return 'text-error';
      default: return 'text-muted-foreground';
    }
  };

  const getConditionIcon = (condition) => {
    switch (condition?.toLowerCase()) {
      case 'excellent': return 'Star';
      case 'good': return 'ThumbsUp';
      case 'fair': return 'AlertCircle';
      case 'poor': return 'AlertTriangle';
      default: return 'Info';
    }
  };

  return (
    <div className="space-y-6">
      {/* Title and Price */}
      <div>
        <h1 className="text-2xl lg:text-3xl font-bold text-foreground mb-2">
          {product?.title}
        </h1>
        <div className="flex items-center space-x-4">
          <span className="text-2xl lg:text-3xl font-bold text-primary">
            ${product?.price}
            {product?.type === 'rental' && <span className="text-base font-normal text-muted-foreground">/day</span>}
          </span>
          {product?.originalPrice && (
            <span className="text-lg text-muted-foreground line-through">
              ${product?.originalPrice}
            </span>
          )}
        </div>
      </div>
      {/* Condition Assessment */}
      <div className="flex items-center space-x-3 p-3 bg-muted rounded-lg">
        <Icon 
          name={getConditionIcon(product?.condition)} 
          size={20} 
          className={getConditionColor(product?.condition)} 
        />
        <div>
          <span className="font-medium text-foreground">Condition: </span>
          <span className={`font-semibold ${getConditionColor(product?.condition)}`}>
            {product?.condition}
          </span>
        </div>
        <div className="flex items-center space-x-1">
          {[...Array(5)]?.map((_, i) => (
            <Icon
              key={i}
              name="Star"
              size={16}
              className={i < product?.conditionRating ? 'text-warning fill-current' : 'text-muted-foreground'}
            />
          ))}
          <span className="text-sm text-muted-foreground ml-1">
            ({product?.conditionRating}/5)
          </span>
        </div>
      </div>
      {/* Key Features */}
      <div>
        <h3 className="text-lg font-semibold text-foreground mb-3">Key Features</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {product?.features?.map((feature, index) => (
            <div key={index} className="flex items-center space-x-2">
              <Icon name="Check" size={16} className="text-success" />
              <span className="text-sm text-foreground">{feature}</span>
            </div>
          ))}
        </div>
      </div>
      {/* Specifications */}
      <div>
        <h3 className="text-lg font-semibold text-foreground mb-3">Specifications</h3>
        <div className="space-y-2">
          {Object.entries(product?.specifications)?.map(([key, value]) => (
            <div key={key} className="flex justify-between py-2 border-b border-border last:border-b-0">
              <span className="text-sm font-medium text-muted-foreground capitalize">
                {key?.replace(/([A-Z])/g, ' $1')?.trim()}
              </span>
              <span className="text-sm text-foreground">{value}</span>
            </div>
          ))}
        </div>
      </div>
      {/* Description */}
      <div>
        <h3 className="text-lg font-semibold text-foreground mb-3">Description</h3>
        <p className="text-sm text-muted-foreground leading-relaxed">
          {product?.description}
        </p>
      </div>
      {/* Tags */}
      {product?.tags && product?.tags?.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold text-foreground mb-3">Tags</h3>
          <div className="flex flex-wrap gap-2">
            {product?.tags?.map((tag, index) => (
              <span
                key={index}
                className="px-3 py-1 bg-secondary/10 text-secondary text-sm rounded-full"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default ProductInfo;