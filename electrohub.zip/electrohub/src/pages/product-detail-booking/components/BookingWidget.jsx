import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import { Checkbox } from '../../../components/ui/Checkbox';

const BookingWidget = ({ product, selectedDates, onBookingSubmit }) => {
  const [quantity, setQuantity] = useState(1);
  const [selectedInsurance, setSelectedInsurance] = useState([]);
  const [deliveryOption, setDeliveryOption] = useState('pickup');
  const [deliveryAddress, setDeliveryAddress] = useState('');

  const insuranceOptions = [
    { id: 'basic', name: 'Basic Protection', price: 5, description: 'Covers accidental damage up to $500' },
    { id: 'premium', name: 'Premium Protection', price: 15, description: 'Full coverage including theft and loss' },
    { id: 'extended', name: 'Extended Warranty', price: 10, description: 'Additional 6 months warranty' }
  ];

  const deliveryOptions = [
    { id: 'pickup', name: 'Self Pickup', price: 0, description: 'Pick up from seller location' },
    { id: 'delivery', name: 'Home Delivery', price: 25, description: 'Delivered to your address' },
    { id: 'express', name: 'Express Delivery', price: 45, description: 'Same day delivery (if available)' }
  ];

  const calculateTotal = () => {
    let total = 0;
    
    if (product?.type === 'rental' && selectedDates?.length === 2) {
      const startDate = new Date(selectedDates[0]);
      const endDate = new Date(selectedDates[1]);
      const days = Math.ceil((endDate - startDate) / (1000 * 60 * 60 * 24));
      total = product?.price * days * quantity;
    } else if (product?.type === 'purchase') {
      total = product?.price * quantity;
    }

    // Add insurance costs
    const insuranceCost = selectedInsurance?.reduce((sum, insuranceId) => {
      const insurance = insuranceOptions?.find(opt => opt?.id === insuranceId);
      return sum + (insurance ? insurance?.price : 0);
    }, 0);

    // Add delivery cost
    const deliveryCost = deliveryOptions?.find(opt => opt?.id === deliveryOption)?.price || 0;

    return {
      subtotal: total,
      insurance: insuranceCost,
      delivery: deliveryCost,
      total: total + insuranceCost + deliveryCost
    };
  };

  const handleInsuranceChange = (insuranceId, checked) => {
    if (checked) {
      setSelectedInsurance(prev => [...prev, insuranceId]);
    } else {
      setSelectedInsurance(prev => prev?.filter(id => id !== insuranceId));
    }
  };

  const handleBookingSubmit = () => {
    const bookingData = {
      productId: product?.id,
      quantity,
      selectedDates,
      insurance: selectedInsurance,
      delivery: deliveryOption,
      deliveryAddress: deliveryOption !== 'pickup' ? deliveryAddress : null,
      total: calculateTotal()?.total
    };
    onBookingSubmit(bookingData);
  };

  const costs = calculateTotal();
  const canBook = product?.type === 'rental' ? selectedDates?.length === 2 : true;

  return (
    <div className="bg-card border border-border rounded-lg p-6 space-y-6 sticky top-24">
      <div className="border-b border-border pb-4">
        <h3 className="text-lg font-semibold text-foreground mb-2">
          {product?.type === 'rental' ? 'Book Rental' : 'Purchase Details'}
        </h3>
        <div className="text-2xl font-bold text-primary">
          ${product?.price}
          {product?.type === 'rental' && <span className="text-sm font-normal text-muted-foreground">/day</span>}
        </div>
      </div>
      {/* Quantity Selector */}
      {product?.type === 'purchase' && (
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Quantity</label>
          <div className="flex items-center space-x-3">
            <Button
              variant="outline"
              onClick={() => setQuantity(Math.max(1, quantity - 1))}
              disabled={quantity <= 1}
              className="w-10 h-10 p-0"
            >
              <Icon name="Minus" size={16} />
            </Button>
            <span className="text-lg font-medium text-foreground min-w-[2rem] text-center">
              {quantity}
            </span>
            <Button
              variant="outline"
              onClick={() => setQuantity(quantity + 1)}
              disabled={quantity >= product?.maxQuantity}
              className="w-10 h-10 p-0"
            >
              <Icon name="Plus" size={16} />
            </Button>
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            {product?.maxQuantity} available
          </p>
        </div>
      )}
      {/* Rental Duration Display */}
      {product?.type === 'rental' && selectedDates?.length === 2 && (
        <div className="p-3 bg-muted rounded-lg">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Duration:</span>
            <span className="font-medium text-foreground">
              {Math.ceil((new Date(selectedDates[1]) - new Date(selectedDates[0])) / (1000 * 60 * 60 * 24))} days
            </span>
          </div>
          <div className="flex items-center justify-between text-sm mt-1">
            <span className="text-muted-foreground">From:</span>
            <span className="font-medium text-foreground">
              {new Date(selectedDates[0])?.toLocaleDateString()}
            </span>
          </div>
          <div className="flex items-center justify-between text-sm mt-1">
            <span className="text-muted-foreground">To:</span>
            <span className="font-medium text-foreground">
              {new Date(selectedDates[1])?.toLocaleDateString()}
            </span>
          </div>
        </div>
      )}
      {/* Insurance Options */}
      <div>
        <h4 className="text-sm font-medium text-foreground mb-3">Protection & Insurance</h4>
        <div className="space-y-3">
          {insuranceOptions?.map((insurance) => (
            <div key={insurance?.id} className="flex items-start space-x-3">
              <Checkbox
                checked={selectedInsurance?.includes(insurance?.id)}
                onChange={(e) => handleInsuranceChange(insurance?.id, e?.target?.checked)}
                className="mt-1"
              />
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-foreground">{insurance?.name}</span>
                  <span className="text-sm font-medium text-foreground">+${insurance?.price}</span>
                </div>
                <p className="text-xs text-muted-foreground">{insurance?.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Delivery Options */}
      <div>
        <h4 className="text-sm font-medium text-foreground mb-3">Delivery Options</h4>
        <div className="space-y-2">
          {deliveryOptions?.map((option) => (
            <label key={option?.id} className="flex items-center space-x-3 cursor-pointer">
              <input
                type="radio"
                name="delivery"
                value={option?.id}
                checked={deliveryOption === option?.id}
                onChange={(e) => setDeliveryOption(e?.target?.value)}
                className="w-4 h-4 text-primary"
              />
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-foreground">{option?.name}</span>
                  <span className="text-sm font-medium text-foreground">
                    {option?.price === 0 ? 'Free' : `$${option?.price}`}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground">{option?.description}</p>
              </div>
            </label>
          ))}
        </div>

        {/* Delivery Address */}
        {deliveryOption !== 'pickup' && (
          <div className="mt-3">
            <Input
              label="Delivery Address"
              type="text"
              placeholder="Enter your delivery address"
              value={deliveryAddress}
              onChange={(e) => setDeliveryAddress(e?.target?.value)}
              required
            />
          </div>
        )}
      </div>
      {/* Cost Breakdown */}
      <div className="border-t border-border pt-4 space-y-2">
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">Subtotal:</span>
          <span className="font-medium text-foreground">${costs?.subtotal}</span>
        </div>
        {costs?.insurance > 0 && (
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Insurance:</span>
            <span className="font-medium text-foreground">${costs?.insurance}</span>
          </div>
        )}
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">Delivery:</span>
          <span className="font-medium text-foreground">
            {costs?.delivery === 0 ? 'Free' : `$${costs?.delivery}`}
          </span>
        </div>
        <div className="flex items-center justify-between text-base font-semibold border-t border-border pt-2">
          <span className="text-foreground">Total:</span>
          <span className="text-primary">${costs?.total}</span>
        </div>
      </div>
      {/* Action Buttons */}
      <div className="space-y-3">
        <Button
          variant="default"
          fullWidth
          onClick={handleBookingSubmit}
          disabled={!canBook || (deliveryOption !== 'pickup' && !deliveryAddress)}
          iconName={product?.type === 'rental' ? 'Calendar' : 'ShoppingCart'}
          iconPosition="left"
        >
          {product?.type === 'rental' ? 'Book Now' : 'Add to Cart'}
        </Button>
        
        <div className="grid grid-cols-2 gap-2">
          <Button variant="outline" fullWidth iconName="Heart" iconPosition="left">
            Wishlist
          </Button>
          <Button variant="outline" fullWidth iconName="Share" iconPosition="left">
            Share
          </Button>
        </div>
      </div>
      {/* Trust Indicators */}
      <div className="border-t border-border pt-4 space-y-2">
        <div className="flex items-center space-x-2 text-xs text-muted-foreground">
          <Icon name="Shield" size={14} className="text-success" />
          <span>Secure payment processing</span>
        </div>
        <div className="flex items-center space-x-2 text-xs text-muted-foreground">
          <Icon name="Truck" size={14} className="text-primary" />
          <span>Free returns within 7 days</span>
        </div>
        <div className="flex items-center space-x-2 text-xs text-muted-foreground">
          <Icon name="MessageCircle" size={14} className="text-secondary" />
          <span>24/7 customer support</span>
        </div>
      </div>
    </div>
  );
};

export default BookingWidget;