import React, { useState } from 'react';
import Image from '../../../components/AppImage';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const SellerProfile = ({ seller }) => {
  const [showAllReviews, setShowAllReviews] = useState(false);

  const displayedReviews = showAllReviews ? seller?.reviews : seller?.reviews?.slice(0, 3);

  return (
    <div className="bg-card border border-border rounded-lg p-6 space-y-6">
      {/* Seller Header */}
      <div className="flex items-start space-x-4">
        <div className="relative">
          <Image
            src={seller?.avatar}
            alt={seller?.name}
            className="w-16 h-16 rounded-full object-cover"
          />
          {seller?.isVerified && (
            <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-success rounded-full flex items-center justify-center">
              <Icon name="Check" size={12} color="white" />
            </div>
          )}
        </div>
        <div className="flex-1">
          <div className="flex items-center space-x-2 mb-1">
            <h3 className="text-lg font-semibold text-foreground">{seller?.name}</h3>
            {seller?.isPowerSeller && (
              <span className="px-2 py-1 bg-warning/10 text-warning text-xs font-medium rounded">
                Power Seller
              </span>
            )}
          </div>
          <div className="flex items-center space-x-4 text-sm text-muted-foreground">
            <div className="flex items-center space-x-1">
              <Icon name="Star" size={14} className="text-warning fill-current" />
              <span>{seller?.rating}</span>
              <span>({seller?.totalReviews} reviews)</span>
            </div>
            <div className="flex items-center space-x-1">
              <Icon name="Clock" size={14} />
              <span>Responds in {seller?.responseTime}</span>
            </div>
          </div>
        </div>
      </div>
      {/* Seller Stats */}
      <div className="grid grid-cols-3 gap-4 py-4 border-t border-b border-border">
        <div className="text-center">
          <div className="text-lg font-semibold text-foreground">{seller?.totalListings}</div>
          <div className="text-xs text-muted-foreground">Active Listings</div>
        </div>
        <div className="text-center">
          <div className="text-lg font-semibold text-foreground">{seller?.completedDeals}</div>
          <div className="text-xs text-muted-foreground">Completed Deals</div>
        </div>
        <div className="text-center">
          <div className="text-lg font-semibold text-foreground">{seller?.memberSince}</div>
          <div className="text-xs text-muted-foreground">Member Since</div>
        </div>
      </div>
      {/* Verification Badges */}
      <div>
        <h4 className="text-sm font-medium text-foreground mb-3">Verifications</h4>
        <div className="flex flex-wrap gap-2">
          {seller?.verifications?.map((verification, index) => (
            <div
              key={index}
              className="flex items-center space-x-1 px-2 py-1 bg-success/10 text-success text-xs rounded"
            >
              <Icon name="Shield" size={12} />
              <span>{verification}</span>
            </div>
          ))}
        </div>
      </div>
      {/* Recent Reviews */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h4 className="text-sm font-medium text-foreground">Recent Reviews</h4>
          {seller?.reviews?.length > 3 && (
            <Button
              variant="ghost"
              onClick={() => setShowAllReviews(!showAllReviews)}
              className="text-xs"
            >
              {showAllReviews ? 'Show Less' : `View All (${seller?.reviews?.length})`}
            </Button>
          )}
        </div>
        <div className="space-y-3">
          {displayedReviews?.map((review, index) => (
            <div key={index} className="p-3 bg-muted rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-2">
                  <Image
                    src={review?.reviewerAvatar}
                    alt={review?.reviewerName}
                    className="w-6 h-6 rounded-full object-cover"
                  />
                  <span className="text-sm font-medium text-foreground">
                    {review?.reviewerName}
                  </span>
                </div>
                <div className="flex items-center space-x-1">
                  {[...Array(5)]?.map((_, i) => (
                    <Icon
                      key={i}
                      name="Star"
                      size={12}
                      className={i < review?.rating ? 'text-warning fill-current' : 'text-muted-foreground'}
                    />
                  ))}
                </div>
              </div>
              <p className="text-xs text-muted-foreground">{review?.comment}</p>
              <span className="text-xs text-muted-foreground">{review?.date}</span>
            </div>
          ))}
        </div>
      </div>
      {/* Action Buttons */}
      <div className="space-y-2">
        <Button variant="outline" fullWidth iconName="MessageCircle" iconPosition="left">
          Message Seller
        </Button>
        <Button variant="ghost" fullWidth iconName="Flag" iconPosition="left">
          Report Listing
        </Button>
      </div>
    </div>
  );
};

export default SellerProfile;