import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import Header from '../../components/ui/Header';
import ImageGallery from './components/ImageGallery';
import ProductInfo from './components/ProductInfo';
import SellerProfile from './components/SellerProfile';
import RentalCalendar from './components/RentalCalendar';
import BookingWidget from './components/BookingWidget';
import AuctionWidget from './components/AuctionWidget';
import RelatedItems from './components/RelatedItems';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const ProductDetailBooking = () => {
  const [searchParams] = useSearchParams();
  const productId = searchParams?.get('id') || '1';
  
  const [selectedDates, setSelectedDates] = useState([]);
  const [activeTab, setActiveTab] = useState('details');

  // Mock product data
  const mockProduct = {
    id: productId,
    title: "MacBook Pro 16-inch M2 Max - Space Gray",
    price: 45,
    originalPrice: 55,
    type: 'rental', // 'rental', 'purchase', 'auction\'condition: \'Excellent',
    conditionRating: 5,
    maxQuantity: 3,
    images: [
      "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=800&h=800&fit=crop",
      "https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=800&h=800&fit=crop",
      "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=800&h=800&fit=crop",
      "https://images.unsplash.com/photo-1515343480029-43cdfe6b6dae?w=800&h=800&fit=crop"
    ],
    features: [
      "Apple M2 Max chip with 12-core CPU",
      "38-core GPU for graphics-intensive tasks",
      "32GB unified memory",
      "1TB SSD storage",
      "16-inch Liquid Retina XDR display",
      "1080p FaceTime HD camera"
    ],
    specifications: {
      brand: "Apple",
      model: "MacBook Pro 16-inch",
      processor: "Apple M2 Max",
      memory: "32GB",
      storage: "1TB SSD",
      display: "16-inch Liquid Retina XDR",
      weight: "4.7 lbs",
      color: "Space Gray",
      year: "2023"
    },
    description: `Experience unprecedented performance with the MacBook Pro 16-inch featuring the powerful M2 Max chip. This laptop is perfect for creative professionals, developers, and power users who demand the best.\n\nThe stunning Liquid Retina XDR display delivers exceptional color accuracy and brightness, making it ideal for photo and video editing. With up to 22 hours of battery life, you can work all day without worrying about charging.\n\nThis rental unit has been carefully maintained and comes with the original charger and documentation. Perfect for short-term projects, travel, or trying before you buy.`,
    tags: ["Apple", "MacBook", "M2 Max", "Professional", "Creative", "High Performance"],
    seller: {
      id: "seller123",
      name: "TechRentals Pro",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face",
      rating: 4.9,
      totalReviews: 1247,
      responseTime: "2 hours",
      isVerified: true,
      isPowerSeller: true,
      totalListings: 156,
      completedDeals: 892,
      memberSince: "2019",
      verifications: ["Identity Verified", "Phone Verified", "Business Verified"],
      reviews: [
        {
          reviewerName: "Sarah Johnson",
          reviewerAvatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=50&h=50&fit=crop&crop=face",
          rating: 5,
          comment: "Excellent service! The MacBook was in perfect condition and exactly as described.",
          date: "2 days ago"
        },
        {
          reviewerName: "Mike Chen",
          reviewerAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=50&h=50&fit=crop&crop=face",
          rating: 5,
          comment: "Fast delivery and great communication. Highly recommended seller!",
          date: "1 week ago"
        },
        {
          reviewerName: "Emily Davis",
          reviewerAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=50&h=50&fit=crop&crop=face",
          rating: 4,
          comment: "Good experience overall. The laptop worked perfectly for my project.",
          date: "2 weeks ago"
        }
      ]
    }
  };

  // Mock auction data (when product type is auction)
  const mockAuction = {
    currentBid: 1250,
    startingBid: 800,
    minIncrement: 25,
    totalBids: 23,
    watchers: 47,
    endTime: "2025-01-05T18:00:00Z",
    reserveMet: true,
    shippingCost: 0,
    bidHistory: [
      {
        bidderName: "TechCollector",
        amount: 1250,
        timestamp: "2025-01-01T14:30:00Z"
      },
      {
        bidderName: "GadgetLover",
        amount: 1225,
        timestamp: "2025-01-01T14:15:00Z"
      },
      {
        bidderName: "AppleFan2023",
        amount: 1200,
        timestamp: "2025-01-01T13:45:00Z"
      }
    ]
  };

  // Mock availability data for rental calendar
  const mockAvailability = [
    "2025-01-02", "2025-01-03", "2025-01-04", "2025-01-05", "2025-01-06",
    "2025-01-08", "2025-01-09", "2025-01-10", "2025-01-11", "2025-01-12",
    "2025-01-15", "2025-01-16", "2025-01-17", "2025-01-18", "2025-01-19",
    "2025-01-22", "2025-01-23", "2025-01-24", "2025-01-25", "2025-01-26"
  ];

  const mockPricing = {
    weekday: 45,
    weekend: 55
  };

  // Mock related items
  const mockRelatedItems = [
    {
      id: "2",
      title: "iPad Pro 12.9-inch M2",
      price: 25,
      originalPrice: 30,
      type: "rental",
      condition: "Excellent",
      image: "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=400&h=400&fit=crop",
      rating: 4.8,
      reviewCount: 156,
      location: "New York, NY",
      seller: {
        name: "TechRentals Pro",
        avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=50&h=50&fit=crop&crop=face",
        isVerified: true
      }
    },
    {
      id: "3",
      title: "Dell XPS 15 Gaming Laptop",
      price: 1899,
      type: "purchase",
      condition: "Good",
      image: "https://images.unsplash.com/photo-1593642632823-8f785ba67e45?w=400&h=400&fit=crop",
      rating: 4.6,
      reviewCount: 89,
      location: "Los Angeles, CA",
      seller: {
        name: "ElectroDeals",
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=50&h=50&fit=crop&crop=face",
        isVerified: true
      }
    },
    {
      id: "4",
      title: "Vintage Apple iMac G3",
      price: 450,
      type: "auction",
      condition: "Fair",
      image: "https://images.unsplash.com/photo-1517077304055-6e89abbf09b0?w=400&h=400&fit=crop",
      rating: 4.2,
      reviewCount: 34,
      location: "Chicago, IL",
      seller: {
        name: "RetroTech",
        avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=50&h=50&fit=crop&crop=face",
        isVerified: false
      }
    },
    {
      id: "5",
      title: "Microsoft Surface Studio 2",
      price: 35,
      type: "rental",
      condition: "Excellent",
      image: "https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=400&h=400&fit=crop",
      rating: 4.9,
      reviewCount: 203,
      location: "Seattle, WA",
      seller: {
        name: "CreativeRentals",
        avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=50&h=50&fit=crop&crop=face",
        isVerified: true
      }
    }
  ];

  const handleDateSelect = (date) => {
    const dateStr = date?.toISOString()?.split('T')?.[0];
    
    if (selectedDates?.length === 0) {
      setSelectedDates([dateStr]);
    } else if (selectedDates?.length === 1) {
      const existingDate = new Date(selectedDates[0]);
      if (date > existingDate) {
        setSelectedDates([selectedDates?.[0], dateStr]);
      } else {
        setSelectedDates([dateStr, selectedDates?.[0]]);
      }
    } else {
      setSelectedDates([dateStr]);
    }
  };

  const handleBookingSubmit = (bookingData) => {
    console.log('Booking submitted:', bookingData);
    // Handle booking submission
  };

  const handlePlaceBid = (bidAmount) => {
    console.log('Bid placed:', bidAmount);
    // Handle bid placement
  };

  const tabs = [
    { id: 'details', label: 'Details', icon: 'Info' },
    { id: 'specifications', label: 'Specs', icon: 'Settings' },
    { id: 'reviews', label: 'Reviews', icon: 'Star' },
    { id: 'shipping', label: 'Shipping', icon: 'Truck' }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-16">
        {/* Breadcrumb */}
        <div className="bg-muted border-b border-border">
          <div className="max-w-7xl mx-auto px-6 py-4">
            <nav className="flex items-center space-x-2 text-sm">
              <a href="/marketplace-dashboard" className="text-muted-foreground hover:text-foreground">
                Home
              </a>
              <Icon name="ChevronRight" size={14} className="text-muted-foreground" />
              <a href="/product-search-browse" className="text-muted-foreground hover:text-foreground">
                Electronics
              </a>
              <Icon name="ChevronRight" size={14} className="text-muted-foreground" />
              <span className="text-foreground">Laptops</span>
            </nav>
          </div>
        </div>

        {/* Main Content */}
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left Column - Images and Details */}
            <div className="lg:col-span-2 space-y-8">
              {/* Image Gallery */}
              <ImageGallery 
                images={mockProduct?.images} 
                productName={mockProduct?.title} 
              />

              {/* Mobile Action Bar */}
              <div className="lg:hidden sticky bottom-0 left-0 right-0 bg-card border-t border-border p-4 z-10">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <div className="text-2xl font-bold text-primary">
                      ${mockProduct?.price}
                      {mockProduct?.type === 'rental' && <span className="text-sm font-normal text-muted-foreground">/day</span>}
                    </div>
                    {selectedDates?.length === 2 && mockProduct?.type === 'rental' && (
                      <div className="text-sm text-muted-foreground">
                        {Math.ceil((new Date(selectedDates[1]) - new Date(selectedDates[0])) / (1000 * 60 * 60 * 24))} days selected
                      </div>
                    )}
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button variant="outline" className="p-2">
                      <Icon name="Heart" size={20} />
                    </Button>
                    <Button variant="outline" className="p-2">
                      <Icon name="Share" size={20} />
                    </Button>
                  </div>
                </div>
                <Button
                  variant="default"
                  fullWidth
                  iconName={mockProduct?.type === 'rental' ? 'Calendar' : mockProduct?.type === 'auction' ? 'Gavel' : 'ShoppingCart'}
                  iconPosition="left"
                >
                  {mockProduct?.type === 'rental' && 'Book Now'}
                  {mockProduct?.type === 'auction' && 'Place Bid'}
                  {mockProduct?.type === 'purchase' && 'Buy Now'}
                </Button>
              </div>

              {/* Tabs */}
              <div className="border-b border-border">
                <nav className="flex space-x-8">
                  {tabs?.map((tab) => (
                    <button
                      key={tab?.id}
                      onClick={() => setActiveTab(tab?.id)}
                      className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                        activeTab === tab?.id
                          ? 'border-primary text-primary' :'border-transparent text-muted-foreground hover:text-foreground hover:border-muted-foreground'
                      }`}
                    >
                      <Icon name={tab?.icon} size={16} />
                      <span>{tab?.label}</span>
                    </button>
                  ))}
                </nav>
              </div>

              {/* Tab Content */}
              <div className="min-h-[400px]">
                {activeTab === 'details' && (
                  <ProductInfo product={mockProduct} />
                )}
                
                {activeTab === 'specifications' && (
                  <div className="space-y-4">
                    <h3 className="text-xl font-semibold text-foreground">Technical Specifications</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {Object.entries(mockProduct?.specifications)?.map(([key, value]) => (
                        <div key={key} className="flex justify-between py-3 border-b border-border">
                          <span className="font-medium text-muted-foreground capitalize">
                            {key?.replace(/([A-Z])/g, ' $1')?.trim()}
                          </span>
                          <span className="text-foreground">{value}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                {activeTab === 'reviews' && (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <h3 className="text-xl font-semibold text-foreground">Customer Reviews</h3>
                      <div className="flex items-center space-x-2">
                        <div className="flex items-center space-x-1">
                          {[...Array(5)]?.map((_, i) => (
                            <Icon
                              key={i}
                              name="Star"
                              size={16}
                              className={i < Math.floor(mockProduct?.seller?.rating) ? 'text-warning fill-current' : 'text-muted-foreground'}
                            />
                          ))}
                        </div>
                        <span className="text-lg font-semibold text-foreground">{mockProduct?.seller?.rating}</span>
                        <span className="text-muted-foreground">({mockProduct?.seller?.totalReviews} reviews)</span>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      {mockProduct?.seller?.reviews?.map((review, index) => (
                        <div key={index} className="p-4 bg-card border border-border rounded-lg">
                          <div className="flex items-center space-x-3 mb-3">
                            <img
                              src={review?.reviewerAvatar}
                              alt={review?.reviewerName}
                              className="w-10 h-10 rounded-full object-cover"
                            />
                            <div>
                              <div className="font-medium text-foreground">{review?.reviewerName}</div>
                              <div className="flex items-center space-x-2">
                                <div className="flex items-center space-x-1">
                                  {[...Array(5)]?.map((_, i) => (
                                    <Icon
                                      key={i}
                                      name="Star"
                                      size={12}
                                      className={i < review?.rating ? 'text-warning fill-current' : 'text-muted-foreground'}
                                    />
                                  ))}
                                </div>
                                <span className="text-sm text-muted-foreground">{review?.date}</span>
                              </div>
                            </div>
                          </div>
                          <p className="text-muted-foreground">{review?.comment}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                {activeTab === 'shipping' && (
                  <div className="space-y-6">
                    <h3 className="text-xl font-semibold text-foreground">Shipping & Returns</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <div className="flex items-center space-x-3">
                          <Icon name="Truck" size={20} className="text-primary" />
                          <div>
                            <div className="font-medium text-foreground">Free Shipping</div>
                            <div className="text-sm text-muted-foreground">On orders over $50</div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-3">
                          <Icon name="RotateCcw" size={20} className="text-success" />
                          <div>
                            <div className="font-medium text-foreground">Easy Returns</div>
                            <div className="text-sm text-muted-foreground">30-day return policy</div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-3">
                          <Icon name="Shield" size={20} className="text-secondary" />
                          <div>
                            <div className="font-medium text-foreground">Buyer Protection</div>
                            <div className="text-sm text-muted-foreground">Full refund if not as described</div>
                          </div>
                        </div>
                      </div>
                      <div className="space-y-4">
                        <div>
                          <div className="font-medium text-foreground mb-2">Estimated Delivery</div>
                          <div className="text-sm text-muted-foreground">3-5 business days</div>
                        </div>
                        <div>
                          <div className="font-medium text-foreground mb-2">Shipping Methods</div>
                          <div className="text-sm text-muted-foreground space-y-1">
                            <div>• Standard Shipping (Free)</div>
                            <div>• Express Shipping ($15)</div>
                            <div>• Overnight Shipping ($35)</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Right Column - Booking/Auction Widget and Seller Info */}
            <div className="space-y-6">
              {/* Booking/Auction Widget */}
              <div className="hidden lg:block">
                {mockProduct?.type === 'auction' ? (
                  <AuctionWidget 
                    auction={mockAuction} 
                    onPlaceBid={handlePlaceBid} 
                  />
                ) : (
                  <BookingWidget 
                    product={mockProduct}
                    selectedDates={selectedDates}
                    onBookingSubmit={handleBookingSubmit}
                  />
                )}
              </div>

              {/* Rental Calendar */}
              {mockProduct?.type === 'rental' && (
                <div className="hidden lg:block">
                  <RentalCalendar
                    availability={mockAvailability}
                    onDateSelect={handleDateSelect}
                    selectedDates={selectedDates}
                    pricing={mockPricing}
                  />
                </div>
              )}

              {/* Seller Profile */}
              <SellerProfile seller={mockProduct?.seller} />
            </div>
          </div>
        </div>

        {/* Related Items */}
        <RelatedItems items={mockRelatedItems} title="Similar Items You Might Like" />
      </main>
    </div>
  );
};

export default ProductDetailBooking;