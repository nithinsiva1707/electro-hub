import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import Header from '../../components/ui/Header';
import SearchBar from './components/SearchBar';
import FilterChips from './components/FilterChips';
import FilterPanel from './components/FilterPanel';
import SortDropdown from './components/SortDropdown';
import ViewToggle from './components/ViewToggle';
import ProductGrid from './components/ProductGrid';
import MapView from './components/MapView';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const ProductSearchBrowse = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [searchQuery, setSearchQuery] = useState(searchParams?.get('q') || '');
  const [currentView, setCurrentView] = useState('grid');
  const [currentSort, setCurrentSort] = useState('relevance');
  const [isFilterPanelOpen, setIsFilterPanelOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 1024);
  const [loading, setLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [selectedMapProduct, setSelectedMapProduct] = useState(null);

  // Filter state
  const [filters, setFilters] = useState({
    categories: [],
    priceRange: { min: '', max: '' },
    conditions: [],
    distance: 25,
    availability: [],
    listingTypes: []
  });

  // Active filters for chips
  const [activeFilters, setActiveFilters] = useState({});

  // Mock products data
  const [products, setProducts] = useState([
    {
      id: 1,
      title: "iPhone 14 Pro Max 256GB Space Black",
      image: "https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=400",
      price: 899,
      originalPrice: 1099,
      listingType: "sale",
      condition: "like-new",
      rating: 4.8,
      reviewCount: 124,
      location: "Manhattan, NY",
      distance: 2.3,
      availability: "available",
      isNew: false,
      isFeatured: true,
      discount: 18,
      owner: {
        name: "Sarah Johnson",
        avatar: "https://randomuser.me/api/portraits/women/32.jpg",
        isVerified: true
      },
      coordinates: { lat: 40.7589, lng: -73.9851 },
      isFavorited: false
    },
    {
      id: 2,
      title: "MacBook Pro 16-inch M2 Pro",
      image: "https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=400",
      price: 45,
      rentPeriod: "day",
      listingType: "rent",
      condition: "good",
      rating: 4.9,
      reviewCount: 89,
      location: "Brooklyn, NY",
      distance: 5.7,
      availability: "available",
      isNew: false,
      isFeatured: false,
      owner: {
        name: "Mike Chen",
        avatar: "https://randomuser.me/api/portraits/men/45.jpg",
        isVerified: true
      },
      coordinates: { lat: 40.6782, lng: -73.9442 },
      isFavorited: true
    },
    {
      id: 3,
      title: "Sony PlayStation 5 Console",
      image: "https://images.unsplash.com/photo-1606813907291-d86efa9b94db?w=400",
      currentBid: 425,
      listingType: "auction",
      condition: "new",
      rating: 4.7,
      reviewCount: 156,
      location: "Queens, NY",
      distance: 8.2,
      availability: "available",
      timeLeft: "2d 14h",
      isNew: true,
      isFeatured: false,
      owner: {
        name: "Alex Rodriguez",
        avatar: "https://randomuser.me/api/portraits/men/28.jpg",
        isVerified: false
      },
      coordinates: { lat: 40.7282, lng: -73.7949 },
      isFavorited: false
    },
    {
      id: 4,
      title: "Dyson V15 Detect Cordless Vacuum",
      image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400",
      price: 25,
      rentPeriod: "week",
      listingType: "rent",
      condition: "like-new",
      rating: 4.6,
      reviewCount: 67,
      location: "Bronx, NY",
      distance: 12.1,
      availability: "rented",
      isNew: false,
      isFeatured: false,
      owner: {
        name: "Emma Wilson",
        avatar: "https://randomuser.me/api/portraits/women/41.jpg",
        isVerified: true
      },
      coordinates: { lat: 40.8448, lng: -73.8648 },
      isFavorited: false
    },
    {
      id: 5,
      title: "Samsung 55\" QLED 4K Smart TV",
      image: "https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=400",
      price: 650,
      originalPrice: 799,
      listingType: "sale",
      condition: "good",
      rating: 4.5,
      reviewCount: 203,
      location: "Staten Island, NY",
      distance: 15.8,
      availability: "available",
      isNew: false,
      isFeatured: false,
      discount: 19,
      owner: {
        name: "David Kim",
        avatar: "https://randomuser.me/api/portraits/men/52.jpg",
        isVerified: true
      },
      coordinates: { lat: 40.5795, lng: -74.1502 },
      isFavorited: false
    },
    {
      id: 6,
      title: "Nintendo Switch OLED Console",
      image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400",
      price: 280,
      listingType: "sale",
      condition: "like-new",
      rating: 4.8,
      reviewCount: 91,
      location: "Manhattan, NY",
      distance: 3.4,
      availability: "available",
      isNew: false,
      isFeatured: true,
      owner: {
        name: "Lisa Park",
        avatar: "https://randomuser.me/api/portraits/women/29.jpg",
        isVerified: true
      },
      coordinates: { lat: 40.7505, lng: -73.9934 },
      isFavorited: false
    }
  ]);

  // Handle window resize
  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 1024);
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Handle search from URL params
  useEffect(() => {
    const query = searchParams?.get('q');
    if (query) {
      setSearchQuery(query);
      handleSearch(query);
    }
  }, [searchParams]);

  const handleSearch = useCallback((query) => {
    setLoading(true);
    
    // Update URL
    if (query?.trim()) {
      setSearchParams({ q: query });
    } else {
      setSearchParams({});
    }

    // Simulate API call
    setTimeout(() => {
      // Filter products based on search query
      const filteredProducts = products?.filter(product =>
        product?.title?.toLowerCase()?.includes(query?.toLowerCase()) ||
        product?.location?.toLowerCase()?.includes(query?.toLowerCase())
      );
      
      setProducts(query?.trim() ? filteredProducts : products);
      setLoading(false);
    }, 500);
  }, [products, setSearchParams]);

  const handleFiltersChange = (newFilters) => {
    setFilters(newFilters);
    
    // Update active filters for chips
    const active = {};
    if (newFilters?.categories?.length > 0) {
      active.category = `${newFilters?.categories?.length} categories`;
    }
    if (newFilters?.priceRange?.min || newFilters?.priceRange?.max) {
      const min = newFilters?.priceRange?.min || '0';
      const max = newFilters?.priceRange?.max || '∞';
      active.priceRange = `$${min} - $${max}`;
    }
    if (newFilters?.conditions?.length > 0) {
      active.condition = newFilters?.conditions?.join(', ');
    }
    if (newFilters?.distance !== 25) {
      active.distance = `${newFilters?.distance} miles`;
    }
    if (newFilters?.availability?.length > 0) {
      active.availability = newFilters?.availability?.join(', ');
    }
    if (newFilters?.listingTypes?.length > 0) {
      active.listingType = newFilters?.listingTypes?.join(', ');
    }
    
    setActiveFilters(active);
    
    // Apply filters to products
    setLoading(true);
    setTimeout(() => {
      // Simulate filtering logic
      setLoading(false);
    }, 300);
  };

  const handleRemoveFilter = (filterKey) => {
    const newFilters = { ...filters };
    const newActiveFilters = { ...activeFilters };
    
    switch (filterKey) {
      case 'category':
        newFilters.categories = [];
        break;
      case 'priceRange':
        newFilters.priceRange = { min: '', max: '' };
        break;
      case 'condition':
        newFilters.conditions = [];
        break;
      case 'distance':
        newFilters.distance = 25;
        break;
      case 'availability':
        newFilters.availability = [];
        break;
      case 'listingType':
        newFilters.listingTypes = [];
        break;
    }
    
    delete newActiveFilters?.[filterKey];
    
    setFilters(newFilters);
    setActiveFilters(newActiveFilters);
  };

  const handleClearAllFilters = () => {
    const emptyFilters = {
      categories: [],
      priceRange: { min: '', max: '' },
      conditions: [],
      distance: 25,
      availability: [],
      listingTypes: []
    };
    setFilters(emptyFilters);
    setActiveFilters({});
  };

  const handleLoadMore = async () => {
    // Simulate loading more products
    return new Promise(resolve => {
      setTimeout(() => {
        // In real app, this would fetch more products
        setHasMore(false); // For demo, disable after first load
        resolve();
      }, 1000);
    });
  };

  const handleFavorite = (productId, isFavorited) => {
    setProducts(prev => prev?.map(product =>
      product?.id === productId
        ? { ...product, isFavorited }
        : product
    ));
  };

  const handleQuickInquiry = (product) => {
    console.log('Quick inquiry for:', product?.title);
    // In real app, this would open a modal or navigate to inquiry page
  };

  const handleCompare = (product) => {
    console.log('Add to compare:', product?.title);
    // In real app, this would add to comparison list
  };

  const handleBarcodeClick = () => {
    console.log('Open barcode scanner');
    // In real app, this would open camera for barcode scanning
  };

  const handleImageSearch = () => {
    console.log('Open image search');
    // In real app, this would open camera for image-based search
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="pt-16">
        {/* Search Section */}
        <div className="bg-card border-b border-border">
          <div className="container mx-auto px-4 py-6">
            <SearchBar
              searchQuery={searchQuery}
              setSearchQuery={setSearchQuery}
              onSearch={handleSearch}
              onBarcodeClick={handleBarcodeClick}
              onImageSearch={handleImageSearch}
            />
          </div>
        </div>

        {/* Filter Chips */}
        <FilterChips
          activeFilters={activeFilters}
          onRemoveFilter={handleRemoveFilter}
          onClearAll={handleClearAllFilters}
        />

        <div className="flex">
          {/* Filter Panel */}
          <FilterPanel
            isOpen={isFilterPanelOpen}
            onClose={() => setIsFilterPanelOpen(false)}
            filters={filters}
            onFiltersChange={handleFiltersChange}
            isMobile={isMobile}
          />

          {/* Main Content */}
          <div className="flex-1 min-w-0">
            {/* Controls Bar */}
            <div className="bg-card border-b border-border px-4 py-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setIsFilterPanelOpen(!isFilterPanelOpen)}
                    className="lg:hidden"
                  >
                    <Icon name="Filter" size={16} className="mr-2" />
                    Filters
                  </Button>
                  
                  <div className="hidden lg:flex items-center space-x-2 text-sm text-muted-foreground">
                    <Icon name="Package" size={16} />
                    <span>{products?.length} products found</span>
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  <SortDropdown
                    currentSort={currentSort}
                    onSortChange={setCurrentSort}
                  />
                  
                  <ViewToggle
                    currentView={currentView}
                    onViewChange={setCurrentView}
                  />
                </div>
              </div>
            </div>

            {/* Content Area */}
            <div className="p-4">
              {currentView === 'map' ? (
                <MapView
                  products={products}
                  onProductSelect={setSelectedMapProduct}
                  selectedProduct={selectedMapProduct}
                />
              ) : (
                <ProductGrid
                  products={products}
                  loading={loading}
                  hasMore={hasMore}
                  onLoadMore={handleLoadMore}
                  onFavorite={handleFavorite}
                  onQuickInquiry={handleQuickInquiry}
                  onCompare={handleCompare}
                  viewType={currentView}
                />
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductSearchBrowse;