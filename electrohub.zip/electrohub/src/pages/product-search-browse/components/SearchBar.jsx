import React, { useState, useRef, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Input from '../../../components/ui/Input';
import Button from '../../../components/ui/Button';

const SearchBar = ({ searchQuery, setSearchQuery, onSearch, onBarcodeClick, onImageSearch }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [recentSearches] = useState([
    'iPhone 14 Pro',
    'MacBook Air M2',
    'Gaming Chair',
    'Coffee Machine',
    'Wireless Headphones'
  ]);
  const [trendingItems] = useState([
    'PlayStation 5',
    'iPad Pro',
    'Dyson Vacuum',
    'Smart TV 55"',
    'Robot Vacuum'
  ]);
  
  const searchRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (searchRef?.current && !searchRef?.current?.contains(event?.target)) {
        setIsExpanded(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSubmit = (e) => {
    e?.preventDefault();
    if (searchQuery?.trim()) {
      onSearch(searchQuery);
      setIsExpanded(false);
    }
  };

  const handleRecentSearchClick = (search) => {
    setSearchQuery(search);
    onSearch(search);
    setIsExpanded(false);
  };

  return (
    <div className="relative w-full max-w-2xl mx-auto" ref={searchRef}>
      <form onSubmit={handleSubmit} className="relative">
        <div className="relative">
          <Icon 
            name="Search" 
            size={20} 
            className="absolute left-4 top-1/2 transform -translate-y-1/2 text-muted-foreground" 
          />
          <Input
            type="search"
            placeholder="Search electronics, appliances, or scan barcode..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e?.target?.value)}
            onFocus={() => setIsExpanded(true)}
            className="pl-12 pr-24 py-3 text-base rounded-xl border-2 focus:border-primary"
          />
          <div className="absolute right-2 top-1/2 transform -translate-y-1/2 flex items-center space-x-1">
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={onBarcodeClick}
              className="p-2"
            >
              <Icon name="ScanLine" size={18} />
            </Button>
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={onImageSearch}
              className="p-2"
            >
              <Icon name="Camera" size={18} />
            </Button>
          </div>
        </div>
      </form>
      {/* Expanded Search Suggestions */}
      {isExpanded && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-card border border-border rounded-xl shadow-elevated z-50 max-h-96 overflow-y-auto">
          <div className="p-4">
            {/* Recent Searches */}
            {recentSearches?.length > 0 && (
              <div className="mb-6">
                <h4 className="text-sm font-medium text-foreground mb-3 flex items-center">
                  <Icon name="Clock" size={16} className="mr-2" />
                  Recent Searches
                </h4>
                <div className="space-y-2">
                  {recentSearches?.map((search, index) => (
                    <button
                      key={index}
                      onClick={() => handleRecentSearchClick(search)}
                      className="flex items-center space-x-3 w-full px-3 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-muted rounded-lg transition-smooth"
                    >
                      <Icon name="Search" size={14} />
                      <span>{search}</span>
                      <Icon name="ArrowUpLeft" size={12} className="ml-auto" />
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Trending Items */}
            <div>
              <h4 className="text-sm font-medium text-foreground mb-3 flex items-center">
                <Icon name="TrendingUp" size={16} className="mr-2" />
                Trending Now
              </h4>
              <div className="space-y-2">
                {trendingItems?.map((item, index) => (
                  <button
                    key={index}
                    onClick={() => handleRecentSearchClick(item)}
                    className="flex items-center space-x-3 w-full px-3 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-muted rounded-lg transition-smooth"
                  >
                    <Icon name="Flame" size={14} className="text-orange-500" />
                    <span>{item}</span>
                    <Icon name="ArrowUpLeft" size={12} className="ml-auto" />
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SearchBar;