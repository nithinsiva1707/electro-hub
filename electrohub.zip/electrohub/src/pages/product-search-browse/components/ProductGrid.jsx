import React, { useState, useEffect, useCallback } from 'react';
import ProductCard from './ProductCard';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ProductGrid = ({ 
  products, 
  loading, 
  hasMore, 
  onLoadMore, 
  onFavorite, 
  onQuickInquiry, 
  onCompare,
  viewType = 'grid' 
}) => {
  const [loadingMore, setLoadingMore] = useState(false);

  const handleLoadMore = useCallback(async () => {
    if (loadingMore || !hasMore) return;
    
    setLoadingMore(true);
    await onLoadMore();
    setLoadingMore(false);
  }, [loadingMore, hasMore, onLoadMore]);

  // Infinite scroll
  useEffect(() => {
    const handleScroll = () => {
      if (
        window.innerHeight + document.documentElement?.scrollTop
        >= document.documentElement?.offsetHeight - 1000
      ) {
        handleLoadMore();
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [handleLoadMore]);

  // Loading skeleton
  const LoadingSkeleton = () => (
    <div className="bg-card border border-border rounded-xl overflow-hidden animate-pulse">
      <div className="aspect-square bg-muted" />
      <div className="p-4 space-y-3">
        <div className="h-4 bg-muted rounded w-3/4" />
        <div className="h-3 bg-muted rounded w-1/2" />
        <div className="h-4 bg-muted rounded w-1/3" />
        <div className="flex space-x-2">
          <div className="h-8 bg-muted rounded flex-1" />
          <div className="h-8 bg-muted rounded w-16" />
        </div>
      </div>
    </div>
  );

  if (loading && products?.length === 0) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6 gap-4">
        {Array.from({ length: 12 })?.map((_, index) => (
          <LoadingSkeleton key={index} />
        ))}
      </div>
    );
  }

  if (!loading && products?.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center">
        <div className="w-24 h-24 bg-muted rounded-full flex items-center justify-center mb-6">
          <Icon name="Search" size={32} className="text-muted-foreground" />
        </div>
        <h3 className="text-xl font-semibold text-foreground mb-2">No products found</h3>
        <p className="text-muted-foreground mb-6 max-w-md">
          We couldn't find any products matching your search criteria. Try adjusting your filters or search terms.
        </p>
        <div className="flex flex-col sm:flex-row gap-3">
          <Button variant="outline" onClick={() => window.location?.reload()}>
            <Icon name="RotateCcw" size={16} className="mr-2" />
            Reset Filters
          </Button>
          <Button>
            <Icon name="Plus" size={16} className="mr-2" />
            List Your Item
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Results Count */}
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          Showing {products?.length} of {products?.length + (hasMore ? '+' : '')} results
        </p>
      </div>
      {/* Product Grid */}
      <div className={`grid gap-4 ${
        viewType === 'grid' ?'grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6'
          : viewType === 'list' ?'grid-cols-1' :'grid-cols-2 md:grid-cols-3 lg:grid-cols-4'
      }`}>
        {products?.map((product) => (
          <ProductCard
            key={product?.id}
            product={product}
            onFavorite={onFavorite}
            onQuickInquiry={onQuickInquiry}
            onCompare={onCompare}
          />
        ))}
      </div>
      {/* Loading More */}
      {loadingMore && (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6 gap-4">
          {Array.from({ length: 6 })?.map((_, index) => (
            <LoadingSkeleton key={`loading-${index}`} />
          ))}
        </div>
      )}
      {/* Load More Button */}
      {hasMore && !loadingMore && (
        <div className="flex justify-center pt-8">
          <Button
            variant="outline"
            onClick={handleLoadMore}
            className="px-8"
          >
            <Icon name="ChevronDown" size={16} className="mr-2" />
            Load More Products
          </Button>
        </div>
      )}
      {/* End of Results */}
      {!hasMore && products?.length > 0 && (
        <div className="text-center py-8">
          <p className="text-sm text-muted-foreground">
            You've reached the end of the results
          </p>
        </div>
      )}
    </div>
  );
};

export default ProductGrid;