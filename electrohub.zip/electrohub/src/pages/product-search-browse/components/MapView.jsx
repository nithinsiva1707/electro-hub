import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Image from '../../../components/AppImage';

const MapView = ({ products, onProductSelect, selectedProduct }) => {
  const [mapCenter] = useState({ lat: 40.7128, lng: -74.0060 }); // New York City
  const [userLocation, setUserLocation] = useState(null);

  useEffect(() => {
    // Get user's current location
    if (navigator.geolocation) {
      navigator.geolocation?.getCurrentPosition(
        (position) => {
          setUserLocation({
            lat: position?.coords?.latitude,
            lng: position?.coords?.longitude
          });
        },
        (error) => {
          console.log('Location access denied:', error);
        }
      );
    }
  }, []);

  const ProductMarker = ({ product, isSelected, onClick }) => (
    <div
      className={`absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer transition-all duration-200 ${
        isSelected ? 'z-20 scale-110' : 'z-10 hover:scale-105'
      }`}
      style={{
        left: `${((product?.coordinates?.lng + 74.0060) / 0.1) * 10}%`,
        top: `${((40.7128 - product?.coordinates?.lat) / 0.1) * 10}%`
      }}
      onClick={() => onClick(product)}
    >
      <div className={`relative ${isSelected ? 'animate-bounce' : ''}`}>
        <div className={`w-10 h-10 rounded-full border-2 overflow-hidden ${
          isSelected 
            ? 'border-primary shadow-lg' 
            : 'border-white shadow-md hover:border-primary'
        }`}>
          <Image
            src={product?.image}
            alt={product?.title}
            className="w-full h-full object-cover"
          />
        </div>
        <div className={`absolute -bottom-1 left-1/2 transform -translate-x-1/2 w-3 h-3 rotate-45 ${
          isSelected ? 'bg-primary' : 'bg-white'
        } border border-gray-300`} />
        
        {/* Price Badge */}
        <div className="absolute -top-2 -right-2 bg-primary text-white text-xs font-bold px-2 py-1 rounded-full shadow-md">
          ${product?.price}
        </div>
      </div>
    </div>
  );

  const ProductPopup = ({ product, onClose }) => (
    <div className="absolute bottom-4 left-4 right-4 bg-card border border-border rounded-xl shadow-elevated z-30 max-w-sm mx-auto">
      <div className="p-4">
        <div className="flex items-start space-x-3">
          <div className="w-16 h-16 rounded-lg overflow-hidden bg-muted flex-shrink-0">
            <Image
              src={product?.image}
              alt={product?.title}
              className="w-full h-full object-cover"
            />
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between">
              <h3 className="font-semibold text-foreground text-sm line-clamp-2">
                {product?.title}
              </h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={onClose}
                className="p-1 h-6 w-6 -mt-1"
              >
                <Icon name="X" size={14} />
              </Button>
            </div>
            
            <div className="flex items-center space-x-2 mt-1">
              <div className="flex items-center space-x-1">
                <Icon name="Star" size={12} className="text-yellow-500" fill="currentColor" />
                <span className="text-xs font-medium text-foreground">{product?.rating}</span>
              </div>
              <span className="text-xs text-muted-foreground">•</span>
              <span className="text-xs text-muted-foreground">{product?.distance} miles</span>
            </div>
            
            <div className="flex items-center justify-between mt-2">
              <div className="flex items-baseline space-x-1">
                <span className="text-lg font-bold text-foreground">${product?.price}</span>
                {product?.listingType === 'rent' && (
                  <span className="text-xs text-muted-foreground">/{product?.rentPeriod}</span>
                )}
              </div>
              
              <div className="flex space-x-2">
                <Button size="sm" className="text-xs px-3">
                  View Details
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="relative w-full h-[600px] bg-muted rounded-xl overflow-hidden">
      {/* Map Container */}
      <div className="absolute inset-0">
        <iframe
          width="100%"
          height="100%"
          loading="lazy"
          title="Product Locations Map"
          referrerPolicy="no-referrer-when-downgrade"
          src={`https://www.google.com/maps?q=${mapCenter?.lat},${mapCenter?.lng}&z=12&output=embed`}
          className="border-0"
        />
      </div>
      {/* Map Controls */}
      <div className="absolute top-4 right-4 flex flex-col space-y-2 z-20">
        <Button
          variant="outline"
          size="sm"
          className="bg-card/90 backdrop-blur-sm"
          onClick={() => {
            if (userLocation) {
              // Center map on user location
              console.log('Center on user location:', userLocation);
            }
          }}
        >
          <Icon name="Crosshair" size={16} />
        </Button>
        
        <Button
          variant="outline"
          size="sm"
          className="bg-card/90 backdrop-blur-sm"
          onClick={() => {
            // Zoom in
            console.log('Zoom in');
          }}
        >
          <Icon name="Plus" size={16} />
        </Button>
        
        <Button
          variant="outline"
          size="sm"
          className="bg-card/90 backdrop-blur-sm"
          onClick={() => {
            // Zoom out
            console.log('Zoom out');
          }}
        >
          <Icon name="Minus" size={16} />
        </Button>
      </div>
      {/* Map Legend */}
      <div className="absolute top-4 left-4 bg-card/90 backdrop-blur-sm border border-border rounded-lg p-3 z-20">
        <h4 className="text-sm font-medium text-foreground mb-2">Legend</h4>
        <div className="space-y-2 text-xs">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            <span className="text-muted-foreground">Available</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-red-500 rounded-full"></div>
            <span className="text-muted-foreground">Rented</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
            <span className="text-muted-foreground">Your Location</span>
          </div>
        </div>
      </div>
      {/* Product Markers */}
      {products?.map((product) => (
        <ProductMarker
          key={product?.id}
          product={product}
          isSelected={selectedProduct?.id === product?.id}
          onClick={onProductSelect}
        />
      ))}
      {/* User Location Marker */}
      {userLocation && (
        <div
          className="absolute transform -translate-x-1/2 -translate-y-1/2 z-15"
          style={{
            left: `${((userLocation?.lng + 74.0060) / 0.1) * 10}%`,
            top: `${((40.7128 - userLocation?.lat) / 0.1) * 10}%`
          }}
        >
          <div className="w-4 h-4 bg-blue-500 rounded-full border-2 border-white shadow-lg animate-pulse"></div>
        </div>
      )}
      {/* Selected Product Popup */}
      {selectedProduct && (
        <ProductPopup
          product={selectedProduct}
          onClose={() => onProductSelect(null)}
        />
      )}
      {/* Results Counter */}
      <div className="absolute bottom-4 right-4 bg-card/90 backdrop-blur-sm border border-border rounded-lg px-3 py-2 z-20">
        <span className="text-sm font-medium text-foreground">
          {products?.length} products shown
        </span>
      </div>
    </div>
  );
};

export default MapView;