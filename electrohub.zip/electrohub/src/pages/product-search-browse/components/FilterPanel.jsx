import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import { Checkbox } from '../../../components/ui/Checkbox';

const FilterPanel = ({ isOpen, onClose, filters, onFiltersChange, isMobile }) => {
  const [localFilters, setLocalFilters] = useState(filters);

  const categories = [
    { id: 'personal-gadgets', label: 'Personal Gadgets', count: 1247 },
    { id: 'home-kitchen', label: 'Home & Kitchen', count: 892 },
    { id: 'office-electronics', label: 'Office Electronics', count: 634 },
    { id: 'entertainment', label: 'Entertainment', count: 456 },
    { id: 'gaming', label: 'Gaming', count: 321 },
    { id: 'fitness', label: 'Fitness & Health', count: 189 }
  ];

  const conditions = [
    { id: 'new', label: 'Brand New', count: 567 },
    { id: 'like-new', label: 'Like New', count: 892 },
    { id: 'good', label: 'Good', count: 1234 },
    { id: 'fair', label: 'Fair', count: 456 },
    { id: 'poor', label: 'Poor', count: 123 }
  ];

  const listingTypes = [
    { id: 'rent', label: 'For Rent', count: 1456 },
    { id: 'sale', label: 'For Sale', count: 2134 },
    { id: 'auction', label: 'Auction', count: 234 }
  ];

  const availabilityOptions = [
    { id: 'available-now', label: 'Available Now', count: 1892 },
    { id: 'available-soon', label: 'Available Soon', count: 456 },
    { id: 'pre-order', label: 'Pre-order', count: 78 }
  ];

  const handleFilterChange = (section, value, checked) => {
    setLocalFilters(prev => ({
      ...prev,
      [section]: checked 
        ? [...(prev?.[section] || []), value]
        : (prev?.[section] || [])?.filter(item => item !== value)
    }));
  };

  const handlePriceChange = (field, value) => {
    setLocalFilters(prev => ({
      ...prev,
      priceRange: {
        ...prev?.priceRange,
        [field]: value
      }
    }));
  };

  const handleDistanceChange = (value) => {
    setLocalFilters(prev => ({
      ...prev,
      distance: value
    }));
  };

  const applyFilters = () => {
    onFiltersChange(localFilters);
    if (isMobile) onClose();
  };

  const resetFilters = () => {
    const emptyFilters = {
      categories: [],
      priceRange: { min: '', max: '' },
      conditions: [],
      distance: 25,
      availability: [],
      listingTypes: []
    };
    setLocalFilters(emptyFilters);
    onFiltersChange(emptyFilters);
  };

  const FilterSection = ({ title, children, defaultOpen = true }) => {
    const [isExpanded, setIsExpanded] = useState(defaultOpen);
    
    return (
      <div className="border-b border-border last:border-b-0">
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="flex items-center justify-between w-full p-4 text-left hover:bg-muted/50 transition-smooth"
        >
          <h3 className="font-medium text-foreground">{title}</h3>
          <Icon 
            name={isExpanded ? "ChevronUp" : "ChevronDown"} 
            size={16} 
            className="text-muted-foreground" 
          />
        </button>
        {isExpanded && (
          <div className="px-4 pb-4">
            {children}
          </div>
        )}
      </div>
    );
  };

  const content = (
    <div className="h-full flex flex-col bg-card">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <h2 className="text-lg font-semibold text-foreground">Filters</h2>
        {isMobile && (
          <Button variant="ghost" size="sm" onClick={onClose}>
            <Icon name="X" size={20} />
          </Button>
        )}
      </div>

      {/* Filter Content */}
      <div className="flex-1 overflow-y-auto">
        {/* Categories */}
        <FilterSection title="Categories">
          <div className="space-y-3">
            {categories?.map((category) => (
              <div key={category?.id} className="flex items-center justify-between">
                <Checkbox
                  label={category?.label}
                  checked={localFilters?.categories?.includes(category?.id) || false}
                  onChange={(e) => handleFilterChange('categories', category?.id, e?.target?.checked)}
                />
                <span className="text-sm text-muted-foreground">({category?.count})</span>
              </div>
            ))}
          </div>
        </FilterSection>

        {/* Price Range */}
        <FilterSection title="Price Range">
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <Input
                type="number"
                placeholder="Min"
                value={localFilters?.priceRange?.min || ''}
                onChange={(e) => handlePriceChange('min', e?.target?.value)}
                className="text-sm"
              />
              <Input
                type="number"
                placeholder="Max"
                value={localFilters?.priceRange?.max || ''}
                onChange={(e) => handlePriceChange('max', e?.target?.value)}
                className="text-sm"
              />
            </div>
            <div className="flex flex-wrap gap-2">
              {['$0-50', '$50-200', '$200-500', '$500+']?.map((range) => (
                <Button
                  key={range}
                  variant="outline"
                  size="sm"
                  className="text-xs"
                  onClick={() => {
                    const [min, max] = range?.replace('$', '')?.split('-');
                    handlePriceChange('min', min);
                    handlePriceChange('max', max === '+' ? '' : max);
                  }}
                >
                  {range}
                </Button>
              ))}
            </div>
          </div>
        </FilterSection>

        {/* Condition */}
        <FilterSection title="Condition">
          <div className="space-y-3">
            {conditions?.map((condition) => (
              <div key={condition?.id} className="flex items-center justify-between">
                <Checkbox
                  label={condition?.label}
                  checked={localFilters?.conditions?.includes(condition?.id) || false}
                  onChange={(e) => handleFilterChange('conditions', condition?.id, e?.target?.checked)}
                />
                <span className="text-sm text-muted-foreground">({condition?.count})</span>
              </div>
            ))}
          </div>
        </FilterSection>

        {/* Distance */}
        <FilterSection title="Distance">
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <span className="text-sm text-muted-foreground">Within</span>
              <Input
                type="number"
                value={localFilters?.distance || 25}
                onChange={(e) => handleDistanceChange(parseInt(e?.target?.value) || 25)}
                className="w-20 text-center"
                min="1"
                max="100"
              />
              <span className="text-sm text-muted-foreground">miles</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {[5, 10, 25, 50, 100]?.map((distance) => (
                <Button
                  key={distance}
                  variant={localFilters?.distance === distance ? "default" : "outline"}
                  size="sm"
                  onClick={() => handleDistanceChange(distance)}
                  className="text-xs"
                >
                  {distance} mi
                </Button>
              ))}
            </div>
          </div>
        </FilterSection>

        {/* Availability */}
        <FilterSection title="Availability">
          <div className="space-y-3">
            {availabilityOptions?.map((option) => (
              <div key={option?.id} className="flex items-center justify-between">
                <Checkbox
                  label={option?.label}
                  checked={localFilters?.availability?.includes(option?.id) || false}
                  onChange={(e) => handleFilterChange('availability', option?.id, e?.target?.checked)}
                />
                <span className="text-sm text-muted-foreground">({option?.count})</span>
              </div>
            ))}
          </div>
        </FilterSection>

        {/* Listing Type */}
        <FilterSection title="Listing Type">
          <div className="space-y-3">
            {listingTypes?.map((type) => (
              <div key={type?.id} className="flex items-center justify-between">
                <Checkbox
                  label={type?.label}
                  checked={localFilters?.listingTypes?.includes(type?.id) || false}
                  onChange={(e) => handleFilterChange('listingTypes', type?.id, e?.target?.checked)}
                />
                <span className="text-sm text-muted-foreground">({type?.count})</span>
              </div>
            ))}
          </div>
        </FilterSection>
      </div>

      {/* Footer Actions */}
      <div className="p-4 border-t border-border bg-card">
        <div className="flex space-x-3">
          <Button
            variant="outline"
            onClick={resetFilters}
            className="flex-1"
          >
            Reset
          </Button>
          <Button
            onClick={applyFilters}
            className="flex-1"
          >
            Apply Filters
          </Button>
        </div>
      </div>
    </div>
  );

  if (isMobile) {
    return (
      <>
        {/* Mobile Overlay */}
        {isOpen && (
          <div className="fixed inset-0 bg-black/50 z-50" onClick={onClose} />
        )}
        
        {/* Mobile Panel */}
        <div className={`fixed inset-y-0 right-0 w-full max-w-sm bg-card z-50 transform transition-transform duration-300 ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}>
          {content}
        </div>
      </>
    );
  }

  // Desktop Sidebar
  return (
    <div className={`w-80 border-r border-border bg-card transition-all duration-300 ${
      isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
    }`}>
      {content}
    </div>
  );
};

export default FilterPanel;