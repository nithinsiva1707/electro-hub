import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const ProductCard = ({ product, onFavorite, onQuickInquiry, onCompare }) => {
  const [isFavorited, setIsFavorited] = useState(product?.isFavorited || false);
  const [imageLoaded, setImageLoaded] = useState(false);

  const handleFavoriteClick = (e) => {
    e?.preventDefault();
    e?.stopPropagation();
    setIsFavorited(!isFavorited);
    onFavorite(product?.id, !isFavorited);
  };

  const handleQuickInquiry = (e) => {
    e?.preventDefault();
    e?.stopPropagation();
    onQuickInquiry(product);
  };

  const handleCompare = (e) => {
    e?.preventDefault();
    e?.stopPropagation();
    onCompare(product);
  };

  const getConditionColor = (condition) => {
    const colors = {
      'new': 'text-green-600 bg-green-50',
      'like-new': 'text-blue-600 bg-blue-50',
      'good': 'text-yellow-600 bg-yellow-50',
      'fair': 'text-orange-600 bg-orange-50',
      'poor': 'text-red-600 bg-red-50'
    };
    return colors?.[condition] || 'text-gray-600 bg-gray-50';
  };

  const getAvailabilityColor = (status) => {
    const colors = {
      'available': 'text-green-600',
      'rented': 'text-red-600',
      'maintenance': 'text-yellow-600',
      'reserved': 'text-blue-600'
    };
    return colors?.[status] || 'text-gray-600';
  };

  return (
    <div className="group bg-card border border-border rounded-xl overflow-hidden hover:shadow-elevated transition-all duration-300 hover:-translate-y-1">
      <Link to={`/product-detail-booking?id=${product?.id}`} className="block">
        {/* Image Container */}
        <div className="relative aspect-square overflow-hidden bg-muted">
          {!imageLoaded && (
            <div className="absolute inset-0 bg-muted animate-pulse flex items-center justify-center">
              <Icon name="Image" size={32} className="text-muted-foreground" />
            </div>
          )}
          
          <Image
            src={product?.image}
            alt={product?.title}
            className={`w-full h-full object-cover transition-all duration-300 group-hover:scale-105 ${
              imageLoaded ? 'opacity-100' : 'opacity-0'
            }`}
            onLoad={() => setImageLoaded(true)}
          />

          {/* Overlay Actions */}
          <div className="absolute top-3 right-3 flex flex-col space-y-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleFavoriteClick}
              className={`w-8 h-8 rounded-full bg-white/90 backdrop-blur-sm hover:bg-white ${
                isFavorited ? 'text-red-500' : 'text-gray-600'
              }`}
            >
              <Icon name={isFavorited ? "Heart" : "Heart"} size={16} fill={isFavorited ? "currentColor" : "none"} />
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={handleCompare}
              className="w-8 h-8 rounded-full bg-white/90 backdrop-blur-sm hover:bg-white text-gray-600"
            >
              <Icon name="GitCompare" size={16} />
            </Button>
          </div>

          {/* Badges */}
          <div className="absolute top-3 left-3 flex flex-col space-y-1">
            {product?.isNew && (
              <span className="px-2 py-1 bg-green-500 text-white text-xs font-medium rounded-full">
                New
              </span>
            )}
            {product?.isFeatured && (
              <span className="px-2 py-1 bg-primary text-white text-xs font-medium rounded-full">
                Featured
              </span>
            )}
            {product?.discount && (
              <span className="px-2 py-1 bg-red-500 text-white text-xs font-medium rounded-full">
                -{product?.discount}%
              </span>
            )}
          </div>

          {/* Availability Status */}
          <div className="absolute bottom-3 left-3">
            <div className={`flex items-center space-x-1 px-2 py-1 bg-white/90 backdrop-blur-sm rounded-full text-xs font-medium ${getAvailabilityColor(product?.availability)}`}>
              <div className={`w-2 h-2 rounded-full ${
                product?.availability === 'available' ? 'bg-green-500' :
                product?.availability === 'rented' ? 'bg-red-500' :
                product?.availability === 'maintenance'? 'bg-yellow-500' : 'bg-blue-500'
              }`} />
              <span className="capitalize">{product?.availability}</span>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-4">
          {/* Title and Rating */}
          <div className="mb-2">
            <h3 className="font-semibold text-foreground text-sm line-clamp-2 mb-1 group-hover:text-primary transition-colors">
              {product?.title}
            </h3>
            <div className="flex items-center space-x-2">
              <div className="flex items-center space-x-1">
                <Icon name="Star" size={14} className="text-yellow-500" fill="currentColor" />
                <span className="text-sm font-medium text-foreground">{product?.rating}</span>
                <span className="text-xs text-muted-foreground">({product?.reviewCount})</span>
              </div>
              <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getConditionColor(product?.condition)}`}>
                {product?.condition}
              </span>
            </div>
          </div>

          {/* Price */}
          <div className="mb-3">
            {product?.listingType === 'rent' ? (
              <div className="flex items-baseline space-x-1">
                <span className="text-lg font-bold text-foreground">${product?.price}</span>
                <span className="text-sm text-muted-foreground">/{product?.rentPeriod}</span>
                {product?.originalPrice && (
                  <span className="text-sm text-muted-foreground line-through">${product?.originalPrice}</span>
                )}
              </div>
            ) : product?.listingType === 'auction' ? (
              <div className="space-y-1">
                <div className="flex items-baseline space-x-1">
                  <span className="text-sm text-muted-foreground">Current bid:</span>
                  <span className="text-lg font-bold text-foreground">${product?.currentBid}</span>
                </div>
                <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                  <Icon name="Clock" size={12} />
                  <span>{product?.timeLeft}</span>
                </div>
              </div>
            ) : (
              <div className="flex items-baseline space-x-2">
                <span className="text-lg font-bold text-foreground">${product?.price}</span>
                {product?.originalPrice && (
                  <span className="text-sm text-muted-foreground line-through">${product?.originalPrice}</span>
                )}
              </div>
            )}
          </div>

          {/* Location and Distance */}
          <div className="flex items-center justify-between text-sm text-muted-foreground mb-3">
            <div className="flex items-center space-x-1">
              <Icon name="MapPin" size={12} />
              <span>{product?.location}</span>
            </div>
            <span>{product?.distance} miles</span>
          </div>

          {/* Owner Info */}
          <div className="flex items-center space-x-2 mb-3">
            <div className="w-6 h-6 bg-muted rounded-full overflow-hidden">
              <Image
                src={product?.owner?.avatar}
                alt={product?.owner?.name}
                className="w-full h-full object-cover"
              />
            </div>
            <span className="text-sm text-muted-foreground">{product?.owner?.name}</span>
            {product?.owner?.isVerified && (
              <Icon name="BadgeCheck" size={14} className="text-blue-500" />
            )}
          </div>

          {/* Quick Actions */}
          <div className="flex space-x-2">
            <Button
              size="sm"
              className="flex-1 text-xs"
              onClick={handleQuickInquiry}
            >
              <Icon name="MessageCircle" size={14} className="mr-1" />
              Quick Inquiry
            </Button>
            
            {product?.listingType === 'rent' && (
              <Button
                variant="outline"
                size="sm"
                className="text-xs"
              >
                <Icon name="Calendar" size={14} className="mr-1" />
                Book
              </Button>
            )}
            
            {product?.listingType === 'auction' && (
              <Button
                variant="outline"
                size="sm"
                className="text-xs"
              >
                <Icon name="Gavel" size={14} className="mr-1" />
                Bid
              </Button>
            )}
          </div>
        </div>
      </Link>
    </div>
  );
};

export default ProductCard;