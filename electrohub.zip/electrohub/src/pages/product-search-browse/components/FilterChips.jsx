import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const FilterChips = ({ activeFilters, onRemoveFilter, onClearAll }) => {
  const filterChips = [
    { key: 'category', label: activeFilters?.category, icon: 'Tag' },
    { key: 'priceRange', label: activeFilters?.priceRange, icon: 'DollarSign' },
    { key: 'condition', label: activeFilters?.condition, icon: 'Shield' },
    { key: 'distance', label: activeFilters?.distance, icon: 'MapPin' },
    { key: 'availability', label: activeFilters?.availability, icon: 'Calendar' },
    { key: 'listingType', label: activeFilters?.listingType, icon: 'Package' }
  ]?.filter(chip => chip?.label);

  if (filterChips?.length === 0) return null;

  return (
    <div className="flex flex-wrap items-center gap-2 p-4 bg-muted/30 border-b border-border">
      <div className="flex items-center space-x-2 text-sm text-muted-foreground">
        <Icon name="Filter" size={16} />
        <span>Active filters:</span>
      </div>
      <div className="flex flex-wrap gap-2">
        {filterChips?.map((chip) => (
          <div
            key={chip?.key}
            className="flex items-center space-x-1 bg-primary/10 text-primary px-3 py-1 rounded-full text-sm border border-primary/20"
          >
            <Icon name={chip?.icon} size={14} />
            <span>{chip?.label}</span>
            <Button
              variant="ghost"
              size="xs"
              onClick={() => onRemoveFilter(chip?.key)}
              className="p-0 h-4 w-4 ml-1 hover:bg-primary/20 rounded-full"
            >
              <Icon name="X" size={12} />
            </Button>
          </div>
        ))}
      </div>
      {filterChips?.length > 1 && (
        <Button
          variant="ghost"
          size="sm"
          onClick={onClearAll}
          className="text-muted-foreground hover:text-foreground ml-2"
        >
          Clear all
        </Button>
      )}
    </div>
  );
};

export default FilterChips;