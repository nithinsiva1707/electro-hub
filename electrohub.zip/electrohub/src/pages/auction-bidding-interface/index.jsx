import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import Header from '../../components/ui/Header';
import AuctionTimer from './components/AuctionTimer';
import BiddingPanel from './components/BiddingPanel';
import BidHistory from './components/BidHistory';
import AuctionItemDetails from './components/AuctionItemDetails';
import WatchlistPanel from './components/WatchlistPanel';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const AuctionBiddingInterface = () => {
  const [searchParams] = useSearchParams();
  const auctionId = searchParams?.get('id') || '1';
  
  const [currentUserId] = useState('user123');
  const [isLoading, setIsLoading] = useState(false);
  const [showWatchlist, setShowWatchlist] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Mock auction data
  const [auctionData, setAuctionData] = useState({
    id: auctionId,
    title: "Apple MacBook Pro 16-inch M2 Max",
    brand: "Apple",
    model: "MacBook Pro 16-inch",
    year: "2023",
    condition: "Excellent",
    location: "New York, NY",
    startingBid: 1500,
    currentBid: 2350,
    minIncrement: 50,
    hasReserve: true,
    reservePrice: 2000,
    reserveMet: true,
    endTime: new Date(Date.now() + 2 * 60 * 60 * 1000), // 2 hours from now
    images: [
      "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=800&h=600&fit=crop"
    ],
    description: `This MacBook Pro 16-inch with M2 Max chip is in excellent condition, barely used for 6 months. Originally purchased for $3,499, this powerful machine features 32GB unified memory, 1TB SSD storage, and the stunning Liquid Retina XDR display.\n\nIncludes original box, charger, documentation, and unused stickers. No scratches, dents, or signs of wear. Battery health is at 98%. Perfect for professionals, content creators, and power users who need top-tier performance.\n\nThis auction includes a 30-day return policy and comes with proof of purchase for warranty coverage. Shipping is included within the continental US.`,
    specifications: {
      processor: "Apple M2 Max",
      memory: "32GB Unified Memory",
      storage: "1TB SSD",
      display: "16-inch Liquid Retina XDR",
      graphics: "38-core GPU",
      batteryHealth: "98%",
      warranty: "Active until Dec 2024"
    },
    seller: {
      name: "TechDeals Pro",
      verified: true,
      rating: 4.9,
      reviewCount: 847,
      memberSince: "2019"
    }
  });

  const [bidHistory, setBidHistory] = useState([
    {
      id: "bid1",
      bidderId: "user456",
      bidderNumber: 127,
      amount: 2350,
      timestamp: new Date(Date.now() - 300000), // 5 minutes ago
      isAutoBid: false
    },
    {
      id: "bid2",
      bidderId: currentUserId,
      amount: 2300,
      timestamp: new Date(Date.now() - 600000), // 10 minutes ago
      isAutoBid: true
    },
    {
      id: "bid3",
      bidderId: "user789",
      bidderNumber: 89,
      amount: 2250,
      timestamp: new Date(Date.now() - 900000), // 15 minutes ago
      isAutoBid: false
    },
    {
      id: "bid4",
      bidderId: "user101",
      bidderNumber: 234,
      amount: 2200,
      timestamp: new Date(Date.now() - 1200000), // 20 minutes ago
      isAutoBid: false
    },
    {
      id: "bid5",
      bidderId: "user456",
      bidderNumber: 127,
      amount: 2150,
      timestamp: new Date(Date.now() - 1500000), // 25 minutes ago
      isAutoBid: false
    }
  ]);

  const [userMaxBid, setUserMaxBid] = useState(2400);
  const [isInWatchlist, setIsInWatchlist] = useState(false);

  const [watchlistItems, setWatchlistItems] = useState([
    {
      id: "watch1",
      title: "iPhone 14 Pro Max 256GB",
      brand: "Apple",
      image: "https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=400&h=400&fit=crop",
      currentBid: 850,
      endTime: new Date(Date.now() + 45 * 60 * 1000) // 45 minutes
    },
    {
      id: "watch2",
      title: "Samsung 65\" QLED TV",
      brand: "Samsung",
      image: "https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=400&h=400&fit=crop",
      currentBid: 1200,
      endTime: new Date(Date.now() + 3 * 60 * 60 * 1000) // 3 hours
    },
    {
      id: "watch3",
      title: "Sony WH-1000XM4 Headphones",
      brand: "Sony",
      image: "https://images.unsplash.com/photo-1583394838336-acd977736f90?w=400&h=400&fit=crop",
      currentBid: 180,
      endTime: new Date(Date.now() + 24 * 60 * 60 * 1000) // 24 hours
    }
  ]);

  // Simulate real-time bid updates
  useEffect(() => {
    const interval = setInterval(() => {
      // Randomly add new bids (10% chance every 30 seconds)
      if (Math.random() < 0.1) {
        const newBid = {
          id: `bid_${Date.now()}`,
          bidderId: `user_${Math.floor(Math.random() * 1000)}`,
          bidderNumber: Math.floor(Math.random() * 999) + 1,
          amount: auctionData?.currentBid + auctionData?.minIncrement,
          timestamp: new Date(),
          isAutoBid: Math.random() < 0.3
        };

        setBidHistory(prev => [newBid, ...prev]);
        setAuctionData(prev => ({
          ...prev,
          currentBid: newBid?.amount
        }));

        // Show notification
        addNotification(`New bid: $${newBid?.amount}`, 'info');
        
        // Play sound if enabled
        if (soundEnabled) {
          // In a real app, you would play an actual sound
          console.log('🔔 New bid sound');
        }
      }
    }, 30000);

    return () => clearInterval(interval);
  }, [auctionData?.currentBid, auctionData?.minIncrement, soundEnabled]);

  const addNotification = (message, type = 'info') => {
    const notification = {
      id: Date.now(),
      message,
      type,
      timestamp: new Date()
    };
    
    setNotifications(prev => [notification, ...prev?.slice(0, 4)]);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
      setNotifications(prev => prev?.filter(n => n?.id !== notification?.id));
    }, 5000);
  };

  const handlePlaceBid = async (amount, isAutoBid = false) => {
    setIsLoading(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const newBid = {
        id: `bid_${Date.now()}`,
        bidderId: currentUserId,
        amount: amount,
        timestamp: new Date(),
        isAutoBid: isAutoBid
      };

      setBidHistory(prev => [newBid, ...prev]);
      setAuctionData(prev => ({
        ...prev,
        currentBid: amount
      }));

      if (isAutoBid) {
        setUserMaxBid(amount);
        addNotification(`Auto-bid set at $${amount}`, 'success');
      } else {
        addNotification(`Bid placed: $${amount}`, 'success');
      }
      
    } catch (error) {
      addNotification('Failed to place bid. Please try again.', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAuctionEnd = () => {
    const winningBid = bidHistory?.[0];
    if (winningBid && winningBid?.bidderId === currentUserId) {
      addNotification('Congratulations! You won the auction!', 'success');
    } else {
      addNotification('Auction ended. You did not win this time.', 'info');
    }
  };

  const handleAddToWatchlist = () => {
    setIsInWatchlist(!isInWatchlist);
    addNotification(
      isInWatchlist ? 'Removed from watchlist' : 'Added to watchlist',
      'info'
    );
  };

  const handleRemoveFromWatchlist = (itemId) => {
    setWatchlistItems(prev => prev?.filter(item => item?.id !== itemId));
    addNotification('Item removed from watchlist', 'info');
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-16">
        {/* Notifications */}
        {notifications?.length > 0 && (
          <div className="fixed top-20 right-4 z-notification space-y-2">
            {notifications?.map((notification) => (
              <div
                key={notification?.id}
                className={`p-4 rounded-lg shadow-elevated border max-w-sm animate-in slide-in-from-right ${
                  notification?.type === 'success' ?'bg-success/10 border-success text-success'
                    : notification?.type === 'error' ?'bg-error/10 border-error text-error' :'bg-primary/10 border-primary text-primary'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <Icon 
                    name={
                      notification?.type === 'success' ? 'CheckCircle' :
                      notification?.type === 'error' ? 'AlertCircle' : 'Info'
                    } 
                    size={16} 
                  />
                  <p className="text-sm font-medium">{notification?.message}</p>
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 xl:grid-cols-4 gap-8">
            {/* Main Content - Left Side */}
            <div className="xl:col-span-3 space-y-8">
              {/* Auction Timer */}
              <AuctionTimer 
                endTime={auctionData?.endTime}
                onTimeEnd={handleAuctionEnd}
              />

              {/* Item Details */}
              <AuctionItemDetails
                item={auctionData}
                onAddToWatchlist={handleAddToWatchlist}
                isInWatchlist={isInWatchlist}
              />

              {/* Mobile Bidding Panel */}
              <div className="xl:hidden">
                <BiddingPanel
                  currentBid={auctionData?.currentBid}
                  minIncrement={auctionData?.minIncrement}
                  onPlaceBid={handlePlaceBid}
                  isLoading={isLoading}
                  userMaxBid={userMaxBid}
                />
              </div>

              {/* Bid History */}
              <BidHistory
                bids={bidHistory}
                currentUserId={currentUserId}
              />
            </div>

            {/* Sidebar - Right Side */}
            <div className="xl:col-span-1 space-y-6">
              {/* Desktop Bidding Panel */}
              <div className="hidden xl:block">
                <BiddingPanel
                  currentBid={auctionData?.currentBid}
                  minIncrement={auctionData?.minIncrement}
                  onPlaceBid={handlePlaceBid}
                  isLoading={isLoading}
                  userMaxBid={userMaxBid}
                />
              </div>

              {/* Settings Panel */}
              <div className="bg-card border border-border rounded-lg p-4">
                <h3 className="font-semibold text-foreground mb-4">Auction Settings</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Icon name="Volume2" size={16} className="text-muted-foreground" />
                      <span className="text-sm text-foreground">Sound Notifications</span>
                    </div>
                    <Button
                      variant="ghost"
                      onClick={() => setSoundEnabled(!soundEnabled)}
                      className={`w-12 h-6 rounded-full p-0 ${
                        soundEnabled ? 'bg-primary' : 'bg-muted'
                      }`}
                    >
                      <div className={`w-5 h-5 bg-white rounded-full transition-transform ${
                        soundEnabled ? 'translate-x-6' : 'translate-x-1'
                      }`} />
                    </Button>
                  </div>
                  
                  <Button
                    variant="outline"
                    onClick={() => setShowWatchlist(!showWatchlist)}
                    className="w-full justify-start"
                  >
                    <Icon name="Heart" size={16} />
                    {showWatchlist ? 'Hide' : 'Show'} Watchlist
                  </Button>
                </div>
              </div>

              {/* Watchlist Panel */}
              {showWatchlist && (
                <WatchlistPanel
                  watchlistItems={watchlistItems}
                  onRemoveFromWatchlist={handleRemoveFromWatchlist}
                />
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default AuctionBiddingInterface;