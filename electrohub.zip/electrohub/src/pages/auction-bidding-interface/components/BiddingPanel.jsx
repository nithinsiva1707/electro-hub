import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const BiddingPanel = ({ currentBid, minIncrement, onPlaceBid, isLoading, userMaxBid }) => {
  const [bidAmount, setBidAmount] = useState('');
  const [maxBidAmount, setMaxBidAmount] = useState('');
  const [showAutoBid, setShowAutoBid] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [pendingBid, setPendingBid] = useState(null);

  const suggestedBids = [
    currentBid + minIncrement,
    currentBid + (minIncrement * 2),
    currentBid + (minIncrement * 5),
    currentBid + (minIncrement * 10)
  ];

  const handleQuickBid = (amount) => {
    setPendingBid(amount);
    setShowConfirmation(true);
  };

  const handleCustomBid = () => {
    const amount = parseFloat(bidAmount);
    if (amount >= currentBid + minIncrement) {
      setPendingBid(amount);
      setShowConfirmation(true);
    }
  };

  const confirmBid = () => {
    onPlaceBid(pendingBid);
    setShowConfirmation(false);
    setPendingBid(null);
    setBidAmount('');
  };

  const handleAutoBid = () => {
    const amount = parseFloat(maxBidAmount);
    if (amount >= currentBid + minIncrement) {
      onPlaceBid(amount, true); // true indicates auto-bid
      setMaxBidAmount('');
      setShowAutoBid(false);
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    })?.format(amount);
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-foreground">Place Your Bid</h3>
        <Button
          variant="ghost"
          onClick={() => setShowAutoBid(!showAutoBid)}
          className="text-sm"
        >
          <Icon name="Zap" size={16} />
          Auto Bid
        </Button>
      </div>
      {/* Current Bid Display */}
      <div className="bg-muted rounded-lg p-4 mb-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground">Current Highest Bid</p>
            <p className="text-2xl font-bold text-foreground">{formatCurrency(currentBid)}</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-muted-foreground">Minimum Increment</p>
            <p className="text-lg font-semibold text-foreground">{formatCurrency(minIncrement)}</p>
          </div>
        </div>
        {userMaxBid && (
          <div className="mt-3 pt-3 border-t border-border">
            <div className="flex items-center space-x-2">
              <Icon name="Shield" size={16} className="text-success" />
              <span className="text-sm text-success">Your max auto-bid: {formatCurrency(userMaxBid)}</span>
            </div>
          </div>
        )}
      </div>
      {/* Quick Bid Buttons */}
      <div className="mb-6">
        <p className="text-sm font-medium text-foreground mb-3">Quick Bid</p>
        <div className="grid grid-cols-2 gap-2">
          {suggestedBids?.map((amount, index) => (
            <Button
              key={index}
              variant="outline"
              onClick={() => handleQuickBid(amount)}
              disabled={isLoading}
              className="h-12"
            >
              {formatCurrency(amount)}
            </Button>
          ))}
        </div>
      </div>
      {/* Custom Bid Input */}
      <div className="mb-6">
        <Input
          label="Custom Bid Amount"
          type="number"
          placeholder={`Minimum: ${formatCurrency(currentBid + minIncrement)}`}
          value={bidAmount}
          onChange={(e) => setBidAmount(e?.target?.value)}
          min={currentBid + minIncrement}
          step={minIncrement}
        />
        <Button
          onClick={handleCustomBid}
          disabled={!bidAmount || parseFloat(bidAmount) < currentBid + minIncrement || isLoading}
          className="w-full mt-3"
        >
          <Icon name="Gavel" size={16} />
          Place Custom Bid
        </Button>
      </div>
      {/* Auto Bid Section */}
      {showAutoBid && (
        <div className="border-t border-border pt-6">
          <div className="bg-primary/5 border border-primary/20 rounded-lg p-4 mb-4">
            <div className="flex items-start space-x-3">
              <Icon name="Info" size={16} className="text-primary mt-0.5" />
              <div>
                <h4 className="text-sm font-medium text-foreground mb-1">Auto Bidding</h4>
                <p className="text-xs text-muted-foreground">
                  Set your maximum bid and we'll automatically bid for you up to that amount, 
                  using the minimum increment each time.
                </p>
              </div>
            </div>
          </div>
          
          <Input
            label="Maximum Auto-Bid Amount"
            type="number"
            placeholder={`Minimum: ${formatCurrency(currentBid + minIncrement)}`}
            value={maxBidAmount}
            onChange={(e) => setMaxBidAmount(e?.target?.value)}
            min={currentBid + minIncrement}
            step={minIncrement}
            description="We'll bid incrementally up to this amount"
          />
          <Button
            onClick={handleAutoBid}
            disabled={!maxBidAmount || parseFloat(maxBidAmount) < currentBid + minIncrement || isLoading}
            className="w-full mt-3"
            variant="secondary"
          >
            <Icon name="Zap" size={16} />
            Set Auto Bid
          </Button>
        </div>
      )}
      {/* Bid Confirmation Modal */}
      {showConfirmation && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-modal p-4">
          <div className="bg-card border border-border rounded-lg p-6 w-full max-w-md">
            <div className="text-center mb-6">
              <Icon name="AlertTriangle" size={48} className="text-warning mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-foreground mb-2">Confirm Your Bid</h3>
              <p className="text-muted-foreground">
                Are you sure you want to bid {formatCurrency(pendingBid)}?
              </p>
            </div>
            
            <div className="bg-muted rounded-lg p-4 mb-6">
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Your bid:</span>
                <span className="text-lg font-bold text-foreground">{formatCurrency(pendingBid)}</span>
              </div>
            </div>

            <div className="flex space-x-3">
              <Button
                variant="outline"
                onClick={() => {
                  setShowConfirmation(false);
                  setPendingBid(null);
                }}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button
                onClick={confirmBid}
                loading={isLoading}
                className="flex-1"
              >
                Confirm Bid
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BiddingPanel;