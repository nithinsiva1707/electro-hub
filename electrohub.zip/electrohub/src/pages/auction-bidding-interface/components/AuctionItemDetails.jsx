import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const AuctionItemDetails = ({ item, onAddToWatchlist, isInWatchlist }) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [showFullDescription, setShowFullDescription] = useState(false);

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    })?.format(amount);
  };

  const getConditionColor = (condition) => {
    switch (condition?.toLowerCase()) {
      case 'excellent': return 'text-success';
      case 'very good': return 'text-primary';
      case 'good': return 'text-warning';
      case 'fair': return 'text-error';
      default: return 'text-muted-foreground';
    }
  };

  const nextImage = () => {
    setCurrentImageIndex((prev) => 
      prev === item?.images?.length - 1 ? 0 : prev + 1
    );
  };

  const prevImage = () => {
    setCurrentImageIndex((prev) => 
      prev === 0 ? item?.images?.length - 1 : prev - 1
    );
  };

  return (
    <div className="bg-card border border-border rounded-lg overflow-hidden">
      {/* Image Gallery */}
      <div className="relative">
        <div className="aspect-video bg-muted overflow-hidden">
          <Image
            src={item?.images?.[currentImageIndex]}
            alt={`${item?.title} - Image ${currentImageIndex + 1}`}
            className="w-full h-full object-cover"
          />
        </div>
        
        {item?.images?.length > 1 && (
          <>
            <Button
              variant="ghost"
              onClick={prevImage}
              className="absolute left-2 top-1/2 transform -translate-y-1/2 w-10 h-10 rounded-full bg-black/50 text-white hover:bg-black/70"
            >
              <Icon name="ChevronLeft" size={20} />
            </Button>
            <Button
              variant="ghost"
              onClick={nextImage}
              className="absolute right-2 top-1/2 transform -translate-y-1/2 w-10 h-10 rounded-full bg-black/50 text-white hover:bg-black/70"
            >
              <Icon name="ChevronRight" size={20} />
            </Button>
          </>
        )}

        {/* Image Indicators */}
        {item?.images?.length > 1 && (
          <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
            {item?.images?.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentImageIndex(index)}
                className={`w-2 h-2 rounded-full transition-smooth ${
                  index === currentImageIndex ? 'bg-white' : 'bg-white/50'
                }`}
              />
            ))}
          </div>
        )}

        {/* Watchlist Button */}
        <Button
          variant="ghost"
          onClick={onAddToWatchlist}
          className="absolute top-4 right-4 w-10 h-10 rounded-full bg-black/50 text-white hover:bg-black/70"
        >
          <Icon 
            name={isInWatchlist ? "Heart" : "Heart"} 
            size={20} 
            className={isInWatchlist ? "fill-current text-error" : ""} 
          />
        </Button>
      </div>
      {/* Item Details */}
      <div className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-foreground mb-2">{item?.title}</h1>
            <p className="text-muted-foreground">{item?.brand} • {item?.model}</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-muted-foreground">Starting Bid</p>
            <p className="text-lg font-semibold text-foreground">{formatCurrency(item?.startingBid)}</p>
          </div>
        </div>

        {/* Key Specifications */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-muted rounded-lg p-3">
            <div className="flex items-center space-x-2 mb-1">
              <Icon name="Award" size={16} className="text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Condition</span>
            </div>
            <p className={`font-medium ${getConditionColor(item?.condition)}`}>
              {item?.condition}
            </p>
          </div>
          
          <div className="bg-muted rounded-lg p-3">
            <div className="flex items-center space-x-2 mb-1">
              <Icon name="Calendar" size={16} className="text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Year</span>
            </div>
            <p className="font-medium text-foreground">{item?.year}</p>
          </div>
          
          <div className="bg-muted rounded-lg p-3">
            <div className="flex items-center space-x-2 mb-1">
              <Icon name="MapPin" size={16} className="text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Location</span>
            </div>
            <p className="font-medium text-foreground">{item?.location}</p>
          </div>
          
          <div className="bg-muted rounded-lg p-3">
            <div className="flex items-center space-x-2 mb-1">
              <Icon name="Shield" size={16} className="text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Reserve</span>
            </div>
            <p className="font-medium text-foreground">
              {item?.hasReserve ? formatCurrency(item?.reservePrice) : 'No Reserve'}
            </p>
          </div>
        </div>

        {/* Description */}
        <div className="mb-6">
          <h3 className="text-lg font-semibold text-foreground mb-3">Description</h3>
          <div className="prose prose-sm max-w-none">
            <p className="text-muted-foreground leading-relaxed">
              {showFullDescription 
                ? item?.description 
                : `${item?.description?.substring(0, 300)}${item?.description?.length > 300 ? '...' : ''}`
              }
            </p>
            {item?.description?.length > 300 && (
              <Button
                variant="link"
                onClick={() => setShowFullDescription(!showFullDescription)}
                className="p-0 h-auto text-primary"
              >
                {showFullDescription ? 'Show Less' : 'Read More'}
              </Button>
            )}
          </div>
        </div>

        {/* Specifications */}
        {item?.specifications && (
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-foreground mb-3">Specifications</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {Object.entries(item?.specifications)?.map(([key, value]) => (
                <div key={key} className="flex justify-between py-2 border-b border-border">
                  <span className="text-muted-foreground capitalize">{key?.replace(/([A-Z])/g, ' $1')}</span>
                  <span className="font-medium text-foreground">{value}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Seller Information */}
        <div className="border-t border-border pt-6">
          <h3 className="text-lg font-semibold text-foreground mb-3">Seller Information</h3>
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
              <Icon name="User" size={20} color="white" />
            </div>
            <div className="flex-1">
              <div className="flex items-center space-x-2">
                <p className="font-medium text-foreground">{item?.seller?.name}</p>
                {item?.seller?.verified && (
                  <Icon name="BadgeCheck" size={16} className="text-success" />
                )}
              </div>
              <div className="flex items-center space-x-4 mt-1">
                <div className="flex items-center space-x-1">
                  <Icon name="Star" size={14} className="text-warning fill-current" />
                  <span className="text-sm text-muted-foreground">
                    {item?.seller?.rating} ({item?.seller?.reviewCount} reviews)
                  </span>
                </div>
                <span className="text-sm text-muted-foreground">
                  Member since {item?.seller?.memberSince}
                </span>
              </div>
            </div>
            <Button variant="outline" className="text-sm">
              <Icon name="MessageCircle" size={16} />
              Contact
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuctionItemDetails;