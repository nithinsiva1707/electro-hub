import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { Link } from 'react-router-dom';

const WatchlistPanel = ({ watchlistItems, onRemoveFromWatchlist }) => {
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    })?.format(amount);
  };

  const formatTimeRemaining = (endTime) => {
    const now = new Date();
    const end = new Date(endTime);
    const diff = end - now;
    
    if (diff <= 0) return 'Ended';
    
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    
    if (days > 0) return `${days}d ${hours}h`;
    if (hours > 0) return `${hours}h ${minutes}m`;
    return `${minutes}m`;
  };

  const getTimeStatus = (endTime) => {
    const now = new Date();
    const end = new Date(endTime);
    const diff = end - now;
    
    if (diff <= 0) return 'ended';
    if (diff < 300000) return 'ending-soon'; // Less than 5 minutes
    if (diff < 3600000) return 'ending-today'; // Less than 1 hour
    return 'normal';
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-foreground">Your Watchlist</h3>
        <div className="flex items-center space-x-2">
          <Icon name="Heart" size={16} className="text-error" />
          <span className="text-sm text-muted-foreground">{watchlistItems?.length} items</span>
        </div>
      </div>
      <div className="space-y-4 max-h-96 overflow-y-auto">
        {watchlistItems?.length === 0 ? (
          <div className="text-center py-8">
            <Icon name="Heart" size={48} className="text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground mb-2">Your watchlist is empty</p>
            <p className="text-sm text-muted-foreground">
              Add items to your watchlist to track auctions you're interested in
            </p>
            <Link to="/product-search-browse">
              <Button variant="outline" className="mt-4">
                <Icon name="Search" size={16} />
                Browse Auctions
              </Button>
            </Link>
          </div>
        ) : (
          watchlistItems?.map((item) => {
            const timeStatus = getTimeStatus(item?.endTime);
            const timeRemaining = formatTimeRemaining(item?.endTime);
            
            return (
              <div
                key={item?.id}
                className={`border rounded-lg p-4 transition-smooth ${
                  timeStatus === 'ending-soon' ?'border-error bg-error/5'
                    : timeStatus === 'ending-today' ?'border-warning bg-warning/5'
                    : timeStatus === 'ended' ?'border-muted bg-muted/50' :'border-border hover:border-primary/50'
                }`}
              >
                <div className="flex items-start space-x-3">
                  <div className="w-16 h-16 bg-muted rounded-lg overflow-hidden flex-shrink-0">
                    <img
                      src={item?.image}
                      alt={item?.title}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        e.target.src = '/assets/images/no_image.png';
                      }}
                    />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h4 className="font-medium text-foreground truncate">{item?.title}</h4>
                        <p className="text-sm text-muted-foreground">{item?.brand}</p>
                      </div>
                      
                      <Button
                        variant="ghost"
                        onClick={() => onRemoveFromWatchlist(item?.id)}
                        className="w-8 h-8 p-0 text-muted-foreground hover:text-error"
                      >
                        <Icon name="X" size={16} />
                      </Button>
                    </div>
                    
                    <div className="flex items-center justify-between mt-2">
                      <div>
                        <p className="text-sm text-muted-foreground">Current Bid</p>
                        <p className="font-semibold text-foreground">{formatCurrency(item?.currentBid)}</p>
                      </div>
                      
                      <div className="text-right">
                        <div className={`flex items-center space-x-1 ${
                          timeStatus === 'ending-soon' ?'text-error'
                            : timeStatus === 'ending-today' ?'text-warning'
                            : timeStatus === 'ended' ?'text-muted-foreground' :'text-muted-foreground'
                        }`}>
                          <Icon 
                            name={timeStatus === 'ended' ? 'Clock' : 'Timer'} 
                            size={14} 
                          />
                          <span className="text-sm font-medium">{timeRemaining}</span>
                        </div>
                        
                        {timeStatus === 'ending-soon' && (
                          <div className="flex items-center space-x-1 mt-1">
                            <div className="w-2 h-2 bg-error rounded-full animate-pulse"></div>
                            <span className="text-xs text-error font-medium">ENDING SOON</span>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2 mt-3">
                      <Link to={`/auction-bidding-interface?id=${item?.id}`}>
                        <Button 
                          variant="outline" 
                          className="text-xs h-8"
                          disabled={timeStatus === 'ended'}
                        >
                          <Icon name="Eye" size={14} />
                          View Auction
                        </Button>
                      </Link>
                      
                      {timeStatus !== 'ended' && (
                        <Button 
                          variant="default" 
                          className="text-xs h-8"
                        >
                          <Icon name="Gavel" size={14} />
                          Bid Now
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
      {watchlistItems?.length > 0 && (
        <div className="mt-4 pt-4 border-t border-border">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">
              {watchlistItems?.filter(item => getTimeStatus(item?.endTime) === 'ending-soon')?.length} ending soon
            </span>
            <Link to="/product-search-browse">
              <Button variant="link" className="text-sm p-0 h-auto">
                Browse more auctions
                <Icon name="ArrowRight" size={14} className="ml-1" />
              </Button>
            </Link>
          </div>
        </div>
      )}
    </div>
  );
};

export default WatchlistPanel;