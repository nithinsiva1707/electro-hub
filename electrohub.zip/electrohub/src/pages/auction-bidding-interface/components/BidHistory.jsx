import React from 'react';
import Icon from '../../../components/AppIcon';

const BidHistory = ({ bids, currentUserId }) => {
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    })?.format(amount);
  };

  const formatTime = (timestamp) => {
    const now = new Date();
    const bidTime = new Date(timestamp);
    const diffInMinutes = Math.floor((now - bidTime) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
    return bidTime?.toLocaleDateString();
  };

  const getBidderDisplay = (bid) => {
    if (bid?.bidderId === currentUserId) {
      return { name: 'You', isCurrentUser: true };
    }
    
    // Anonymize other bidders
    const bidderNumber = bid?.bidderNumber || Math.floor(Math.random() * 999) + 1;
    return { name: `Bidder ${bidderNumber}`, isCurrentUser: false };
  };

  const getBidStatus = (bid, index) => {
    if (index === 0) return 'winning';
    if (bid?.bidderId === currentUserId) return 'outbid';
    return 'normal';
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-foreground">Bid History</h3>
        <div className="flex items-center space-x-2 text-sm text-muted-foreground">
          <Icon name="Users" size={16} />
          <span>{new Set(bids.map(bid => bid.bidderId))?.size} bidders</span>
        </div>
      </div>
      <div className="space-y-3 max-h-96 overflow-y-auto">
        {bids?.length === 0 ? (
          <div className="text-center py-8">
            <Icon name="Gavel" size={48} className="text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">No bids yet</p>
            <p className="text-sm text-muted-foreground mt-1">Be the first to place a bid!</p>
          </div>
        ) : (
          bids?.map((bid, index) => {
            const bidder = getBidderDisplay(bid);
            const status = getBidStatus(bid, index);
            
            return (
              <div
                key={bid?.id}
                className={`flex items-center justify-between p-4 rounded-lg border transition-smooth ${
                  status === 'winning' ?'bg-success/5 border-success/20'
                    : status === 'outbid' ?'bg-warning/5 border-warning/20' :'bg-muted border-border'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    bidder?.isCurrentUser
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-muted-foreground text-muted-foreground-foreground'
                  }`}>
                    <Icon name="User" size={16} />
                  </div>
                  
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className={`font-medium ${
                        bidder?.isCurrentUser ? 'text-primary' : 'text-foreground'
                      }`}>
                        {bidder?.name}
                      </span>
                      {index === 0 && (
                        <div className="flex items-center space-x-1">
                          <Icon name="Crown" size={14} className="text-success" />
                          <span className="text-xs font-medium text-success">Winning</span>
                        </div>
                      )}
                      {status === 'outbid' && index !== 0 && (
                        <span className="text-xs font-medium text-warning">Outbid</span>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground">{formatTime(bid?.timestamp)}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className={`font-bold ${
                    status === 'winning' ? 'text-success' : 'text-foreground'
                  }`}>
                    {formatCurrency(bid?.amount)}
                  </p>
                  {bid?.isAutoBid && (
                    <div className="flex items-center space-x-1 mt-1">
                      <Icon name="Zap" size={12} className="text-secondary" />
                      <span className="text-xs text-secondary">Auto bid</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>
      {bids?.length > 0 && (
        <div className="mt-4 pt-4 border-t border-border">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Total bids: {bids?.length}</span>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span className="text-muted-foreground">Winning</span>
              </div>
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-warning rounded-full"></div>
                <span className="text-muted-foreground">Outbid</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BidHistory;