import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';

const AuctionTimer = ({ endTime, onTimeEnd }) => {
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });
  const [isEnding, setIsEnding] = useState(false);

  useEffect(() => {
    const calculateTimeLeft = () => {
      const now = new Date()?.getTime();
      const end = new Date(endTime)?.getTime();
      const difference = end - now;

      if (difference > 0) {
        const days = Math.floor(difference / (1000 * 60 * 60 * 24));
        const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((difference % (1000 * 60)) / 1000);

        setTimeLeft({ days, hours, minutes, seconds });
        setIsEnding(difference < 300000); // Last 5 minutes
      } else {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
        onTimeEnd && onTimeEnd();
      }
    };

    calculateTimeLeft();
    const timer = setInterval(calculateTimeLeft, 1000);

    return () => clearInterval(timer);
  }, [endTime, onTimeEnd]);

  const formatTime = (value) => value?.toString()?.padStart(2, '0');

  return (
    <div className={`bg-card border border-border rounded-lg p-4 ${isEnding ? 'border-error bg-error/5' : ''}`}>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center space-x-2">
          <Icon name="Clock" size={20} className={isEnding ? 'text-error' : 'text-muted-foreground'} />
          <span className={`font-medium ${isEnding ? 'text-error' : 'text-foreground'}`}>
            {isEnding ? 'Ending Soon!' : 'Time Remaining'}
          </span>
        </div>
        {isEnding && (
          <div className="flex items-center space-x-1 text-error">
            <div className="w-2 h-2 bg-error rounded-full animate-pulse"></div>
            <span className="text-sm font-medium">LIVE</span>
          </div>
        )}
      </div>
      <div className="grid grid-cols-4 gap-2">
        <div className="text-center">
          <div className={`text-2xl font-bold ${isEnding ? 'text-error' : 'text-foreground'}`}>
            {formatTime(timeLeft?.days)}
          </div>
          <div className="text-xs text-muted-foreground">Days</div>
        </div>
        <div className="text-center">
          <div className={`text-2xl font-bold ${isEnding ? 'text-error' : 'text-foreground'}`}>
            {formatTime(timeLeft?.hours)}
          </div>
          <div className="text-xs text-muted-foreground">Hours</div>
        </div>
        <div className="text-center">
          <div className={`text-2xl font-bold ${isEnding ? 'text-error' : 'text-foreground'}`}>
            {formatTime(timeLeft?.minutes)}
          </div>
          <div className="text-xs text-muted-foreground">Minutes</div>
        </div>
        <div className="text-center">
          <div className={`text-2xl font-bold ${isEnding ? 'text-error' : 'text-foreground'}`}>
            {formatTime(timeLeft?.seconds)}
          </div>
          <div className="text-xs text-muted-foreground">Seconds</div>
        </div>
      </div>
      {isEnding && (
        <div className="mt-3 text-center">
          <span className="text-sm text-error font-medium">
            Auction extends by 2 minutes with each new bid
          </span>
        </div>
      )}
    </div>
  );
};

export default AuctionTimer;