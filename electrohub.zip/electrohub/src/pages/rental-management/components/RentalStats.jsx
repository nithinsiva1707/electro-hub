import React from 'react';
import Icon from '../../../components/AppIcon';

const RentalStats = ({ stats, type }) => {
  const renterStats = [
    {
      label: 'Active Rentals',
      value: stats?.activeRentals,
      icon: 'Package',
      color: 'text-success',
      bgColor: 'bg-success/10'
    },
    {
      label: 'Total Spent',
      value: `$${stats?.totalSpent}`,
      icon: 'DollarSign',
      color: 'text-primary',
      bgColor: 'bg-primary/10'
    },
    {
      label: 'Items Rented',
      value: stats?.itemsRented,
      icon: 'ShoppingBag',
      color: 'text-secondary',
      bgColor: 'bg-secondary/10'
    },
    {
      label: 'Avg Rating',
      value: stats?.avgRating,
      icon: 'Star',
      color: 'text-warning',
      bgColor: 'bg-warning/10'
    }
  ];

  const ownerStats = [
    {
      label: 'Listed Items',
      value: stats?.listedItems,
      icon: 'Package',
      color: 'text-primary',
      bgColor: 'bg-primary/10'
    },
    {
      label: 'Total Earned',
      value: `$${stats?.totalEarned}`,
      icon: 'DollarSign',
      color: 'text-success',
      bgColor: 'bg-success/10'
    },
    {
      label: 'Active Rentals',
      value: stats?.activeRentals,
      icon: 'Activity',
      color: 'text-secondary',
      bgColor: 'bg-secondary/10'
    },
    {
      label: 'Avg Rating',
      value: stats?.avgRating,
      icon: 'Star',
      color: 'text-warning',
      bgColor: 'bg-warning/10'
    }
  ];

  const displayStats = type === 'renter' ? renterStats : ownerStats;

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      {displayStats?.map((stat, index) => (
        <div key={index} className="bg-card border border-border rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">{stat?.label}</p>
              <p className="text-2xl font-bold text-foreground">{stat?.value}</p>
            </div>
            <div className={`w-10 h-10 rounded-lg ${stat?.bgColor} flex items-center justify-center`}>
              <Icon name={stat?.icon} size={20} className={stat?.color} />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default RentalStats;