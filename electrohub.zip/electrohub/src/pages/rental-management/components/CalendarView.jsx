import React, { useState } from 'react';

import Button from '../../../components/ui/Button';

const CalendarView = ({ rentals, onDateSelect, onClose }) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(null);

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  const getDaysInMonth = (date) => {
    const year = date?.getFullYear();
    const month = date?.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay?.getDate();
    const startingDayOfWeek = firstDay?.getDay();

    const days = [];
    
    // Add empty cells for days before the first day of the month
    for (let i = 0; i < startingDayOfWeek; i++) {
      days?.push(null);
    }
    
    // Add all days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      days?.push(new Date(year, month, day));
    }
    
    return days;
  };

  const getRentalForDate = (date) => {
    if (!date) return null;
    
    return rentals?.find(rental => {
      const startDate = new Date(rental.startDate);
      const endDate = new Date(rental.endDate);
      return date >= startDate && date <= endDate;
    });
  };

  const navigateMonth = (direction) => {
    const newDate = new Date(currentDate);
    newDate?.setMonth(currentDate?.getMonth() + direction);
    setCurrentDate(newDate);
  };

  const handleDateClick = (date) => {
    if (!date) return;
    setSelectedDate(date);
    onDateSelect(date);
  };

  const isToday = (date) => {
    if (!date) return false;
    const today = new Date();
    return date?.toDateString() === today?.toDateString();
  };

  const isSelected = (date) => {
    if (!date || !selectedDate) return false;
    return date?.toDateString() === selectedDate?.toDateString();
  };

  const days = getDaysInMonth(currentDate);

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-modal p-4">
      <div className="bg-card border border-border rounded-lg w-full max-w-md">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border">
          <h3 className="text-lg font-semibold text-foreground">Rental Calendar</h3>
          <Button variant="ghost" size="sm" iconName="X" onClick={onClose} />
        </div>

        {/* Calendar Navigation */}
        <div className="flex items-center justify-between p-4">
          <Button
            variant="ghost"
            size="sm"
            iconName="ChevronLeft"
            onClick={() => navigateMonth(-1)}
          />
          <h4 className="text-lg font-medium text-foreground">
            {monthNames?.[currentDate?.getMonth()]} {currentDate?.getFullYear()}
          </h4>
          <Button
            variant="ghost"
            size="sm"
            iconName="ChevronRight"
            onClick={() => navigateMonth(1)}
          />
        </div>

        {/* Calendar Grid */}
        <div className="px-4 pb-4">
          {/* Days of Week Header */}
          <div className="grid grid-cols-7 gap-1 mb-2">
            {daysOfWeek?.map(day => (
              <div key={day} className="text-center text-xs font-medium text-muted-foreground py-2">
                {day}
              </div>
            ))}
          </div>

          {/* Calendar Days */}
          <div className="grid grid-cols-7 gap-1">
            {days?.map((date, index) => {
              const rental = getRentalForDate(date);
              
              return (
                <button
                  key={index}
                  onClick={() => handleDateClick(date)}
                  disabled={!date}
                  className={`
                    aspect-square flex items-center justify-center text-sm rounded-md transition-smooth relative
                    ${!date ? 'invisible' : ''}
                    ${isToday(date) ? 'bg-primary text-primary-foreground font-semibold' : ''}
                    ${isSelected(date) ? 'ring-2 ring-primary' : ''}
                    ${rental ? 'bg-secondary/20 text-secondary' : ''}
                    ${!isToday(date) && !rental ? 'hover:bg-muted text-foreground' : ''}
                  `}
                >
                  {date && date?.getDate()}
                  {rental && (
                    <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-secondary rounded-full"></div>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Legend */}
        <div className="px-4 pb-4 border-t border-border pt-4">
          <div className="flex items-center justify-center gap-4 text-xs">
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 bg-primary rounded"></div>
              <span className="text-muted-foreground">Today</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 bg-secondary/20 rounded"></div>
              <span className="text-muted-foreground">Has Rental</span>
            </div>
          </div>
        </div>

        {/* Selected Date Info */}
        {selectedDate && (
          <div className="px-4 pb-4">
            <div className="bg-muted rounded-lg p-3">
              <p className="text-sm font-medium text-foreground mb-1">
                {selectedDate?.toLocaleDateString('en-US', { 
                  weekday: 'long', 
                  year: 'numeric', 
                  month: 'long', 
                  day: 'numeric' 
                })}
              </p>
              {getRentalForDate(selectedDate) ? (
                <p className="text-xs text-muted-foreground">
                  Rental: {getRentalForDate(selectedDate)?.item?.name}
                </p>
              ) : (
                <p className="text-xs text-muted-foreground">No rentals scheduled</p>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CalendarView;