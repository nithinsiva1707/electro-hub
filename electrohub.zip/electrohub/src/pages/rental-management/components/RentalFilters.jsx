import React from 'react';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';
import Input from '../../../components/ui/Input';
import Icon from '../../../components/AppIcon';

const RentalFilters = ({ filters, onFilterChange, onClearFilters }) => {
  const statusOptions = [
    { value: 'all', label: 'All Status' },
    { value: 'pending', label: 'Pending' },
    { value: 'upcoming', label: 'Upcoming' },
    { value: 'active', label: 'Active' },
    { value: 'overdue', label: 'Overdue' },
    { value: 'completed', label: 'Completed' },
    { value: 'cancelled', label: 'Cancelled' }
  ];

  const sortOptions = [
    { value: 'newest', label: 'Newest First' },
    { value: 'oldest', label: 'Oldest First' },
    { value: 'amount-high', label: 'Amount: High to Low' },
    { value: 'amount-low', label: 'Amount: Low to High' },
    { value: 'ending-soon', label: 'Ending Soon' }
  ];

  const categoryOptions = [
    { value: 'all', label: 'All Categories' },
    { value: 'personal-gadgets', label: 'Personal Gadgets' },
    { value: 'home-kitchen', label: 'Home & Kitchen' },
    { value: 'office-electronics', label: 'Office Electronics' },
    { value: 'entertainment', label: 'Entertainment Devices' }
  ];

  return (
    <div className="bg-card border border-border rounded-lg p-4 mb-6">
      <div className="flex flex-col lg:flex-row gap-4">
        {/* Search */}
        <div className="flex-1">
          <Input
            type="search"
            placeholder="Search by item name or renter..."
            value={filters?.search}
            onChange={(e) => onFilterChange('search', e?.target?.value)}
            className="w-full"
          />
        </div>

        {/* Status Filter */}
        <div className="w-full lg:w-48">
          <Select
            options={statusOptions}
            value={filters?.status}
            onChange={(value) => onFilterChange('status', value)}
            placeholder="Filter by status"
          />
        </div>

        {/* Category Filter */}
        <div className="w-full lg:w-48">
          <Select
            options={categoryOptions}
            value={filters?.category}
            onChange={(value) => onFilterChange('category', value)}
            placeholder="Filter by category"
          />
        </div>

        {/* Sort */}
        <div className="w-full lg:w-48">
          <Select
            options={sortOptions}
            value={filters?.sort}
            onChange={(value) => onFilterChange('sort', value)}
            placeholder="Sort by"
          />
        </div>

        {/* Clear Filters */}
        <Button
          variant="outline"
          onClick={onClearFilters}
          iconName="X"
          className="lg:w-auto"
        >
          Clear
        </Button>
      </div>
      {/* Active Filters Display */}
      {(filters?.search || filters?.status !== 'all' || filters?.category !== 'all') && (
        <div className="flex flex-wrap gap-2 mt-4 pt-4 border-t border-border">
          <span className="text-sm text-muted-foreground">Active filters:</span>
          
          {filters?.search && (
            <span className="inline-flex items-center gap-1 px-2 py-1 bg-primary/10 text-primary rounded-md text-xs">
              Search: "{filters?.search}"
              <button onClick={() => onFilterChange('search', '')}>
                <Icon name="X" size={12} />
              </button>
            </span>
          )}
          
          {filters?.status !== 'all' && (
            <span className="inline-flex items-center gap-1 px-2 py-1 bg-secondary/10 text-secondary rounded-md text-xs">
              Status: {statusOptions?.find(opt => opt?.value === filters?.status)?.label}
              <button onClick={() => onFilterChange('status', 'all')}>
                <Icon name="X" size={12} />
              </button>
            </span>
          )}
          
          {filters?.category !== 'all' && (
            <span className="inline-flex items-center gap-1 px-2 py-1 bg-accent/10 text-accent rounded-md text-xs">
              Category: {categoryOptions?.find(opt => opt?.value === filters?.category)?.label}
              <button onClick={() => onFilterChange('category', 'all')}>
                <Icon name="X" size={12} />
              </button>
            </span>
          )}
        </div>
      )}
    </div>
  );
};

export default RentalFilters;