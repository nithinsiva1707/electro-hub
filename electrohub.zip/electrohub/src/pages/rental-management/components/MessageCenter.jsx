import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const MessageCenter = ({ messages, onSendMessage, onClose }) => {
  const [newMessage, setNewMessage] = useState('');
  const [selectedTemplate, setSelectedTemplate] = useState('');

  const quickTemplates = [
    "Hi! I\'m ready for pickup. When would be a good time?",
    "The item is working perfectly. Thank you!",
    "I need to extend the rental period. Is that possible?",
    "I\'m ready to return the item. Please confirm the return process.",
    "There seems to be an issue with the item. Can we discuss?"
  ];

  const handleSendMessage = () => {
    if (newMessage?.trim()) {
      onSendMessage(newMessage);
      setNewMessage('');
    }
  };

  const handleTemplateSelect = (template) => {
    setNewMessage(template);
    setSelectedTemplate('');
  };

  const formatMessageTime = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInHours = (now - date) / (1000 * 60 * 60);

    if (diffInHours < 1) {
      return 'Just now';
    } else if (diffInHours < 24) {
      return `${Math.floor(diffInHours)}h ago`;
    } else {
      return date?.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-modal p-4">
      <div className="bg-card border border-border rounded-lg w-full max-w-2xl max-h-[80vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full overflow-hidden">
              <Image
                src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face"
                alt="Contact"
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <h3 className="font-semibold text-foreground">John Smith</h3>
              <p className="text-sm text-muted-foreground">MacBook Pro M2 Rental</p>
            </div>
          </div>
          <Button variant="ghost" size="sm" iconName="X" onClick={onClose} />
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages?.map((message, index) => (
            <div
              key={index}
              className={`flex ${message?.isOwn ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`max-w-xs lg:max-w-md ${message?.isOwn ? 'order-2' : 'order-1'}`}>
                <div
                  className={`rounded-lg p-3 ${
                    message?.isOwn
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-muted text-muted-foreground'
                  }`}
                >
                  <p className="text-sm">{message?.content}</p>
                  {message?.attachment && (
                    <div className="mt-2 p-2 bg-black/10 rounded border">
                      <div className="flex items-center gap-2">
                        <Icon name="Paperclip" size={14} />
                        <span className="text-xs">{message?.attachment?.name}</span>
                      </div>
                    </div>
                  )}
                </div>
                <p className="text-xs text-muted-foreground mt-1 px-1">
                  {formatMessageTime(message?.timestamp)}
                </p>
              </div>
              {!message?.isOwn && (
                <div className="w-8 h-8 rounded-full overflow-hidden order-1 mr-2 mt-auto">
                  <Image
                    src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=32&h=32&fit=crop&crop=face"
                    alt="Contact"
                    className="w-full h-full object-cover"
                  />
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Quick Templates */}
        <div className="px-4 py-2 border-t border-border">
          <div className="flex flex-wrap gap-2">
            {quickTemplates?.slice(0, 3)?.map((template, index) => (
              <button
                key={index}
                onClick={() => handleTemplateSelect(template)}
                className="text-xs px-2 py-1 bg-muted text-muted-foreground rounded hover:bg-muted/80 transition-smooth"
              >
                {template?.substring(0, 30)}...
              </button>
            ))}
          </div>
        </div>

        {/* Message Input */}
        <div className="p-4 border-t border-border">
          <div className="flex gap-2">
            <div className="flex-1">
              <Input
                type="text"
                placeholder="Type your message..."
                value={newMessage}
                onChange={(e) => setNewMessage(e?.target?.value)}
                onKeyPress={(e) => e?.key === 'Enter' && handleSendMessage()}
              />
            </div>
            <Button
              variant="ghost"
              size="sm"
              iconName="Paperclip"
              onClick={() => console.log('Attach file')}
            />
            <Button
              variant="default"
              size="sm"
              iconName="Send"
              onClick={handleSendMessage}
              disabled={!newMessage?.trim()}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default MessageCenter;