import React from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const RentalCard = ({ rental, type, onAction }) => {
  const getStatusColor = (status) => {
    switch (status) {
      case 'active':
        return 'bg-success text-success-foreground';
      case 'upcoming':
        return 'bg-warning text-warning-foreground';
      case 'overdue':
        return 'bg-error text-error-foreground';
      case 'completed':
        return 'bg-muted text-muted-foreground';
      case 'pending':
        return 'bg-secondary text-secondary-foreground';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const formatDate = (date) => {
    return new Date(date)?.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const calculateDaysRemaining = (endDate) => {
    const today = new Date();
    const end = new Date(endDate);
    const diffTime = end - today;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const renderRenterActions = () => {
    switch (rental?.status) {
      case 'upcoming':
        return (
          <div className="flex flex-col sm:flex-row gap-2">
            <Button 
              variant="outline" 
              size="sm"
              iconName="Calendar"
              onClick={() => onAction('reschedule', rental?.id)}
            >
              Reschedule
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              iconName="MessageCircle"
              onClick={() => onAction('message', rental?.id)}
            >
              Message Owner
            </Button>
          </div>
        );
      case 'active':
        return (
          <div className="flex flex-col sm:flex-row gap-2">
            <Button 
              variant="default" 
              size="sm"
              iconName="RotateCcw"
              onClick={() => onAction('return', rental?.id)}
            >
              Initiate Return
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              iconName="MessageCircle"
              onClick={() => onAction('message', rental?.id)}
            >
              Contact Owner
            </Button>
          </div>
        );
      case 'overdue':
        return (
          <div className="flex flex-col sm:flex-row gap-2">
            <Button 
              variant="destructive" 
              size="sm"
              iconName="AlertTriangle"
              onClick={() => onAction('return', rental?.id)}
            >
              Return Now
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              iconName="MessageCircle"
              onClick={() => onAction('message', rental?.id)}
            >
              Contact Owner
            </Button>
          </div>
        );
      default:
        return null;
    }
  };

  const renderOwnerActions = () => {
    switch (rental?.status) {
      case 'pending':
        return (
          <div className="flex flex-col sm:flex-row gap-2">
            <Button 
              variant="success" 
              size="sm"
              iconName="Check"
              onClick={() => onAction('approve', rental?.id)}
            >
              Approve
            </Button>
            <Button 
              variant="destructive" 
              size="sm"
              iconName="X"
              onClick={() => onAction('reject', rental?.id)}
            >
              Reject
            </Button>
          </div>
        );
      case 'active':
        return (
          <div className="flex flex-col sm:flex-row gap-2">
            <Button 
              variant="outline" 
              size="sm"
              iconName="Eye"
              onClick={() => onAction('track', rental?.id)}
            >
              Track Item
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              iconName="MessageCircle"
              onClick={() => onAction('message', rental?.id)}
            >
              Message Renter
            </Button>
          </div>
        );
      case 'returning':
        return (
          <div className="flex flex-col sm:flex-row gap-2">
            <Button 
              variant="default" 
              size="sm"
              iconName="CheckCircle"
              onClick={() => onAction('confirm-return', rental?.id)}
            >
              Confirm Return
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              iconName="Camera"
              onClick={() => onAction('inspect', rental?.id)}
            >
              Inspect Item
            </Button>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="bg-card border border-border rounded-lg p-4 hover:shadow-elevated transition-smooth">
      <div className="flex flex-col lg:flex-row gap-4">
        {/* Item Image */}
        <div className="flex-shrink-0">
          <div className="w-full lg:w-24 h-48 lg:h-24 rounded-lg overflow-hidden">
            <Image
              src={rental?.item?.image}
              alt={rental?.item?.name}
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        {/* Rental Details */}
        <div className="flex-1 min-w-0">
          <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2 mb-3">
            <div>
              <h3 className="text-lg font-semibold text-foreground truncate">
                {rental?.item?.name}
              </h3>
              <p className="text-sm text-muted-foreground">
                {type === 'renter' ? `Owner: ${rental?.owner?.name}` : `Renter: ${rental?.renter?.name}`}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(rental?.status)}`}>
                {rental?.status?.charAt(0)?.toUpperCase() + rental?.status?.slice(1)}
              </span>
              {rental?.status === 'active' && (
                <span className="text-xs text-muted-foreground">
                  {calculateDaysRemaining(rental?.endDate)} days left
                </span>
              )}
            </div>
          </div>

          {/* Rental Period */}
          <div className="flex flex-col sm:flex-row sm:items-center gap-2 mb-3">
            <div className="flex items-center gap-1 text-sm text-muted-foreground">
              <Icon name="Calendar" size={14} />
              <span>{formatDate(rental?.startDate)} - {formatDate(rental?.endDate)}</span>
            </div>
            <div className="flex items-center gap-1 text-sm text-muted-foreground">
              <Icon name="DollarSign" size={14} />
              <span>${rental?.totalAmount}</span>
            </div>
          </div>

          {/* Progress Bar for Active Rentals */}
          {rental?.status === 'active' && (
            <div className="mb-3">
              <div className="flex justify-between text-xs text-muted-foreground mb-1">
                <span>Rental Progress</span>
                <span>{rental?.progressPercentage}%</span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div 
                  className="bg-primary h-2 rounded-full transition-all duration-300"
                  style={{ width: `${rental?.progressPercentage}%` }}
                ></div>
              </div>
            </div>
          )}

          {/* Special Messages */}
          {rental?.status === 'upcoming' && (
            <div className="bg-warning/10 border border-warning/20 rounded-md p-2 mb-3">
              <div className="flex items-center gap-2">
                <Icon name="Clock" size={14} className="text-warning" />
                <span className="text-xs text-warning">
                  Pickup scheduled for {formatDate(rental?.pickupDate)} at {rental?.pickupTime}
                </span>
              </div>
            </div>
          )}

          {rental?.status === 'overdue' && (
            <div className="bg-error/10 border border-error/20 rounded-md p-2 mb-3">
              <div className="flex items-center gap-2">
                <Icon name="AlertTriangle" size={14} className="text-error" />
                <span className="text-xs text-error">
                  Item is {Math.abs(calculateDaysRemaining(rental?.endDate))} days overdue
                </span>
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex justify-between items-center">
            {type === 'renter' ? renderRenterActions() : renderOwnerActions()}
            
            <Button 
              variant="ghost" 
              size="sm"
              iconName="MoreHorizontal"
              onClick={() => onAction('more', rental?.id)}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default RentalCard;