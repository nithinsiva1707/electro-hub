import React, { useState, useEffect } from 'react';
import Header from '../../components/ui/Header';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import RentalCard from './components/RentalCard';
import RentalStats from './components/RentalStats';
import RentalFilters from './components/RentalFilters';
import MessageCenter from './components/MessageCenter';
import CalendarView from './components/CalendarView';

const RentalManagement = () => {
  const [activeTab, setActiveTab] = useState('renter');
  const [showMessageCenter, setShowMessageCenter] = useState(false);
  const [showCalendar, setShowCalendar] = useState(false);
  const [selectedRental, setSelectedRental] = useState(null);
  const [filters, setFilters] = useState({
    search: '',
    status: 'all',
    category: 'all',
    sort: 'newest'
  });

  // Mock data for rentals
  const mockRenterRentals = [
    {
      id: 1,
      item: {
        name: "MacBook Pro M2 14-inch",
        image: "https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=400&h=300&fit=crop",
        category: "office-electronics"
      },
      owner: {
        name: "Sarah Johnson",
        avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=40&h=40&fit=crop&crop=face"
      },
      status: "active",
      startDate: "2025-08-28",
      endDate: "2025-09-15",
      pickupDate: "2025-08-28",
      pickupTime: "10:00 AM",
      totalAmount: 450,
      progressPercentage: 65
    },
    {
      id: 2,
      item: {
        name: "Canon EOS R5 Camera",
        image: "https://images.unsplash.com/photo-1606983340126-99ab4feaa64a?w=400&h=300&fit=crop",
        category: "personal-gadgets"
      },
      owner: {
        name: "Mike Chen",
        avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face"
      },
      status: "upcoming",
      startDate: "2025-09-05",
      endDate: "2025-09-12",
      pickupDate: "2025-09-05",
      pickupTime: "2:00 PM",
      totalAmount: 280,
      progressPercentage: 0
    },
    {
      id: 3,
      item: {
        name: "KitchenAid Stand Mixer",
        image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=300&fit=crop",
        category: "home-kitchen"
      },
      owner: {
        name: "Emily Davis",
        avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop&crop=face"
      },
      status: "overdue",
      startDate: "2025-08-20",
      endDate: "2025-08-30",
      pickupDate: "2025-08-20",
      pickupTime: "11:00 AM",
      totalAmount: 120,
      progressPercentage: 100
    }
  ];

  const mockOwnerRentals = [
    {
      id: 4,
      item: {
        name: "PlayStation 5 Console",
        image: "https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?w=400&h=300&fit=crop",
        category: "entertainment"
      },
      renter: {
        name: "Alex Rodriguez",
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&crop=face"
      },
      status: "pending",
      startDate: "2025-09-10",
      endDate: "2025-09-20",
      totalAmount: 200,
      progressPercentage: 0
    },
    {
      id: 5,
      item: {
        name: "Dyson V15 Vacuum",
        image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&h=300&fit=crop",
        category: "home-kitchen"
      },
      renter: {
        name: "Jessica Wilson",
        avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=40&h=40&fit=crop&crop=face"
      },
      status: "active",
      startDate: "2025-08-25",
      endDate: "2025-09-08",
      totalAmount: 150,
      progressPercentage: 45
    },
    {
      id: 6,
      item: {
        name: "iPad Pro 12.9-inch",
        image: "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=400&h=300&fit=crop",
        category: "personal-gadgets"
      },
      renter: {
        name: "David Kim",
        avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop&crop=face"
      },
      status: "returning",
      startDate: "2025-08-15",
      endDate: "2025-09-01",
      totalAmount: 320,
      progressPercentage: 95
    }
  ];

  // Mock stats data
  const renterStats = {
    activeRentals: 2,
    totalSpent: 1250,
    itemsRented: 15,
    avgRating: 4.8
  };

  const ownerStats = {
    listedItems: 8,
    totalEarned: 2340,
    activeRentals: 3,
    avgRating: 4.9
  };

  // Mock messages data
  const mockMessages = [
    {
      id: 1,
      content: "Hi! I\'m interested in renting your MacBook. Is it still available?",
      timestamp: new Date(Date.now() - 3600000),
      isOwn: false
    },
    {
      id: 2,
      content: "Yes, it's available! When would you like to pick it up?",
      timestamp: new Date(Date.now() - 3000000),
      isOwn: true
    },
    {
      id: 3,
      content: "How about tomorrow at 2 PM? I can meet at your location.",
      timestamp: new Date(Date.now() - 1800000),
      isOwn: false
    },
    {
      id: 4,
      content: "Perfect! I\'ll send you the exact address. Please bring a valid ID.",
      timestamp: new Date(Date.now() - 900000),
      isOwn: true
    }
  ];

  const getCurrentRentals = () => {
    return activeTab === 'renter' ? mockRenterRentals : mockOwnerRentals;
  };

  const getCurrentStats = () => {
    return activeTab === 'renter' ? renterStats : ownerStats;
  };

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const handleClearFilters = () => {
    setFilters({
      search: '',
      status: 'all',
      category: 'all',
      sort: 'newest'
    });
  };

  const handleRentalAction = (action, rentalId) => {
    console.log(`Action: ${action} for rental: ${rentalId}`);
    
    switch (action) {
      case 'message':
        setSelectedRental(rentalId);
        setShowMessageCenter(true);
        break;
      case 'reschedule':
        setShowCalendar(true);
        break;
      case 'return':
        console.log('Initiating return process');
        break;
      case 'approve': console.log('Approving rental request');
        break;
      case 'reject': console.log('Rejecting rental request');
        break;
      case 'track': console.log('Tracking item location');
        break;
      case 'confirm-return':
        console.log('Confirming item return');
        break;
      case 'inspect': console.log('Opening inspection form');
        break;
      default:
        console.log('Unknown action');
    }
  };

  const handleSendMessage = (message) => {
    console.log('Sending message:', message);
    // In a real app, this would send the message to the backend
  };

  const handleDateSelect = (date) => {
    console.log('Selected date:', date);
    setShowCalendar(false);
  };

  const filterRentals = (rentals) => {
    let filtered = [...rentals];

    // Search filter
    if (filters?.search) {
      filtered = filtered?.filter(rental =>
        rental?.item?.name?.toLowerCase()?.includes(filters?.search?.toLowerCase()) ||
        (activeTab === 'renter' ? 
          rental?.owner?.name?.toLowerCase()?.includes(filters?.search?.toLowerCase()) :
          rental?.renter?.name?.toLowerCase()?.includes(filters?.search?.toLowerCase())
        )
      );
    }

    // Status filter
    if (filters?.status !== 'all') {
      filtered = filtered?.filter(rental => rental?.status === filters?.status);
    }

    // Category filter
    if (filters?.category !== 'all') {
      filtered = filtered?.filter(rental => rental?.item?.category === filters?.category);
    }

    // Sort
    switch (filters?.sort) {
      case 'oldest':
        filtered?.sort((a, b) => new Date(a.startDate) - new Date(b.startDate));
        break;
      case 'amount-high':
        filtered?.sort((a, b) => b?.totalAmount - a?.totalAmount);
        break;
      case 'amount-low':
        filtered?.sort((a, b) => a?.totalAmount - b?.totalAmount);
        break;
      case 'ending-soon':
        filtered?.sort((a, b) => new Date(a.endDate) - new Date(b.endDate));
        break;
      default: // newest
        filtered?.sort((a, b) => new Date(b.startDate) - new Date(a.startDate));
    }

    return filtered;
  };

  const filteredRentals = filterRentals(getCurrentRentals());

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Page Header */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold text-foreground">Rental Management</h1>
              <p className="text-muted-foreground mt-1">
                Manage your rentals and track all activities
              </p>
            </div>
            
            <div className="flex items-center gap-3 mt-4 sm:mt-0">
              <Button
                variant="outline"
                iconName="Calendar"
                onClick={() => setShowCalendar(true)}
              >
                Calendar
              </Button>
              <Button
                variant="outline"
                iconName="MessageCircle"
                onClick={() => setShowMessageCenter(true)}
              >
                Messages
              </Button>
            </div>
          </div>

          {/* Tab Navigation */}
          <div className="flex space-x-1 bg-muted p-1 rounded-lg mb-6 w-fit">
            <button
              onClick={() => setActiveTab('renter')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-smooth ${
                activeTab === 'renter' ?'bg-card text-foreground shadow-sm' :'text-muted-foreground hover:text-foreground'
              }`}
            >
              <Icon name="ShoppingBag" size={16} className="inline mr-2" />
              My Rentals
            </button>
            <button
              onClick={() => setActiveTab('owner')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-smooth ${
                activeTab === 'owner' ?'bg-card text-foreground shadow-sm' :'text-muted-foreground hover:text-foreground'
              }`}
            >
              <Icon name="Package" size={16} className="inline mr-2" />
              My Listed Items
            </button>
          </div>

          {/* Stats */}
          <RentalStats stats={getCurrentStats()} type={activeTab} />

          {/* Filters */}
          <RentalFilters
            filters={filters}
            onFilterChange={handleFilterChange}
            onClearFilters={handleClearFilters}
          />

          {/* Rentals List */}
          <div className="space-y-4">
            {filteredRentals?.length > 0 ? (
              filteredRentals?.map(rental => (
                <RentalCard
                  key={rental?.id}
                  rental={rental}
                  type={activeTab}
                  onAction={handleRentalAction}
                />
              ))
            ) : (
              <div className="text-center py-12">
                <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                  <Icon name="Package" size={32} className="text-muted-foreground" />
                </div>
                <h3 className="text-lg font-medium text-foreground mb-2">
                  No rentals found
                </h3>
                <p className="text-muted-foreground mb-4">
                  {activeTab === 'renter' ? "You haven't rented any items yet." :"You don't have any listed items with rentals."}
                </p>
                <Button
                  variant="default"
                  iconName="Plus"
                  onClick={() => window.location.href = activeTab === 'renter' ? '/product-search-browse' : '/product-listing-creation'}
                >
                  {activeTab === 'renter' ? 'Browse Items' : 'List an Item'}
                </Button>
              </div>
            )}
          </div>
        </div>
      </main>
      {/* Message Center Modal */}
      {showMessageCenter && (
        <MessageCenter
          messages={mockMessages}
          onSendMessage={handleSendMessage}
          onClose={() => setShowMessageCenter(false)}
        />
      )}
      {/* Calendar Modal */}
      {showCalendar && (
        <CalendarView
          rentals={getCurrentRentals()}
          onDateSelect={handleDateSelect}
          onClose={() => setShowCalendar(false)}
        />
      )}
    </div>
  );
};

export default RentalManagement;