import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ScrollToTop from "components/ScrollToTop";
import ErrorBoundary from "components/ErrorBoundary";
import NotFound from "pages/NotFound";
import ProductSearchBrowse from './pages/product-search-browse';
import ProductDetailBooking from './pages/product-detail-booking';
import MarketplaceDashboard from './pages/marketplace-dashboard';
import ProductListingCreation from './pages/product-listing-creation';
import RentalManagement from './pages/rental-management';
import AuctionBiddingInterface from './pages/auction-bidding-interface';

const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
      <ScrollToTop />
      <RouterRoutes>
        {/* Define your route here */}
        <Route path="/" element={<AuctionBiddingInterface />} />
        <Route path="/product-search-browse" element={<ProductSearchBrowse />} />
        <Route path="/product-detail-booking" element={<ProductDetailBooking />} />
        <Route path="/marketplace-dashboard" element={<MarketplaceDashboard />} />
        <Route path="/product-listing-creation" element={<ProductListingCreation />} />
        <Route path="/rental-management" element={<RentalManagement />} />
        <Route path="/auction-bidding-interface" element={<AuctionBiddingInterface />} />
        <Route path="*" element={<NotFound />} />
      </RouterRoutes>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;
